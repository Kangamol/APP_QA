export interface ReportRepairByItem {
    qaRepair_ID: number,
    repairDate: Date,
    repairDocNumber: string,
    repairType: string,
    reasonType: string,
    Qty: number
}