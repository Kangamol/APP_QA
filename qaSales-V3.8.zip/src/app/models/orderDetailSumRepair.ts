export interface OrderDetailSumRepair {
    OrderNumber: String,
    QTY: number,
    Filling: number,
    Setting: number,
    Polishing: number,
    Plating: number,
    Stamp: number,
    Enamel: number,
    Parts: number
}