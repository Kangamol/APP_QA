export interface RepairTypePopup {

    qaRepair_ID: number;
    repairDocNumber: string;
    repair_Item: number;
    qaBill_ID: number;
    userID: number;
    OrderNumber: string;
    repairDate: Date;
    receiveDate: Date;
    qaRepairStatus: string;
    repairType: string;
    reasonType: string;
    Qty: number;
    type_ID: string;
    reason_No: string;

}


