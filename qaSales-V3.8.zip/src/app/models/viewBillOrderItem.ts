export interface ViewBillOrderItem {
    qaBill_ID: Number,
    receiveDate: Date,
    qaDocNumber: String,
    Qty: Number,
    QaFinish: Number,
    nickName: String,
    fullName: String,
    thaiDate: String,
    avatar: String,
    showIcon: String
}