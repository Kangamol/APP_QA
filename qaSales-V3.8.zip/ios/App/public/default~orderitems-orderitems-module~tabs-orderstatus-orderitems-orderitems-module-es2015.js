(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~orderitems-orderitems-module~tabs-orderstatus-orderitems-orderitems-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/orderstatus/orderitems/orderitems.page.html":
/*!********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/orderstatus/orderitems/orderitems.page.html ***!
  \********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"backToOrderStatus()\">\n        <ion-icon name=\"arrow-back\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-title><ion-text color=\"primary\" class=\"fontSize20 fontPromptBold\">{{ orderNumber }}</ion-text></ion-title>\n    <ion-button slot=\"end\" color=\"warning\" size=\"medium\" (click)=\"gotoReportRepair()\"><ion-text class=\"fontPromptRegular\">สรุปงานซ่อม</ion-text></ion-button>\n  </ion-toolbar>\n\n  <ion-grid>\n    <ion-row >\n      <ion-col size=\"2.2\" style=\"border: solid 1px; border-color: black;\">\n        <ion-row class=\"fontPromptRegular fontSize14 ion-text-center\">\n          <ion-col>\n            <ion-text>กำหนดส่ง<br></ion-text>\n          </ion-col>\n        </ion-row>\n        <ion-row class=\"fontPromptBold fontSize14 ion-text-center\">\n          <ion-col>\n            <ion-text><br>({{thaiDate}})&nbsp;{{ DueDate | date:'dd/MM/yyyy':\"+0000\"}}</ion-text>\n          </ion-col>\n        </ion-row>\n      </ion-col>\n      <ion-col size=\"1.3\" class=\"myBorder2\" style=\"border-color: black;\">\n        <ion-row class=\"fontPromptRegular fontSize14 ion-text-center\">\n          <ion-col>\n            <ion-text>จำนวนทั้ง Order</ion-text>\n          </ion-col>\n        </ion-row>\n        <ion-row class=\"fontPromptBold fontSize14 ion-text-center\">\n          <ion-col>\n            <ion-text>{{ totalQty | number }}</ion-text>\n          </ion-col>\n        </ion-row>\n      </ion-col>\n\n      <ion-col size=\"1.3\" class=\"myBorder2\" style=\"border-color: black;\">\n        <ion-row class=\"fontPromptRegular fontSize14 ion-text-center\">\n          <ion-col>\n            <ion-text color=\"danger\">งานค้าง Order</ion-text>\n          </ion-col>\n        </ion-row>\n        <ion-row class=\"fontPromptBold fontSize14 ion-text-center\">\n          <ion-col>\n            <ion-text color=\"danger\">{{ Balance | number }}</ion-text>\n          </ion-col>\n        </ion-row>\n      </ion-col>\n      <ion-col size=\"1.5\" class=\"myBorder2\" style=\"border-color: black;\">\n        <ion-row class=\"fontPromptRegular fontSize14 ion-text-center\">\n          <ion-col>\n            <ion-text color=\"warning\">งานค้างซ่อม<br></ion-text>\n          </ion-col>\n        </ion-row>\n        <ion-row class=\"fontPromptBold fontSize14 ion-text-center\">\n          <ion-col>\n            <ion-text color=\"warning\"><br>{{ repairQty | number }}</ion-text>\n          </ion-col>\n        </ion-row>\n      </ion-col>\n\n      <ion-col size=\"1.5\" class=\"myBorder2\" style=\"border-color: black;\">\n        <ion-row class=\"fontPromptRegular fontSize14 ion-text-center\">\n          <ion-col>\n            <ion-text color=\"danger\">งานรอตรวจ<br></ion-text>\n          </ion-col>\n        </ion-row>\n        <ion-row class=\"fontPromptBold fontSize14 ion-text-center\">\n          <ion-col>\n            <ion-text color=\"danger\"><br>{{ qaQty - repairQty - finishQty| number }}</ion-text>\n          </ion-col>\n        </ion-row>\n      </ion-col>\n\n      <ion-col size=\"1.5\" class=\"myBorder2\" style=\"border-color: black;\">\n        <ion-row class=\"fontPromptRegular fontSize14 ion-text-center\">\n          <ion-col>\n            <ion-text color=\"primary\">ตรวจเสร็จแล้ว</ion-text>\n          </ion-col>\n        </ion-row>\n        <ion-row class=\"fontPromptBold fontSize14 ion-text-center\">\n          <ion-col>\n            <ion-text color=\"primary\">{{finishQty| number }}</ion-text>\n          </ion-col>\n        </ion-row>\n      </ion-col>\n\n      <ion-col size=\"1.4\" class=\"myBorder2\" style=\"border-color: black;\" >\n        <ion-row class=\"fontPromptRegular fontSize14 ion-text-center\">\n          <ion-col>\n            <ion-text color=\"warning\">ซ่อมสะสม<br></ion-text>\n          </ion-col>\n        </ion-row>\n        <ion-row class=\"fontPromptBold fontSize14 ion-text-center\">\n          <ion-col>\n            <ion-text color=\"warning\"><br>{{ totalRepairSum | number }}</ion-text>\n          </ion-col>\n        </ion-row>\n      </ion-col>\n\n      <ion-col size=\"1.3\" class=\"myBorder2\" style=\"border-color: black;\">\n        <ion-row class=\"fontPromptRegular fontSize14 ion-text-center\">\n          <ion-col>\n            <ion-text>Factory</ion-text>\n          </ion-col>\n        </ion-row>\n        <ion-row class=\"fontPromptBold fontSize14 ion-text-center\">\n          <ion-col class=\"center\">\n            \n              <ion-img src=\"{{avatar}}\" class=\"heigth50\"></ion-img>\n            \n            <!-- <ion-button *ngIf=\"dateLate > 3\" color=\"success\">{{ dateLate | number }} วัน</ion-button>\n            <ion-button *ngIf=\"dateLate >= 0 && dateLate <= 3\" color=\"warning\">{{ dateLate | number }} วัน</ion-button>\n            <ion-button *ngIf=\"dateLate < 0\" color=\"danger\">{{ dateLate | number }} วัน</ion-button> -->\n          </ion-col>\n        </ion-row>\n      </ion-col>\n      <!-- <ion-col size=\"2\" class=\"myBorder2\" style=\"border-color: black;\">\n        \n      </ion-col> -->\n    </ion-row>\n  </ion-grid>\n</ion-header>\n\n<ion-content>\n\n  <ion-grid>\n    <ion-row>\n      <ion-col size=\"3\" *ngFor=\"let i of orderItems\" [ngClass]=\"{'BorderRepair': i.SumRepair > 0 }\" (click)=\"openModalReportRepair(i)\">\n        <div>\n          <p class=\"myFont4\">&nbsp;&nbsp;{{i.ItemNo}}</p>\n          <ion-img [ngClass]=\"{'myImg': i.TotalQty == i.TotalFinish}\" src = \"{{ i.NewPict }}\"></ion-img>\n          <div class=\"pictFont1\">\n            {{ i.ProductCode }}\n          </div>\n          <div >\n              \n            <div class=\"fontPromptRegular fontSize14 \">จำนวนORDER : {{ i.TotalQty | number }}</div>\n            <div class=\"fontPromptRegular fontSize14 colorFontBlue\">ตรวจเสร็จแล้ว : {{ i.TotalFinish | number }}</div>\n            <div class=\"fontPromptRegular fontSize14 colorFontYellow\" *ngIf=\" i.TotalQty !== i.TotalFinish\">งานค้างซ่อม. &nbsp; : {{i.TotalRepair | number }}</div>\n            <div class=\"fontPromptRegular fontSize14 colorFontRed\" *ngIf=\" i.TotalQty !== i.TotalFinish\">งานรอตรวจ.  &nbsp; : {{ i.TotalQA - i.TotalFinish - i.TotalRepair| number }}</div>\n            <div class=\"fontPromptRegular fontSize16 colorFontRed\" >ค้างOrder  &nbsp; : {{ i.TotalQty - i.TotalFinish - i.TotalRepair - (i.TotalQA - i.TotalFinish - i.TotalRepair)| number }}</div>\n          </div>\n\n        </div>\n      </ion-col>\n    </ion-row>\n\n  </ion-grid>\n\n</ion-content>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.html":
/*!**********************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.html ***!
  \**********************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-title class=\"fontPromptBold fontSize20\">รายการซ่อม</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n\n\n    <div align=\"center\">\n      <ion-img src=\"{{product.NewPict}}\" style=\"width: 250px;\"></ion-img>\n      <h3 class=\" fontPromptRegular\">{{product.ProductCode}}</h3>\n    </div>\n\n\n    <ion-item color=\"light\" >\n\n\n      <ion-label class=\"fixed50 ion-text-center\">\n        <ion-text class=\"fontPromptRegular fontSize18\">\n         จำนวนงานของ Order :  {{product.TotalQty}}\n        </ion-text>\n      </ion-label>\n\n      <ion-label class=\"fixed50 ion-text-center\">\n        <ion-text class=\"fontPromptRegular fontSize18\">\n         ยอดซ่อมทั้งหมด : {{sum}} \n         <ion-text class=\"fontPromptBold fontSize20\" color=\"warning\">= {{(sum/product.TotalQty)*100 | number:'1.0-1'}}%</ion-text>\n        </ion-text>\n      </ion-label>\n\n \n\n    </ion-item>\n\n    \n      <ion-item color=\"warning\" >\n        <ion-label class=\"fixed15 ion-text-center\">\n          <ion-text class=\"fontPromptRegular fontSize16\">\n            วันที่ส่งซ่อม\n          </ion-text>\n        </ion-label>\n\n        <ion-label class=\"fixed30 ion-text-center\">\n          <ion-text class=\"fontPromptRegular fontSize16\">\n            เลขที่บิล QA\n          </ion-text>\n        </ion-label>\n\n        <ion-label class=\"fixed40 ion-text-center\">\n          <ion-text class=\"fontPromptRegular fontSize16\">\n            อาการที่ซ่อม\n          </ion-text>\n        </ion-label>\n\n        <ion-label class=\"fixed10 ion-text-center\">\n          <ion-text class=\"fontPromptRegular fontSize16\">\n            จำนวน\n          </ion-text>\n        </ion-label>\n      </ion-item>\n\n\n\n\n      <ion-item  *ngFor=\"let i of ReportRepairItem\">\n          <ion-label class=\"fixed15 ion-text-center\">\n            <ion-text class=\"fontPromptRegular fontSize16\">\n              {{i.repairDate | date:\"dd/MM/yy\":\"+0000\" }}<br>\n              <ion-text class=\"colorFontGray\">{{i.repairDate | date: 'HH:mm' : '+0' }} น.</ion-text>\n            </ion-text>\n          </ion-label>\n\n          <ion-label class=\"fixed30 ion-text-center\">\n            <ion-text class=\"fontPromptRegular fontSize16\">\n              {{i.qaDocNumber}}\n            </ion-text>\n          </ion-label>\n  \n          <ion-label class=\"fixed40 ion-text-center\">\n            <ion-text class=\"fontPromptRegular fontSize16\">\n              {{i.repairType}}-{{i.reasonType}}\n            </ion-text>\n          </ion-label>\n  \n          <ion-label class=\"fixed10 ion-text-center\">\n            <ion-text class=\"fontPromptRegular fontSize16\">\n              {{i.Qty}}\n            </ion-text>\n          </ion-label>\n      </ion-item>\n\n\n\n    <div align=\"center\">\n      <br><br><br>\n      <ion-button color=\"danger\" (click)=\"closeModal()\">&nbsp;&nbsp;&nbsp;&nbsp;ปิด&nbsp;&nbsp;&nbsp;&nbsp;</ion-button>\n    </div>\n\n</ion-content>\n");

/***/ }),

/***/ "./src/app/tabs/orderstatus/orderitems/orderitems-routing.module.ts":
/*!**************************************************************************!*\
  !*** ./src/app/tabs/orderstatus/orderitems/orderitems-routing.module.ts ***!
  \**************************************************************************/
/*! exports provided: OrderitemsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrderitemsPageRoutingModule", function() { return OrderitemsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _orderitems_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./orderitems.page */ "./src/app/tabs/orderstatus/orderitems/orderitems.page.ts");




const routes = [
    {
        path: '',
        component: _orderitems_page__WEBPACK_IMPORTED_MODULE_3__["OrderitemsPage"]
    }
];
let OrderitemsPageRoutingModule = class OrderitemsPageRoutingModule {
};
OrderitemsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], OrderitemsPageRoutingModule);



/***/ }),

/***/ "./src/app/tabs/orderstatus/orderitems/orderitems.module.ts":
/*!******************************************************************!*\
  !*** ./src/app/tabs/orderstatus/orderitems/orderitems.module.ts ***!
  \******************************************************************/
/*! exports provided: OrderitemsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrderitemsPageModule", function() { return OrderitemsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _orderitems_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./orderitems-routing.module */ "./src/app/tabs/orderstatus/orderitems/orderitems-routing.module.ts");
/* harmony import */ var _orderitems_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./orderitems.page */ "./src/app/tabs/orderstatus/orderitems/orderitems.page.ts");
/* harmony import */ var _popup_reportrepair_item_popup_reportrepair_item_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../popup-reportrepair-item/popup-reportrepair-item.page */ "./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.ts");








let OrderitemsPageModule = class OrderitemsPageModule {
};
OrderitemsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _orderitems_routing_module__WEBPACK_IMPORTED_MODULE_5__["OrderitemsPageRoutingModule"]
        ],
        declarations: [_orderitems_page__WEBPACK_IMPORTED_MODULE_6__["OrderitemsPage"], _popup_reportrepair_item_popup_reportrepair_item_page__WEBPACK_IMPORTED_MODULE_7__["PopupReportrepairItemPage"]],
        entryComponents: [_popup_reportrepair_item_popup_reportrepair_item_page__WEBPACK_IMPORTED_MODULE_7__["PopupReportrepairItemPage"]]
    })
], OrderitemsPageModule);



/***/ }),

/***/ "./src/app/tabs/orderstatus/orderitems/orderitems.page.scss":
/*!******************************************************************!*\
  !*** ./src/app/tabs/orderstatus/orderitems/orderitems.page.scss ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".welcome-card img {\n  max-height: 35vh;\n  overflow: hidden;\n}\n\n.myBorder1 {\n  border: solid 1px #ddd;\n}\n\n.myBorder1selected {\n  border: solid 3px #17fd0f;\n}\n\n.BorderRepair {\n  border: solid 3px #f4f802;\n}\n\n.myBorder2 {\n  border-top: solid 1px #ddd;\n  border-right: solid 1px #ddd;\n  border-bottom: solid 1px #ddd;\n}\n\n.myBorder1m {\n  border: solid 1px #ddd;\n  margin-top: 3px;\n}\n\n.myBorder2m {\n  border-top: solid 1px #ddd;\n  border-right: solid 1px #ddd;\n  border-bottom: solid 1px #ddd;\n  margin-top: 3px;\n}\n\n.myBorderRow1 {\n  border: solid 1px #ddd;\n  margin-top: 3px;\n}\n\n.myFont1 {\n  font-size: 8px;\n  padding-top: 5px;\n  padding-bottom: 5px;\n}\n\n.myFont2 {\n  font-size: 10px;\n  text-align: center;\n}\n\n.myFont3 {\n  font-size: 12px;\n  text-align: center;\n  color: blueviolet;\n}\n\n.myFont4 {\n  font-size: 10px;\n}\n\n.ordercartFont {\n  font-size: 10px;\n  text-align: center;\n  color: blueviolet;\n}\n\n.image-container {\n  min-height: 200px;\n  background-size: cover;\n}\n\n.pictFont1 {\n  font-size: 14px;\n  text-align: center;\n  background-color: #e9e8e8;\n}\n\n.pictFont2 {\n  font-size: 14px;\n  font-style: bold;\n  text-align: center;\n  color: red;\n  background-color: white;\n}\n\n.fontToolbar {\n  font-size: 18px;\n  text-align: center;\n  color: #2600ff;\n}\n\n.myImg {\n  -webkit-filter: brightness(50%);\n          filter: brightness(50%);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy90aGFuYXNhdGUvaW9uaWMvcWFTYWxlcy1WMy40L3NyYy9hcHAvdGFicy9vcmRlcnN0YXR1cy9vcmRlcml0ZW1zL29yZGVyaXRlbXMucGFnZS5zY3NzIiwic3JjL2FwcC90YWJzL29yZGVyc3RhdHVzL29yZGVyaXRlbXMvb3JkZXJpdGVtcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxnQkFBQTtFQUNBLGdCQUFBO0FDQ0o7O0FERUU7RUFDRSxzQkFBQTtBQ0NKOztBREVFO0VBQ0UseUJBQUE7QUNDSjs7QURFRTtFQUNFLHlCQUFBO0FDQ0o7O0FERUU7RUFDRSwwQkFBQTtFQUNBLDRCQUFBO0VBQ0EsNkJBQUE7QUNDSjs7QURFRTtFQUNFLHNCQUFBO0VBQ0EsZUFBQTtBQ0NKOztBREVFO0VBQ0UsMEJBQUE7RUFDQSw0QkFBQTtFQUNBLDZCQUFBO0VBQ0EsZUFBQTtBQ0NKOztBREVFO0VBQ0Usc0JBQUE7RUFDQSxlQUFBO0FDQ0o7O0FERUU7RUFDRSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtBQ0NKOztBREVFO0VBQ0UsZUFBQTtFQUNBLGtCQUFBO0FDQ0o7O0FERUU7RUFDRSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtBQ0NKOztBREVFO0VBQ0UsZUFBQTtBQ0NKOztBREVFO0VBQ0UsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7QUNDSjs7QURFRTtFQUNFLGlCQUFBO0VBQ0Esc0JBQUE7QUNDSjs7QURFRTtFQUNFLGVBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0FDQ0o7O0FERUU7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7RUFDQSx1QkFBQTtBQ0NKOztBREVFO0VBQ0UsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtBQ0NKOztBREVBO0VBQ0UsK0JBQUE7VUFBQSx1QkFBQTtBQ0NGIiwiZmlsZSI6InNyYy9hcHAvdGFicy9vcmRlcnN0YXR1cy9vcmRlcml0ZW1zL29yZGVyaXRlbXMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLndlbGNvbWUtY2FyZCBpbWcge1xyXG4gICAgbWF4LWhlaWdodDogMzV2aDtcclxuICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgfVxyXG4gIFxyXG4gIC5teUJvcmRlcjEge1xyXG4gICAgYm9yZGVyOiBzb2xpZCAxcHggI2RkZDtcclxuICB9XHJcbiAgXHJcbiAgLm15Qm9yZGVyMXNlbGVjdGVkIHtcclxuICAgIGJvcmRlcjogc29saWQgM3B4IHJnYigyMywgMjUzLCAxNSk7XHJcbiAgfVxyXG5cclxuICAuQm9yZGVyUmVwYWlyIHtcclxuICAgIGJvcmRlcjogc29saWQgM3B4IHJnYigyNDQsIDI0OCwgMik7XHJcbiAgfVxyXG4gIFxyXG4gIC5teUJvcmRlcjIge1xyXG4gICAgYm9yZGVyLXRvcDogc29saWQgMXB4ICNkZGQ7XHJcbiAgICBib3JkZXItcmlnaHQ6IHNvbGlkIDFweCAjZGRkO1xyXG4gICAgYm9yZGVyLWJvdHRvbTogc29saWQgMXB4ICNkZGQ7XHJcbiAgfVxyXG4gIFxyXG4gIC5teUJvcmRlcjFtIHtcclxuICAgIGJvcmRlcjogc29saWQgMXB4ICNkZGQ7XHJcbiAgICBtYXJnaW4tdG9wOiAzcHg7XHJcbiAgfVxyXG4gIFxyXG4gIC5teUJvcmRlcjJtIHtcclxuICAgIGJvcmRlci10b3A6IHNvbGlkIDFweCAjZGRkO1xyXG4gICAgYm9yZGVyLXJpZ2h0OiBzb2xpZCAxcHggI2RkZDtcclxuICAgIGJvcmRlci1ib3R0b206IHNvbGlkIDFweCAjZGRkO1xyXG4gICAgbWFyZ2luLXRvcDogM3B4O1xyXG4gIH1cclxuICBcclxuICAubXlCb3JkZXJSb3cxIHtcclxuICAgIGJvcmRlcjogc29saWQgMXB4ICNkZGQ7XHJcbiAgICBtYXJnaW4tdG9wOiAzcHg7XHJcbiAgfVxyXG4gIFxyXG4gIC5teUZvbnQxIHtcclxuICAgIGZvbnQtc2l6ZTogOHB4O1xyXG4gICAgcGFkZGluZy10b3A6IDVweDtcclxuICAgIHBhZGRpbmctYm90dG9tOiA1cHg7XHJcbiAgfVxyXG4gIFxyXG4gIC5teUZvbnQyIHtcclxuICAgIGZvbnQtc2l6ZTogMTBweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICB9XHJcbiAgXHJcbiAgLm15Rm9udDMge1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgY29sb3I6IGJsdWV2aW9sZXQ7XHJcbiAgfVxyXG5cclxuICAubXlGb250NCB7XHJcbiAgICBmb250LXNpemU6IDEwcHg7XHJcbiAgfVxyXG4gIFxyXG4gIC5vcmRlcmNhcnRGb250IHtcclxuICAgIGZvbnQtc2l6ZTogMTBweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGNvbG9yOiBibHVldmlvbGV0O1xyXG4gIH1cclxuICBcclxuICAuaW1hZ2UtY29udGFpbmVyIHtcclxuICAgIG1pbi1oZWlnaHQ6IDIwMHB4O1xyXG4gICAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcclxuICB9XHJcbiAgXHJcbiAgLnBpY3RGb250MSB7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMjMzLCAyMzIsIDIzMik7XHJcbiAgfVxyXG4gIFxyXG4gIC5waWN0Rm9udDIge1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgZm9udC1zdHlsZTogYm9sZDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGNvbG9yOiByZWQ7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMjU1LCAyNTUsIDI1NSk7XHJcbiAgfVxyXG5cclxuICAuZm9udFRvb2xiYXIge1xyXG4gICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgY29sb3I6ICMyNjAwZmY7XHJcbn1cclxuXHJcbi5teUltZyB7XHJcbiAgZmlsdGVyOiBicmlnaHRuZXNzKDUwJSk7XHJcbn0iLCIud2VsY29tZS1jYXJkIGltZyB7XG4gIG1heC1oZWlnaHQ6IDM1dmg7XG4gIG92ZXJmbG93OiBoaWRkZW47XG59XG5cbi5teUJvcmRlcjEge1xuICBib3JkZXI6IHNvbGlkIDFweCAjZGRkO1xufVxuXG4ubXlCb3JkZXIxc2VsZWN0ZWQge1xuICBib3JkZXI6IHNvbGlkIDNweCAjMTdmZDBmO1xufVxuXG4uQm9yZGVyUmVwYWlyIHtcbiAgYm9yZGVyOiBzb2xpZCAzcHggI2Y0ZjgwMjtcbn1cblxuLm15Qm9yZGVyMiB7XG4gIGJvcmRlci10b3A6IHNvbGlkIDFweCAjZGRkO1xuICBib3JkZXItcmlnaHQ6IHNvbGlkIDFweCAjZGRkO1xuICBib3JkZXItYm90dG9tOiBzb2xpZCAxcHggI2RkZDtcbn1cblxuLm15Qm9yZGVyMW0ge1xuICBib3JkZXI6IHNvbGlkIDFweCAjZGRkO1xuICBtYXJnaW4tdG9wOiAzcHg7XG59XG5cbi5teUJvcmRlcjJtIHtcbiAgYm9yZGVyLXRvcDogc29saWQgMXB4ICNkZGQ7XG4gIGJvcmRlci1yaWdodDogc29saWQgMXB4ICNkZGQ7XG4gIGJvcmRlci1ib3R0b206IHNvbGlkIDFweCAjZGRkO1xuICBtYXJnaW4tdG9wOiAzcHg7XG59XG5cbi5teUJvcmRlclJvdzEge1xuICBib3JkZXI6IHNvbGlkIDFweCAjZGRkO1xuICBtYXJnaW4tdG9wOiAzcHg7XG59XG5cbi5teUZvbnQxIHtcbiAgZm9udC1zaXplOiA4cHg7XG4gIHBhZGRpbmctdG9wOiA1cHg7XG4gIHBhZGRpbmctYm90dG9tOiA1cHg7XG59XG5cbi5teUZvbnQyIHtcbiAgZm9udC1zaXplOiAxMHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5teUZvbnQzIHtcbiAgZm9udC1zaXplOiAxMnB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGNvbG9yOiBibHVldmlvbGV0O1xufVxuXG4ubXlGb250NCB7XG4gIGZvbnQtc2l6ZTogMTBweDtcbn1cblxuLm9yZGVyY2FydEZvbnQge1xuICBmb250LXNpemU6IDEwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgY29sb3I6IGJsdWV2aW9sZXQ7XG59XG5cbi5pbWFnZS1jb250YWluZXIge1xuICBtaW4taGVpZ2h0OiAyMDBweDtcbiAgYmFja2dyb3VuZC1zaXplOiBjb3Zlcjtcbn1cblxuLnBpY3RGb250MSB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTllOGU4O1xufVxuXG4ucGljdEZvbnQyIHtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBmb250LXN0eWxlOiBib2xkO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGNvbG9yOiByZWQ7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xufVxuXG4uZm9udFRvb2xiYXIge1xuICBmb250LXNpemU6IDE4cHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgY29sb3I6ICMyNjAwZmY7XG59XG5cbi5teUltZyB7XG4gIGZpbHRlcjogYnJpZ2h0bmVzcyg1MCUpO1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/tabs/orderstatus/orderitems/orderitems.page.ts":
/*!****************************************************************!*\
  !*** ./src/app/tabs/orderstatus/orderitems/orderitems.page.ts ***!
  \****************************************************************/
/*! exports provided: OrderitemsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrderitemsPage", function() { return OrderitemsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_services_qasales_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/qasales.service */ "./src/app/services/qasales.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _popup_reportrepair_item_popup_reportrepair_item_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../popup-reportrepair-item/popup-reportrepair-item.page */ "./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.ts");







let OrderitemsPage = class OrderitemsPage {
    constructor(service, route, router, nav, loadingCtrl, modal) {
        this.service = service;
        this.route = route;
        this.router = router;
        this.nav = nav;
        this.loadingCtrl = loadingCtrl;
        this.modal = modal;
        this.orderNumber = this.route.snapshot.paramMap.get('orderNumber');
        this.thaiDate = this.route.snapshot.paramMap.get('thaiDate');
        this.DueDate = this.route.snapshot.paramMap.get('DueDate');
        this.totalQty = this.route.snapshot.paramMap.get('totalQty');
        this.finishQty = this.route.snapshot.paramMap.get('finishQty');
        this.totalRepairSum = this.route.snapshot.paramMap.get('totalRepairSum');
        this.dateLate = this.route.snapshot.paramMap.get('dateLate');
        this.repairQty = this.route.snapshot.paramMap.get('repairQty');
        this.qaQty = this.route.snapshot.paramMap.get('qaQty');
        this.avatar = this.route.snapshot.paramMap.get('avatar');
        this.fac = this.route.snapshot.paramMap.get('fac');
        this.Balance = this.route.snapshot.paramMap.get('Balance');
    }
    ngOnInit() {
        this.loadData();
    }
    loadData() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingCtrl.create({
                spinner: 'bubbles',
                message: 'กำลังโหลดข้อมูล...'
            });
            yield loading.present();
            // start loading
            this.sub = this.service.getOrderDetail(this.orderNumber).subscribe(data => {
                this.orderItems = data;
                // console.log(this.orderItems);
            }, (error) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                console.log(error);
                yield loading.dismiss();
            }), () => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                yield loading.dismiss();
            }));
        });
    }
    backToOrderStatus() {
        this.nav.navigateBack(['/tabs/orderstatus']);
    }
    gotoReportRepair() {
        this.nav.navigateForward(['/report-repair-byorder', {
                orderNumber: this.orderNumber
            }]);
    }
    openModalReportRepair(i) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            // console.log(i);
            if (i.SumRepair > 0) {
                const modal = yield this.modal.create({
                    component: _popup_reportrepair_item_popup_reportrepair_item_page__WEBPACK_IMPORTED_MODULE_5__["PopupReportrepairItemPage"],
                    componentProps: {
                        product: i,
                    }
                });
                modal.onWillDismiss().then(dataReturn => {
                    // console.log(dataReturn);
                });
                return yield modal.present();
            }
        });
    }
    ngOnDestroy() {
        this.sub.unsubscribe();
    }
};
OrderitemsPage.ctorParameters = () => [
    { type: src_app_services_qasales_service__WEBPACK_IMPORTED_MODULE_2__["QasalesService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] }
];
OrderitemsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-orderitems',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./orderitems.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/orderstatus/orderitems/orderitems.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./orderitems.page.scss */ "./src/app/tabs/orderstatus/orderitems/orderitems.page.scss")).default]
    })
], OrderitemsPage);



/***/ }),

/***/ "./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.scss":
/*!********************************************************************************************!*\
  !*** ./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.scss ***!
  \********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3RhYnMvb3JkZXJzdGF0dXMvcG9wdXAtcmVwb3J0cmVwYWlyLWl0ZW0vcG9wdXAtcmVwb3J0cmVwYWlyLWl0ZW0ucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.ts":
/*!******************************************************************************************!*\
  !*** ./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.ts ***!
  \******************************************************************************************/
/*! exports provided: PopupReportrepairItemPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PopupReportrepairItemPage", function() { return PopupReportrepairItemPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_services_qasales_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/qasales.service */ "./src/app/services/qasales.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");




let PopupReportrepairItemPage = class PopupReportrepairItemPage {
    constructor(service, loadingCtrl, modal) {
        this.service = service;
        this.loadingCtrl = loadingCtrl;
        this.modal = modal;
    }
    ngOnInit() {
        // console.log(this.product);
        this.loadData();
    }
    loadData() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingCtrl.create({
                spinner: 'dots',
                message: 'กำลังโหลดข้อมูล...'
            });
            yield loading.present();
            // start loading
            this.sub1 = this.service.reportRepairbyItem(this.product.OrderNumber, this.product.ItemNo).subscribe(data => {
                this.ReportRepairItem = data;
                // console.log(this.ReportRepairItem);
            }, (error) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                console.log(error);
                yield loading.dismiss();
            }), () => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                this.sum = 0;
                this.ReportRepairItem.forEach((item) => {
                    this.sum = this.sum + item.Qty;
                });
                yield loading.dismiss();
            }));
        });
    }
    closeModal() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            // console.log('sent back', this.selectQty);
            yield this.modal.dismiss();
        });
    }
    ngOnDestroy() {
        this.sub1.unsubscribe();
    }
};
PopupReportrepairItemPage.ctorParameters = () => [
    { type: src_app_services_qasales_service__WEBPACK_IMPORTED_MODULE_2__["QasalesService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"] }
];
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], PopupReportrepairItemPage.prototype, "product", void 0);
PopupReportrepairItemPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-popup-reportrepair-item',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./popup-reportrepair-item.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./popup-reportrepair-item.page.scss */ "./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.scss")).default]
    })
], PopupReportrepairItemPage);



/***/ })

}]);
//# sourceMappingURL=default~orderitems-orderitems-module~tabs-orderstatus-orderitems-orderitems-module-es2015.js.map