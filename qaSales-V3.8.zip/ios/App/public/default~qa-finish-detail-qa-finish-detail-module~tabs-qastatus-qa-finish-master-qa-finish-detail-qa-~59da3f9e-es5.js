function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~qa-finish-detail-qa-finish-detail-module~tabs-qastatus-qa-finish-master-qa-finish-detail-qa-~59da3f9e"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/qastatus/qa-finish-master/qa-finish-detail/qa-finish-detail.page.html":
  /*!**********************************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/qastatus/qa-finish-master/qa-finish-detail/qa-finish-detail.page.html ***!
    \**********************************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppTabsQastatusQaFinishMasterQaFinishDetailQaFinishDetailPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-button>\n        <ion-back-button></ion-back-button>\n      </ion-button>\n    </ion-buttons>\n    <ion-title class=\"fontPromptBold fontSize26\">ดูประวัติการตรวจงานเสร็จ</ion-title>\n  </ion-toolbar>\n\n\n  <ion-toolbar>\n    <ion-grid>\n      <ion-row >\n  \n        <ion-col size=\"4\" style=\"border: solid 1px; border-color: black;\">\n\n\n              <h6 class=\"fontPromptRegular ion-text-center\">OrderNumber</h6>\n              <h5 class=\"fontPromptBold ion-text-center\">{{OrderNumber}}</h5>\n\n              <h6 class=\"fontPromptRegular ion-text-center\">เลขที่บิล</h6>\n              <h5 class=\"fontPromptBold ion-text-center\">{{qaDoc}}</h5>\n    \n\n        </ion-col>\n\n\n        <ion-col size=\"2.5\" class=\"myBorder2\" style=\"border-color: black;\">\n          <ion-row class=\"fontPromptRegular fontSize17 ion-text-center\">\n            <ion-col>\n              <ion-text>ผู้ส่งงานตรวจเสร็จ<br></ion-text>\n            </ion-col>\n          </ion-row>\n          <ion-row class=\"fontPromptBold fontSize18 ion-text-center\">\n            <ion-col>\n              <ion-text ><br> {{fullName}}({{nickName}})</ion-text>\n            </ion-col>\n          </ion-row>\n        </ion-col>\n\n  \n        <ion-col size=\"1.5\" class=\"myBorder2\" style=\"border-color: black;\">\n          <ion-row class=\"fontPromptRegular fontSize17 ion-text-center\">\n            <ion-col>\n              <ion-text>Team<br><br></ion-text>\n            </ion-col>\n          </ion-row>\n          <ion-row class=\"fontPromptBold fontSize18 ion-text-center\">\n            <ion-col>\n              <ion-img src=\"{{avatar}}\" class=\"heigth70\"></ion-img>\n            </ion-col>\n          </ion-row>\n        </ion-col>\n\n        <ion-col size=\"2.5\" class=\"myBorder2\" style=\"border-color: black;\">\n          <ion-row class=\"fontPromptRegular fontSize17 ion-text-center\">\n            <ion-col>\n              <ion-text >วันที่ตรวจงานเสร็จ</ion-text>\n            </ion-col>\n          </ion-row>\n          <ion-row class=\"fontPromptBold fontSize17 ion-text-center\">\n            <ion-col>\n              <ion-text ><br>({{thaiDate}}) {{finishdate | date:'dd/MM/yyyy':\"+0000\"}}</ion-text>\n            </ion-col>\n          </ion-row>\n        </ion-col>\n  \n        <ion-col size=\"1.5\" class=\"myBorder2\" style=\"border-color: black;\">\n          <ion-row class=\"fontPromptRegular fontSize17 ion-text-center\">\n            <ion-col>\n              <ion-text>Factory</ion-text>\n            </ion-col>\n          </ion-row>\n          <ion-row class=\"fontPromptBold fontSize18 ion-text-center\">\n            <ion-col class=\"center\">\n              \n                <ion-img src=\"{{showIcon}}\" class=\"heigth70\"></ion-img>\n              \n  \n            </ion-col>\n          </ion-row>\n        </ion-col>\n      </ion-row>\n\n\n    </ion-grid>\n\n  </ion-toolbar>\n\n\n\n    <ion-grid>\n\n      <ion-item color=\"primary\">\n\n        <ion-label  fixed class=\"fixed10 align\">    \n          <ion-text>\n            <h2 class=\"fontPromptRegular align\">NO.</h2>\n          </ion-text>\n        </ion-label>\n    \n  \n    \n        <ion-label  fixed class=\"fixed30 align\">    \n          <h2 class=\"fontPromptRegular\">Picture</h2>\n        </ion-label>\n      \n        <ion-label class=\"align\">\n          <h2 class=\"fontPromptRegular\">ProductCode</h2>\n        </ion-label>\n      \n  \n        <ion-label class=\"align\">\n          <h2 class=\"fontPromptRegular\">ตรวจเสร็จแล้ว</h2>\n        </ion-label>\n\n      </ion-item>\n    \n    </ion-grid>\n\n</ion-header>\n\n<ion-content>\n\n  <ion-grid>\n\n  \n\n    <ion-item  *ngFor=\"let i of qaFinishDetail\">\n\n  \n      <ion-label  fixed class=\"fixed10 align\">    \n        <ion-text>\n          <h2 class=\"fontPromptRegular align\">{{i.finish_Item}}</h2>\n        </ion-text>\n      </ion-label>\n  \n\n  \n      <ion-label  fixed class=\"fixed30 align\">    \n        <img src=\"{{i.NewPict}}\">\n      </ion-label>\n    \n      <ion-label class=\" align\">\n        <h2 class=\"fontPromptRegular\">{{i.ProductCode}}</h2>\n      </ion-label>\n\n    \n\n      <ion-label class=\"align\" color=\"primary\">\n        <h2 class=\"fontPromptRegular\">{{i.TotalQtyFinish}}</h2>\n      </ion-label>\n \n    </ion-item>\n\n \n\n  </ion-grid>\n\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/tabs/qastatus/qa-finish-master/qa-finish-detail/qa-finish-detail-routing.module.ts":
  /*!****************************************************************************************************!*\
    !*** ./src/app/tabs/qastatus/qa-finish-master/qa-finish-detail/qa-finish-detail-routing.module.ts ***!
    \****************************************************************************************************/

  /*! exports provided: QaFinishDetailPageRoutingModule */

  /***/
  function srcAppTabsQastatusQaFinishMasterQaFinishDetailQaFinishDetailRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "QaFinishDetailPageRoutingModule", function () {
      return QaFinishDetailPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _qa_finish_detail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./qa-finish-detail.page */
    "./src/app/tabs/qastatus/qa-finish-master/qa-finish-detail/qa-finish-detail.page.ts");

    var routes = [{
      path: '',
      component: _qa_finish_detail_page__WEBPACK_IMPORTED_MODULE_3__["QaFinishDetailPage"]
    }];

    var QaFinishDetailPageRoutingModule = function QaFinishDetailPageRoutingModule() {
      _classCallCheck(this, QaFinishDetailPageRoutingModule);
    };

    QaFinishDetailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], QaFinishDetailPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/tabs/qastatus/qa-finish-master/qa-finish-detail/qa-finish-detail.module.ts":
  /*!********************************************************************************************!*\
    !*** ./src/app/tabs/qastatus/qa-finish-master/qa-finish-detail/qa-finish-detail.module.ts ***!
    \********************************************************************************************/

  /*! exports provided: QaFinishDetailPageModule */

  /***/
  function srcAppTabsQastatusQaFinishMasterQaFinishDetailQaFinishDetailModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "QaFinishDetailPageModule", function () {
      return QaFinishDetailPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _qa_finish_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./qa-finish-detail-routing.module */
    "./src/app/tabs/qastatus/qa-finish-master/qa-finish-detail/qa-finish-detail-routing.module.ts");
    /* harmony import */


    var _qa_finish_detail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./qa-finish-detail.page */
    "./src/app/tabs/qastatus/qa-finish-master/qa-finish-detail/qa-finish-detail.page.ts");

    var QaFinishDetailPageModule = function QaFinishDetailPageModule() {
      _classCallCheck(this, QaFinishDetailPageModule);
    };

    QaFinishDetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _qa_finish_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__["QaFinishDetailPageRoutingModule"]],
      declarations: [_qa_finish_detail_page__WEBPACK_IMPORTED_MODULE_6__["QaFinishDetailPage"]]
    })], QaFinishDetailPageModule);
    /***/
  },

  /***/
  "./src/app/tabs/qastatus/qa-finish-master/qa-finish-detail/qa-finish-detail.page.scss":
  /*!********************************************************************************************!*\
    !*** ./src/app/tabs/qastatus/qa-finish-master/qa-finish-detail/qa-finish-detail.page.scss ***!
    \********************************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppTabsQastatusQaFinishMasterQaFinishDetailQaFinishDetailPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".welcome-card img {\n  max-height: 35vh;\n  overflow: hidden;\n}\n\n.myBorder1 {\n  border: solid 1px #ddd;\n}\n\n.myBorder1selected {\n  border: solid 3px #17fd0f;\n}\n\n.myBorder2 {\n  border-top: solid 1px #ddd;\n  border-right: solid 1px #ddd;\n  border-bottom: solid 1px #ddd;\n}\n\n.myBorder1m {\n  border: solid 1px #ddd;\n  margin-top: 3px;\n}\n\n.myBorder2m {\n  border-top: solid 1px #ddd;\n  border-right: solid 1px #ddd;\n  border-bottom: solid 1px #ddd;\n  margin-top: 3px;\n}\n\n.myBorderRow1 {\n  border: solid 1px #ddd;\n  margin-top: 3px;\n}\n\n.myFont1 {\n  font-size: 8px;\n  padding-top: 5px;\n  padding-bottom: 5px;\n}\n\n.myFont2 {\n  font-size: 10px;\n  text-align: center;\n}\n\n.myFont3 {\n  font-size: 12px;\n  text-align: center;\n  color: blueviolet;\n}\n\n.myFont4 {\n  font-size: 10px;\n}\n\n.ordercartFont {\n  font-size: 10px;\n  text-align: center;\n  color: blueviolet;\n}\n\n.image-container {\n  min-height: 200px;\n  background-size: cover;\n}\n\n.pictFont1 {\n  font-size: 14px;\n  text-align: center;\n  background-color: #e9e8e8;\n}\n\n.pictFont2 {\n  font-size: 14px;\n  font-style: bold;\n  text-align: center;\n  color: red;\n  background-color: white;\n}\n\n.fontToolbar {\n  font-size: 18px;\n  text-align: center;\n  color: #2600ff;\n}\n\n.myImg {\n  -webkit-filter: brightness(50%);\n          filter: brightness(50%);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy90aGFuYXNhdGUvaW9uaWMvcWFTYWxlcy1WMy40L3NyYy9hcHAvdGFicy9xYXN0YXR1cy9xYS1maW5pc2gtbWFzdGVyL3FhLWZpbmlzaC1kZXRhaWwvcWEtZmluaXNoLWRldGFpbC5wYWdlLnNjc3MiLCJzcmMvYXBwL3RhYnMvcWFzdGF0dXMvcWEtZmluaXNoLW1hc3Rlci9xYS1maW5pc2gtZGV0YWlsL3FhLWZpbmlzaC1kZXRhaWwucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksZ0JBQUE7RUFDQSxnQkFBQTtBQ0NKOztBREVFO0VBQ0Usc0JBQUE7QUNDSjs7QURFRTtFQUNFLHlCQUFBO0FDQ0o7O0FERUU7RUFDRSwwQkFBQTtFQUNBLDRCQUFBO0VBQ0EsNkJBQUE7QUNDSjs7QURFRTtFQUNFLHNCQUFBO0VBQ0EsZUFBQTtBQ0NKOztBREVFO0VBQ0UsMEJBQUE7RUFDQSw0QkFBQTtFQUNBLDZCQUFBO0VBQ0EsZUFBQTtBQ0NKOztBREVFO0VBQ0Usc0JBQUE7RUFDQSxlQUFBO0FDQ0o7O0FERUU7RUFDRSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtBQ0NKOztBREVFO0VBQ0UsZUFBQTtFQUNBLGtCQUFBO0FDQ0o7O0FERUU7RUFDRSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtBQ0NKOztBREVFO0VBQ0UsZUFBQTtBQ0NKOztBREVFO0VBQ0UsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7QUNDSjs7QURFRTtFQUNFLGlCQUFBO0VBQ0Esc0JBQUE7QUNDSjs7QURFRTtFQUNFLGVBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0FDQ0o7O0FERUU7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7RUFDQSx1QkFBQTtBQ0NKOztBREVFO0VBQ0UsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtBQ0NKOztBREVBO0VBQ0UsK0JBQUE7VUFBQSx1QkFBQTtBQ0NGIiwiZmlsZSI6InNyYy9hcHAvdGFicy9xYXN0YXR1cy9xYS1maW5pc2gtbWFzdGVyL3FhLWZpbmlzaC1kZXRhaWwvcWEtZmluaXNoLWRldGFpbC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIud2VsY29tZS1jYXJkIGltZyB7XHJcbiAgICBtYXgtaGVpZ2h0OiAzNXZoO1xyXG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICB9XHJcbiAgXHJcbiAgLm15Qm9yZGVyMSB7XHJcbiAgICBib3JkZXI6IHNvbGlkIDFweCAjZGRkO1xyXG4gIH1cclxuICBcclxuICAubXlCb3JkZXIxc2VsZWN0ZWQge1xyXG4gICAgYm9yZGVyOiBzb2xpZCAzcHggcmdiKDIzLCAyNTMsIDE1KTtcclxuICB9XHJcbiAgXHJcbiAgLm15Qm9yZGVyMiB7XHJcbiAgICBib3JkZXItdG9wOiBzb2xpZCAxcHggI2RkZDtcclxuICAgIGJvcmRlci1yaWdodDogc29saWQgMXB4ICNkZGQ7XHJcbiAgICBib3JkZXItYm90dG9tOiBzb2xpZCAxcHggI2RkZDtcclxuICB9XHJcbiAgXHJcbiAgLm15Qm9yZGVyMW0ge1xyXG4gICAgYm9yZGVyOiBzb2xpZCAxcHggI2RkZDtcclxuICAgIG1hcmdpbi10b3A6IDNweDtcclxuICB9XHJcbiAgXHJcbiAgLm15Qm9yZGVyMm0ge1xyXG4gICAgYm9yZGVyLXRvcDogc29saWQgMXB4ICNkZGQ7XHJcbiAgICBib3JkZXItcmlnaHQ6IHNvbGlkIDFweCAjZGRkO1xyXG4gICAgYm9yZGVyLWJvdHRvbTogc29saWQgMXB4ICNkZGQ7XHJcbiAgICBtYXJnaW4tdG9wOiAzcHg7XHJcbiAgfVxyXG4gIFxyXG4gIC5teUJvcmRlclJvdzEge1xyXG4gICAgYm9yZGVyOiBzb2xpZCAxcHggI2RkZDtcclxuICAgIG1hcmdpbi10b3A6IDNweDtcclxuICB9XHJcbiAgXHJcbiAgLm15Rm9udDEge1xyXG4gICAgZm9udC1zaXplOiA4cHg7XHJcbiAgICBwYWRkaW5nLXRvcDogNXB4O1xyXG4gICAgcGFkZGluZy1ib3R0b206IDVweDtcclxuICB9XHJcbiAgXHJcbiAgLm15Rm9udDIge1xyXG4gICAgZm9udC1zaXplOiAxMHB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIH1cclxuICBcclxuICAubXlGb250MyB7XHJcbiAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBjb2xvcjogYmx1ZXZpb2xldDtcclxuICB9XHJcblxyXG4gIC5teUZvbnQ0IHtcclxuICAgIGZvbnQtc2l6ZTogMTBweDtcclxuICB9XHJcbiAgXHJcbiAgLm9yZGVyY2FydEZvbnQge1xyXG4gICAgZm9udC1zaXplOiAxMHB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgY29sb3I6IGJsdWV2aW9sZXQ7XHJcbiAgfVxyXG4gIFxyXG4gIC5pbWFnZS1jb250YWluZXIge1xyXG4gICAgbWluLWhlaWdodDogMjAwcHg7XHJcbiAgICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xyXG4gIH1cclxuICBcclxuICAucGljdEZvbnQxIHtcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHJnYigyMzMsIDIzMiwgMjMyKTtcclxuICB9XHJcbiAgXHJcbiAgLnBpY3RGb250MiB7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBmb250LXN0eWxlOiBib2xkO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgY29sb3I6IHJlZDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHJnYigyNTUsIDI1NSwgMjU1KTtcclxuICB9XHJcblxyXG4gIC5mb250VG9vbGJhciB7XHJcbiAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBjb2xvcjogIzI2MDBmZjtcclxufVxyXG5cclxuLm15SW1nIHtcclxuICBmaWx0ZXI6IGJyaWdodG5lc3MoNTAlKTtcclxufSIsIi53ZWxjb21lLWNhcmQgaW1nIHtcbiAgbWF4LWhlaWdodDogMzV2aDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLm15Qm9yZGVyMSB7XG4gIGJvcmRlcjogc29saWQgMXB4ICNkZGQ7XG59XG5cbi5teUJvcmRlcjFzZWxlY3RlZCB7XG4gIGJvcmRlcjogc29saWQgM3B4ICMxN2ZkMGY7XG59XG5cbi5teUJvcmRlcjIge1xuICBib3JkZXItdG9wOiBzb2xpZCAxcHggI2RkZDtcbiAgYm9yZGVyLXJpZ2h0OiBzb2xpZCAxcHggI2RkZDtcbiAgYm9yZGVyLWJvdHRvbTogc29saWQgMXB4ICNkZGQ7XG59XG5cbi5teUJvcmRlcjFtIHtcbiAgYm9yZGVyOiBzb2xpZCAxcHggI2RkZDtcbiAgbWFyZ2luLXRvcDogM3B4O1xufVxuXG4ubXlCb3JkZXIybSB7XG4gIGJvcmRlci10b3A6IHNvbGlkIDFweCAjZGRkO1xuICBib3JkZXItcmlnaHQ6IHNvbGlkIDFweCAjZGRkO1xuICBib3JkZXItYm90dG9tOiBzb2xpZCAxcHggI2RkZDtcbiAgbWFyZ2luLXRvcDogM3B4O1xufVxuXG4ubXlCb3JkZXJSb3cxIHtcbiAgYm9yZGVyOiBzb2xpZCAxcHggI2RkZDtcbiAgbWFyZ2luLXRvcDogM3B4O1xufVxuXG4ubXlGb250MSB7XG4gIGZvbnQtc2l6ZTogOHB4O1xuICBwYWRkaW5nLXRvcDogNXB4O1xuICBwYWRkaW5nLWJvdHRvbTogNXB4O1xufVxuXG4ubXlGb250MiB7XG4gIGZvbnQtc2l6ZTogMTBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4ubXlGb250MyB7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogYmx1ZXZpb2xldDtcbn1cblxuLm15Rm9udDQge1xuICBmb250LXNpemU6IDEwcHg7XG59XG5cbi5vcmRlcmNhcnRGb250IHtcbiAgZm9udC1zaXplOiAxMHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGNvbG9yOiBibHVldmlvbGV0O1xufVxuXG4uaW1hZ2UtY29udGFpbmVyIHtcbiAgbWluLWhlaWdodDogMjAwcHg7XG4gIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XG59XG5cbi5waWN0Rm9udDEge1xuICBmb250LXNpemU6IDE0cHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2U5ZThlODtcbn1cblxuLnBpY3RGb250MiB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgZm9udC1zdHlsZTogYm9sZDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogcmVkO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcbn1cblxuLmZvbnRUb29sYmFyIHtcbiAgZm9udC1zaXplOiAxOHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGNvbG9yOiAjMjYwMGZmO1xufVxuXG4ubXlJbWcge1xuICBmaWx0ZXI6IGJyaWdodG5lc3MoNTAlKTtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/tabs/qastatus/qa-finish-master/qa-finish-detail/qa-finish-detail.page.ts":
  /*!******************************************************************************************!*\
    !*** ./src/app/tabs/qastatus/qa-finish-master/qa-finish-detail/qa-finish-detail.page.ts ***!
    \******************************************************************************************/

  /*! exports provided: QaFinishDetailPage */

  /***/
  function srcAppTabsQastatusQaFinishMasterQaFinishDetailQaFinishDetailPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "QaFinishDetailPage", function () {
      return QaFinishDetailPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var src_app_services_qasales_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/app/services/qasales.service */
    "./src/app/services/qasales.service.ts");
    /* harmony import */


    var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/auth/auth.service */
    "./src/app/auth/auth.service.ts");

    var QaFinishDetailPage = /*#__PURE__*/function () {
      function QaFinishDetailPage(service, loadingCtrl, nav, route, router, authService) {
        _classCallCheck(this, QaFinishDetailPage);

        this.service = service;
        this.loadingCtrl = loadingCtrl;
        this.nav = nav;
        this.route = route;
        this.router = router;
        this.authService = authService;
        this.finishID = '';
        this.finishID = this.route.snapshot.paramMap.get('finishID');
        this.fullName = this.route.snapshot.paramMap.get('fullName');
        this.OrderNumber = this.route.snapshot.paramMap.get('OrderNumber');
        this.finishdate = this.route.snapshot.paramMap.get('date');
        this.thaiDate = this.route.snapshot.paramMap.get('thaiDate');
        this.showIcon = this.route.snapshot.paramMap.get('showIcon');
        this.avatar = this.route.snapshot.paramMap.get('avatar');
        this.qaDoc = this.route.snapshot.paramMap.get('qaDoc');
        this.nickName = this.route.snapshot.paramMap.get('nickName');
      }

      _createClass(QaFinishDetailPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.user = this.authService.getUserInfo();
        }
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.user = this.authService.getUserInfo();
          this.loaddata();

          if (!this.user) {
            this.router.navigateByUrl('/auth');
          } else {
            console.log(this.user[0].saleManager);
            this.loaddata();
          }
        }
      }, {
        key: "loaddata",
        value: function loaddata() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var _this = this;

            var loading;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return this.loadingCtrl.create({
                      spinner: 'bubbles',
                      message: 'กำลังโหลด'
                    });

                  case 2:
                    loading = _context3.sent;
                    _context3.next = 5;
                    return loading.present();

                  case 5:
                    this.sub = this.service.qaFinishDetail(this.finishID).subscribe(function (data) {
                      _this.qaFinishDetail = data; //  console.log(this.qaFinishDetail);
                    }, function (err) {
                      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                        return regeneratorRuntime.wrap(function _callee$(_context) {
                          while (1) {
                            switch (_context.prev = _context.next) {
                              case 0:
                                console.log(err);
                                _context.next = 3;
                                return loading.dismiss();

                              case 3:
                              case "end":
                                return _context.stop();
                            }
                          }
                        }, _callee);
                      }));
                    }, function () {
                      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
                        return regeneratorRuntime.wrap(function _callee2$(_context2) {
                          while (1) {
                            switch (_context2.prev = _context2.next) {
                              case 0:
                                _context2.next = 2;
                                return loading.dismiss();

                              case 2:
                              case "end":
                                return _context2.stop();
                            }
                          }
                        }, _callee2);
                      }));
                    });

                  case 6:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          this.sub.unsubscribe();
        }
      }]);

      return QaFinishDetailPage;
    }();

    QaFinishDetailPage.ctorParameters = function () {
      return [{
        type: src_app_services_qasales_service__WEBPACK_IMPORTED_MODULE_4__["QasalesService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }, {
        type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_5__["AuthService"]
      }];
    };

    QaFinishDetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-qa-finish-detail',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./qa-finish-detail.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/qastatus/qa-finish-master/qa-finish-detail/qa-finish-detail.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./qa-finish-detail.page.scss */
      "./src/app/tabs/qastatus/qa-finish-master/qa-finish-detail/qa-finish-detail.page.scss"))["default"]]
    })], QaFinishDetailPage);
    /***/
  }
}]);
//# sourceMappingURL=default~qa-finish-detail-qa-finish-detail-module~tabs-qastatus-qa-finish-master-qa-finish-detail-qa-~59da3f9e-es5.js.map