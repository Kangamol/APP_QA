function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~repair-finish-master-repair-finish-master-module~tabs-repairstatus-repair-finish-master-repa~6f6a5a8a"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/repairstatus/repair-finish-master/repair-finish-master.page.html":
  /*!*****************************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/repairstatus/repair-finish-master/repair-finish-master.page.html ***!
    \*****************************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppTabsRepairstatusRepairFinishMasterRepairFinishMasterPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header [translucent]=\"true\">\n\n  <ion-toolbar class=\"heigth70\">\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"backToQaStatusRepair()\">\n        <ion-icon name=\"arrow-back\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-title class=\" fontPromptBold\" >\n      <h1 class=\"fontsize30\">สถานะงานซ่อมเสร็จแล้ว</h1>\n    </ion-title>\n\n    <ion-buttons slot=\"end\" >\n      <ion-button (click)=\"onClickRefresh()\">\n        <ion-icon slot=\"icon-only\" name=\"refresh\" size=\"large\"></ion-icon>\n      </ion-button>\n      <ion-button (click)=\"showSearch()\">\n        <ion-icon slot=\"icon-only\" name=\"search\" size=\"large\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n\n  <ion-toolbar *ngIf=\"search\">\n    <ion-searchbar placeholder=\"Find OrderNumber\" debounce=\"500\" (ionChange)=\"getBill($event)\" ></ion-searchbar>\n  </ion-toolbar>\n\n  <!-- Login -->\n  <!-- <ion-toolbar>\n    <ion-grid>\n      <ion-row [ngClass]=\"{'backgroundPink': user[0].saleManager == '2', 'backgroundOrange': user[0].saleManager == '1,3'}\">\n      <ion-col size=\"1\">\n        <ion-avatar>\n          <img src=\"{{user[0].userPicture}}\">\n        </ion-avatar>\n        </ion-col>\n\n        <ion-col size=\"5\" class=\"padingTop\">\n          <ion-text  class=\"fontPromptBold fontSize20  ion-text-left \">&nbsp;Login : {{user[0].fullName}}({{user[0].nickName}})</ion-text>\n        </ion-col>\n\n        <ion-col size=\"5\" class=\"padingTop\">\n          <ion-text  class=\"fontPromptBold fontSize20 ion-text-left \">&nbsp;Team : {{user[0].saleTeam}}</ion-text>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n\n  </ion-toolbar> -->\n\n\n  <ion-toolbar>\n    <ion-grid>\n      <ion-row>\n        <ion-col>\n          <ion-item color=\"primary\">\n\n            <ion-col size=\"6\">\n              <ion-label class=\"ion-text-center\">    \n                <h1 class=\"fontPromptBold\">Description</h1> \n              </ion-label>\n            </ion-col>\n\n            <ion-col size=\"2\" class=\"ion-text-center\">\n              <ion-label >\n                <h2  class=\"fontPromptBold\">จำนวนที่<br>ส่งซ่อม</h2>\n              </ion-label>\n            </ion-col>\n\n            <ion-col size=\"2\" class=\"ion-text-center\">\n              <ion-label>\n                <h2  class=\"fontPromptBold\">จำนวนที่<br>QAรับแล้ว</h2>\n              </ion-label>\n            </ion-col>\n\n\n            <ion-col size=\"2\" class=\"ion-text-center\">\n              <ion-label >\n                <h2 class=\"fontPromptBold\">สถานะ</h2>\n              </ion-label>\n            </ion-col>\n          </ion-item>\n        </ion-col>\n      </ion-row>\n  \n      <!-- Summary -->\n      <ion-row>\n        <ion-col>\n\n          <ion-item color=\"light\">\n\n            <ion-col size=\"6\" class=\"ion-text-center\">\n              <ion-label><h1 class=\"fontPromptBold\">ยอดรวม :</h1></ion-label>\n            </ion-col>\n\n            <ion-col size=\"2\" class=\"ion-text-center\">\n              <ion-label>\n                <ion-text class=\"fontPromptBold fontSize18\">\n                  {{ sum1 | number }}\n                </ion-text>\n              </ion-label>\n            </ion-col>\n\n            <ion-col size=\"2\" class=\"ion-text-center\">\n              <ion-label color=\"primary\">\n                <ion-text class=\"fontPromptBold fontSize18\">\n                  {{ sum2 | number }}\n                </ion-text>\n              </ion-label>\n            </ion-col>\n\n          </ion-item>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid>\n    <ion-row>\n      <ion-col>\n        <ion-item *ngFor=\"let i of statusRepairMaster\" (click)=\"gotoRepairFinishDetail(i)\">\n\n          <ion-col size=\"1\">\n            <ion-thumbnail>\n              <img src=\"{{i.showIcon}}\">\n            </ion-thumbnail>\n          </ion-col>\n\n          <!-- Description -->\n          <ion-col size=\"4.8\" offset=\"0.2\">\n            <ion-label class=\" ion-text-left\">    \n              <ion-text>\n                <h2 class=\"fontPromptBold\">{{i.OrderNumber}}</h2>\n                <h3 class=\"fontPromptRegular colorFontGray\">เลขที่บิล QA&nbsp;&nbsp;: {{i.qaDocNumber}}</h3>\n                <h3 class=\"fontPromptRegular colorFontGray\">เลขที่บิลซ่อม : {{i.repairDocNumber}} </h3>\n                <h3 class=\"fontPromptRegular colorFontGray\">วันที่ส่งซ่อม : ({{i.receiveDateThai}}){{i.repairDate | date:\"dd/MM/yy\":\"+0000\"}} ({{i.repairDate | date: 'HH:mm' : '+0'}}น.)</h3>\n              </ion-text>\n          </ion-label>\n          </ion-col>\n\n          <ion-col size=\"2\" class=\"ion-text-center\">\n            <!-- จำนวนซ่อมทั้งหมด -->\n            <ion-label  >\n              <h2 class=\"fontPromptRegular\">{{i.TotalQty | number}}</h2>\n            </ion-label>\n          </ion-col>\n\n          <ion-col size=\"2\" class=\"ion-text-center\">\n            <!-- จำนวนซ่อมเสร็จแล้ว -->\n            <ion-label  color=\"primary\">\n              <h2 class=\"fontPromptRegular\">{{i.TotalFinishQty | number}}</h2>\n            </ion-label>\n          </ion-col>\n\n          <ion-col size=\"2\" class=\"ion-text-center\">\n            <ion-label>\n              <ion-button *ngIf=\"i.qaRepairStatus == '3' \" expand=\"block\" color=\"danger\">\n                <ion-text class=\"fontPromptRegular fontSize16\">\n                  {{i.statusShow}}\n                </ion-text>\n              </ion-button>\n            </ion-label>\n          </ion-col>\n\n        </ion-item>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n\n\n  \n</ion-content>";
    /***/
  },

  /***/
  "./src/app/tabs/repairstatus/repair-finish-master/repair-finish-master-routing.module.ts":
  /*!***********************************************************************************************!*\
    !*** ./src/app/tabs/repairstatus/repair-finish-master/repair-finish-master-routing.module.ts ***!
    \***********************************************************************************************/

  /*! exports provided: RepairFinishMasterPageRoutingModule */

  /***/
  function srcAppTabsRepairstatusRepairFinishMasterRepairFinishMasterRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "RepairFinishMasterPageRoutingModule", function () {
      return RepairFinishMasterPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _repair_finish_master_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./repair-finish-master.page */
    "./src/app/tabs/repairstatus/repair-finish-master/repair-finish-master.page.ts");

    var routes = [{
      path: '',
      component: _repair_finish_master_page__WEBPACK_IMPORTED_MODULE_3__["RepairFinishMasterPage"]
    }, {
      path: 'repair-finish-detail',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | repair-finish-detail-repair-finish-detail-module */
        "default~repair-finish-detail-repair-finish-detail-module~tabs-repairstatus-repair-finish-master-repa~a5e7e5ff").then(__webpack_require__.bind(null,
        /*! ./repair-finish-detail/repair-finish-detail.module */
        "./src/app/tabs/repairstatus/repair-finish-master/repair-finish-detail/repair-finish-detail.module.ts")).then(function (m) {
          return m.RepairFinishDetailPageModule;
        });
      }
    }];

    var RepairFinishMasterPageRoutingModule = function RepairFinishMasterPageRoutingModule() {
      _classCallCheck(this, RepairFinishMasterPageRoutingModule);
    };

    RepairFinishMasterPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], RepairFinishMasterPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/tabs/repairstatus/repair-finish-master/repair-finish-master.module.ts":
  /*!***************************************************************************************!*\
    !*** ./src/app/tabs/repairstatus/repair-finish-master/repair-finish-master.module.ts ***!
    \***************************************************************************************/

  /*! exports provided: RepairFinishMasterPageModule */

  /***/
  function srcAppTabsRepairstatusRepairFinishMasterRepairFinishMasterModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "RepairFinishMasterPageModule", function () {
      return RepairFinishMasterPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _repair_finish_master_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./repair-finish-master-routing.module */
    "./src/app/tabs/repairstatus/repair-finish-master/repair-finish-master-routing.module.ts");
    /* harmony import */


    var _repair_finish_master_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./repair-finish-master.page */
    "./src/app/tabs/repairstatus/repair-finish-master/repair-finish-master.page.ts");

    var RepairFinishMasterPageModule = function RepairFinishMasterPageModule() {
      _classCallCheck(this, RepairFinishMasterPageModule);
    };

    RepairFinishMasterPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _repair_finish_master_routing_module__WEBPACK_IMPORTED_MODULE_5__["RepairFinishMasterPageRoutingModule"]],
      declarations: [_repair_finish_master_page__WEBPACK_IMPORTED_MODULE_6__["RepairFinishMasterPage"]]
    })], RepairFinishMasterPageModule);
    /***/
  },

  /***/
  "./src/app/tabs/repairstatus/repair-finish-master/repair-finish-master.page.scss":
  /*!***************************************************************************************!*\
    !*** ./src/app/tabs/repairstatus/repair-finish-master/repair-finish-master.page.scss ***!
    \***************************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppTabsRepairstatusRepairFinishMasterRepairFinishMasterPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3RhYnMvcmVwYWlyc3RhdHVzL3JlcGFpci1maW5pc2gtbWFzdGVyL3JlcGFpci1maW5pc2gtbWFzdGVyLnBhZ2Uuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/tabs/repairstatus/repair-finish-master/repair-finish-master.page.ts":
  /*!*************************************************************************************!*\
    !*** ./src/app/tabs/repairstatus/repair-finish-master/repair-finish-master.page.ts ***!
    \*************************************************************************************/

  /*! exports provided: RepairFinishMasterPage */

  /***/
  function srcAppTabsRepairstatusRepairFinishMasterRepairFinishMasterPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "RepairFinishMasterPage", function () {
      return RepairFinishMasterPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/auth/auth.service */
    "./src/app/auth/auth.service.ts");
    /* harmony import */


    var src_app_services_qasales_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/app/services/qasales.service */
    "./src/app/services/qasales.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");

    var RepairFinishMasterPage = /*#__PURE__*/function () {
      function RepairFinishMasterPage(nav, service, authService, loadingCtrl, route) {
        _classCallCheck(this, RepairFinishMasterPage);

        this.nav = nav;
        this.service = service;
        this.authService = authService;
        this.loadingCtrl = loadingCtrl;
        this.route = route;
        this.search = false;
        this.sum1 = 0;
        this.sum2 = 0;
        this.sum3 = 0;
        this.sum4 = 0;
      }

      _createClass(RepairFinishMasterPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.user = this.authService.getUserInfo();
        }
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          // this.loaddata();
          this.search = false;
          this.user = this.authService.getUserInfo();

          if (!this.user) {
            this.route.navigateByUrl('/auth');
          } else {
            // console.log('Deaprtment = ', this.user[0].userDepartment);
            this.loaddata();
          }
        }
      }, {
        key: "loaddata",
        value: function loaddata() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var _this = this;

            var loading;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return this.loadingCtrl.create({
                      spinner: 'bubbles',
                      message: 'กำลังโหลด'
                    });

                  case 2:
                    loading = _context3.sent;
                    _context3.next = 5;
                    return loading.present();

                  case 5:
                    this.sub = this.service.repairFinishMaster(this.user[0].saleManager).subscribe(function (data) {
                      _this.statusRepairMaster = data; // console.log(this.statusRepairMaster);
                    }, function (error) {
                      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                        return regeneratorRuntime.wrap(function _callee$(_context) {
                          while (1) {
                            switch (_context.prev = _context.next) {
                              case 0:
                                console.log(error);
                                _context.next = 3;
                                return loading.dismiss();

                              case 3:
                              case "end":
                                return _context.stop();
                            }
                          }
                        }, _callee);
                      }));
                    }, function () {
                      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
                        var _this2 = this;

                        return regeneratorRuntime.wrap(function _callee2$(_context2) {
                          while (1) {
                            switch (_context2.prev = _context2.next) {
                              case 0:
                                this.sum1 = this.sum2 = this.sum3 = this.sum4 = 0;
                                this.statusRepairMaster.forEach(function (item) {
                                  _this2.sum1 = _this2.sum1 + item.TotalQty;
                                  _this2.sum2 = _this2.sum2 + item.TotalFinishQty;
                                  _this2.sum3 = _this2.sum3 + (item.TotalQty - item.TotalFinishQty);
                                  _this2.sum4 = _this2.sum4 + item.ToQa;
                                });
                                _context2.next = 4;
                                return loading.dismiss();

                              case 4:
                              case "end":
                                return _context2.stop();
                            }
                          }
                        }, _callee2, this);
                      }));
                    });

                  case 6:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "backToQaStatusRepair",
        value: function backToQaStatusRepair() {
          this.nav.navigateBack(['/tabs/repairstatus']);
        }
      }, {
        key: "gotoRepairFinishDetail",
        value: function gotoRepairFinishDetail(i) {
          this.nav.navigateForward(['/repairfinish-detail', {
            repairId: i.qaRepair_ID,
            OrderNumber: i.OrderNumber,
            qaDoc: i.qaDocNumber,
            repairDoc: i.repairDocNumber,
            fact: i.ProductionTeam,
            Repairstatus: i.qaRepairStatus,
            userReceive: i.userReceive,
            userSent: i.userSent,
            avatar: i.avatar,
            showIcon: i.showIcon,
            repairDate: i.repairDate,
            repairDateThai: i.repairDateThai,
            receiveDate: i.receiveDate,
            receiveDateThai: i.receiveDateThai,
            nickNameSent: i.nickNameSent,
            nickNameReceive: i.nickNameReceive
          }]);
        }
      }, {
        key: "onClickRefresh",
        value: function onClickRefresh() {
          this.loaddata();
        }
      }, {
        key: "getBill",
        value: function getBill(ev) {
          var _this3 = this;

          var val = ev.target.value;

          if (val && val.trim() !== '') {
            this.statusRepairMaster = this.statusRepairMaster.filter(function (bill) {
              return bill.OrderNumber.toLowerCase().indexOf(val.toLowerCase()) > -1;
            });
            this.sum1 = this.sum2 = this.sum3 = this.sum4 = 0;
            this.statusRepairMaster.forEach(function (item) {
              _this3.sum1 = _this3.sum1 + item.TotalQty;
              _this3.sum2 = _this3.sum2 + item.TotalFinishQty;
              _this3.sum3 = _this3.sum3 + (item.TotalQty - item.TotalFinishQty);
              _this3.sum4 = _this3.sum4 + item.ToQa;
            });
          } else {
            this.loaddata();
          }
        }
      }, {
        key: "showSearch",
        value: function showSearch() {
          this.search = !this.search;
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          this.sub.unsubscribe();
        }
      }]);

      return RepairFinishMasterPage;
    }();

    RepairFinishMasterPage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }, {
        type: src_app_services_qasales_service__WEBPACK_IMPORTED_MODULE_4__["QasalesService"]
      }, {
        type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]
      }];
    };

    RepairFinishMasterPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-repair-finish-master',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./repair-finish-master.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/repairstatus/repair-finish-master/repair-finish-master.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./repair-finish-master.page.scss */
      "./src/app/tabs/repairstatus/repair-finish-master/repair-finish-master.page.scss"))["default"]]
    })], RepairFinishMasterPage);
    /***/
  }
}]);
//# sourceMappingURL=default~repair-finish-master-repair-finish-master-module~tabs-repairstatus-repair-finish-master-repa~6f6a5a8a-es5.js.map