function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~receive-detail-receive-detail-module~tabs-receive-billfac-receive-detail-receive-detail-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/receive-billfac/receive-detail/receive-detail.page.html":
  /*!********************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/receive-billfac/receive-detail/receive-detail.page.html ***!
    \********************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppTabsReceiveBillfacReceiveDetailReceiveDetailPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title class=\"fontPromptBold fontSize26\">รับงานที่ผลิตเสร็จโอนมา QA</ion-title>\n\n    <!-- <ion-img [src]=\"showIcon\"></ion-img> -->\n  </ion-toolbar>\n\n\n  <ion-grid>\n    <ion-row >\n\n      <ion-col size=\"3.2\" style=\"border: solid 1px; border-color: black;\">\n        <h6 class=\"fontPromptRegular ion-text-center\">OrderNumber</h6>\n        <h5 class=\"fontPromptBold ion-text-center\">{{receivedata.OrderNumber}}</h5>\n\n        <h6 class=\"fontPromptRegular ion-text-center\">เลขที่บิล</h6>\n        <h5 class=\"fontPromptBold ion-text-center\">{{billQA}}</h5>\n      </ion-col>\n\n      <ion-col size=\"2.5\" class=\"myBorder2\" style=\"border-color: black;\">\n        <ion-row class=\"fontPromptRegular fontSize17 ion-text-center\">\n          <ion-col>\n            <ion-text>ผู้โอนงาน<br></ion-text>\n          </ion-col>\n        </ion-row>\n        <ion-row class=\"fontPromptBold fontSize18 ion-text-center\">\n          <ion-col>\n            <ion-text><br>{{userSent}}({{nickNameSent}})</ion-text>\n          </ion-col>\n        </ion-row>\n      </ion-col>\n\n      <ion-col size=\"2.1\" class=\"myBorder2\" style=\"border-color: black;\">\n        <ion-row class=\"fontPromptRegular fontSize17 ion-text-center\">\n          <ion-col>\n            <ion-text>โอนมาที่ Team<br></ion-text>\n          </ion-col>\n        </ion-row>\n        <ion-row class=\"fontPromptBold fontSize18 ion-text-center\">\n          <ion-col>\n            <ion-img src=\"{{saleTeam}}\" class=\"heigth70\"></ion-img>\n          </ion-col>\n        </ion-row>\n      </ion-col>\n      <ion-col size=\"2.5\" class=\"myBorder2\" style=\"border-color: black;\">\n        <ion-row class=\"fontPromptRegular fontSize17 ion-text-center\">\n          <ion-col>\n            <ion-text >วันที่ฝ่ายผลิต<br>โอนงาน</ion-text>\n          </ion-col>\n        </ion-row>\n        <ion-row class=\"fontPromptBold fontSize17 ion-text-center\">\n          <ion-col>\n            \n            <h6  class=\"colorFontGray\">เวลา : {{dateReceive |  date: 'HH:mm' : '+0'}} น.</h6>\n            <h6 >({{thaiDate}}) {{dateReceive | date:'dd/MM/yyyy':\"+0000\"}}</h6>\n           \n          </ion-col>\n        </ion-row>\n      </ion-col>\n\n      <ion-col size=\"1.7\" class=\"myBorder2\" style=\"border-color: black;\">\n        <ion-row class=\"fontPromptRegular fontSize17 ion-text-center\">\n          <ion-col>\n            <ion-text>Factory</ion-text>\n          </ion-col>\n        </ion-row>\n        <ion-row class=\"fontPromptBold fontSize18 ion-text-center\">\n          <ion-col class=\"center\">\n            \n              <ion-img src=\"{{showIcon}}\" class=\"heigth70\"></ion-img>\n            \n\n          </ion-col>\n        </ion-row>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n  <ion-grid>\n    <ion-row>\n      <ion-col>\n        <ion-item class=\"align\" color=\"danger\">\n\n          <ion-col size=\"1\">\n            <ion-label>\n              <ion-text class=\"fontPromptMedium fontSize20\">\n                No.\n              </ion-text>\n            </ion-label>\n          </ion-col>\n\n          <ion-col size=\"3\">\n            <ion-label>\n              <ion-text class=\"fontPromptMedium fontSize20\">\n                Picture\n              </ion-text>\n            </ion-label>\n          </ion-col>\n\n          <ion-col size=\"6\">\n            <ion-label>\n              <ion-text class=\"fontPromptMedium fontSize20\">\n                ProductCode\n              </ion-text>\n            </ion-label>\n          </ion-col>\n\n          <ion-col size=\"2\">\n            <ion-label>\n              <ion-text class=\"fontPromptMedium\">\n                จำนวนที่<br>ฝ่ายผลิตโอนมา\n              </ion-text>\n            </ion-label>\n          </ion-col>\n\n        </ion-item>\n      </ion-col>\n    </ion-row>\n\n    <ion-row>\n      <ion-col>\n        <ion-item color=\"light\">\n          <ion-col size=\"6\" offset=\"4\">\n            <ion-label class=\"ion-text-center\">\n              <ion-text class=\"fontPromptMedium fontSize24\">\n                ยอดรวมของบิล &nbsp;&nbsp;:\n              </ion-text>\n            </ion-label>\n          </ion-col>\n\n          <ion-label class=\"ion-text-center\">\n            <ion-text class=\"fontPromptMedium fontSize26\">\n              {{sum1}}\n            </ion-text>\n          </ion-label>\n        </ion-item>\n      </ion-col>\n    </ion-row>\n\n  </ion-grid>\n\n\n</ion-header>\n\n<ion-content>\n\n  <ion-grid>\n    <ion-row>\n      <ion-col>\n        <ion-item class=\"align\" *ngFor=\"let i of qaReceiveDetail\">\n\n          <ion-col size=\"1\">\n            <ion-label>\n              <ion-text class=\"fontPromptRegular\">\n                {{i.bill_Item}}\n              </ion-text>\n            </ion-label>\n          </ion-col>\n\n          <ion-col size=\"3\">\n            <ion-label>\n              <img src=\"{{i.NewPict}}\">\n            </ion-label>\n          </ion-col>\n\n          <ion-col size=\"6\">\n            <ion-label>\n              <ion-text class=\"fontPromptRegular\">\n                {{i.ProductCode}}\n              </ion-text>\n            </ion-label>\n          </ion-col>\n\n          <ion-col size=\"2\">\n            <ion-label>\n              <ion-text class=\"fontPromptRegular\">\n                {{i.Qty}}\n              </ion-text>\n            </ion-label>\n          </ion-col>\n\n        </ion-item>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n  <!-- <ion-list >\n\n\n    <ion-item class=\"align\" *ngFor=\"let i of qaReceiveDetail\">\n\n      <ion-label  class=\"fixed10\">\n        <ion-text >\n          <h1 class=\"fontPromptRegular\">{{i.bill_Item}}</h1>\n\n        </ion-text>\n      </ion-label>\n        \n      <ion-label class=\"fixed25\">     \n      \n           <img src=\"{{i.NewPict}}\">\n        \n      </ion-label>     \n        \n      <ion-label  class=\"fixed40\">\n        <ion-text >\n          <h1 class=\"fontPromptRegular\"> {{i.ProductCode}} </h1>\n        </ion-text>\n      </ion-label>\n        \n      <ion-label class=\"fixed20\">\n        <ion-text>\n          <h1 class=\"fontPromptBold\">{{i.Qty}}</h1>\n        </ion-text>\n      </ion-label>\n\n    </ion-item>\n\n  </ion-list> -->\n\n</ion-content>\n\n<ion-footer>\n  <ion-row> \n\n     <ion-col size-md=\"2\" offset-md=\"2\">\n       <ion-button color=\"success\" expand=\"block\" (click)=\"onConfirm()\">ยืนยันรับงาน</ion-button>\n     </ion-col>\n\n\n     <ion-col size=\"2\" offset-md=\"4\">\n      <ion-button color=\"danger\" expand=\"block\"  routerLink=\"/tabs/receive-billfac\" routerDirection=\"back\">กลับ</ion-button>\n    </ion-col>\n\n    <ion-col size=\"2\">\n      <br>\n    </ion-col>\n\n  </ion-row>\n\n</ion-footer>";
    /***/
  },

  /***/
  "./src/app/tabs/receive-billfac/receive-detail/receive-detail-routing.module.ts":
  /*!**************************************************************************************!*\
    !*** ./src/app/tabs/receive-billfac/receive-detail/receive-detail-routing.module.ts ***!
    \**************************************************************************************/

  /*! exports provided: ReceiveDetailPageRoutingModule */

  /***/
  function srcAppTabsReceiveBillfacReceiveDetailReceiveDetailRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ReceiveDetailPageRoutingModule", function () {
      return ReceiveDetailPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _receive_detail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./receive-detail.page */
    "./src/app/tabs/receive-billfac/receive-detail/receive-detail.page.ts");

    var routes = [{
      path: '',
      component: _receive_detail_page__WEBPACK_IMPORTED_MODULE_3__["ReceiveDetailPage"]
    }];

    var ReceiveDetailPageRoutingModule = function ReceiveDetailPageRoutingModule() {
      _classCallCheck(this, ReceiveDetailPageRoutingModule);
    };

    ReceiveDetailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], ReceiveDetailPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/tabs/receive-billfac/receive-detail/receive-detail.module.ts":
  /*!******************************************************************************!*\
    !*** ./src/app/tabs/receive-billfac/receive-detail/receive-detail.module.ts ***!
    \******************************************************************************/

  /*! exports provided: ReceiveDetailPageModule */

  /***/
  function srcAppTabsReceiveBillfacReceiveDetailReceiveDetailModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ReceiveDetailPageModule", function () {
      return ReceiveDetailPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _receive_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./receive-detail-routing.module */
    "./src/app/tabs/receive-billfac/receive-detail/receive-detail-routing.module.ts");
    /* harmony import */


    var _receive_detail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./receive-detail.page */
    "./src/app/tabs/receive-billfac/receive-detail/receive-detail.page.ts");

    var ReceiveDetailPageModule = function ReceiveDetailPageModule() {
      _classCallCheck(this, ReceiveDetailPageModule);
    };

    ReceiveDetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _receive_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__["ReceiveDetailPageRoutingModule"]],
      declarations: [_receive_detail_page__WEBPACK_IMPORTED_MODULE_6__["ReceiveDetailPage"]]
    })], ReceiveDetailPageModule);
    /***/
  },

  /***/
  "./src/app/tabs/receive-billfac/receive-detail/receive-detail.page.scss":
  /*!******************************************************************************!*\
    !*** ./src/app/tabs/receive-billfac/receive-detail/receive-detail.page.scss ***!
    \******************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppTabsReceiveBillfacReceiveDetailReceiveDetailPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".welcome-card img {\n  max-height: 35vh;\n  overflow: hidden;\n}\n\n.myBorder1 {\n  border: solid 1px #ddd;\n}\n\n.myBorder1selected {\n  border: solid 3px #17fd0f;\n}\n\n.myBorder2 {\n  border-top: solid 1px #ddd;\n  border-right: solid 1px #ddd;\n  border-bottom: solid 1px #ddd;\n}\n\n.myBorder1m {\n  border: solid 1px #ddd;\n  margin-top: 3px;\n}\n\n.myBorder2m {\n  border-top: solid 1px #ddd;\n  border-right: solid 1px #ddd;\n  border-bottom: solid 1px #ddd;\n  margin-top: 3px;\n}\n\n.myBorderRow1 {\n  border: solid 1px #ddd;\n  margin-top: 3px;\n}\n\n.myFont1 {\n  font-size: 8px;\n  padding-top: 5px;\n  padding-bottom: 5px;\n}\n\n.myFont2 {\n  font-size: 10px;\n  text-align: center;\n}\n\n.myFont3 {\n  font-size: 12px;\n  text-align: center;\n  color: blueviolet;\n}\n\n.myFont4 {\n  font-size: 10px;\n}\n\n.ordercartFont {\n  font-size: 10px;\n  text-align: center;\n  color: blueviolet;\n}\n\n.image-container {\n  min-height: 200px;\n  background-size: cover;\n}\n\n.pictFont1 {\n  font-size: 14px;\n  text-align: center;\n  background-color: #e9e8e8;\n}\n\n.pictFont2 {\n  font-size: 14px;\n  font-style: bold;\n  text-align: center;\n  color: red;\n  background-color: white;\n}\n\n.fontToolbar {\n  font-size: 18px;\n  text-align: center;\n  color: #2600ff;\n}\n\n.myImg {\n  -webkit-filter: brightness(50%);\n          filter: brightness(50%);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy90aGFuYXNhdGUvaW9uaWMvcWFTYWxlcy1WMy40L3NyYy9hcHAvdGFicy9yZWNlaXZlLWJpbGxmYWMvcmVjZWl2ZS1kZXRhaWwvcmVjZWl2ZS1kZXRhaWwucGFnZS5zY3NzIiwic3JjL2FwcC90YWJzL3JlY2VpdmUtYmlsbGZhYy9yZWNlaXZlLWRldGFpbC9yZWNlaXZlLWRldGFpbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxnQkFBQTtFQUNBLGdCQUFBO0FDQ0o7O0FERUU7RUFDRSxzQkFBQTtBQ0NKOztBREVFO0VBQ0UseUJBQUE7QUNDSjs7QURFRTtFQUNFLDBCQUFBO0VBQ0EsNEJBQUE7RUFDQSw2QkFBQTtBQ0NKOztBREVFO0VBQ0Usc0JBQUE7RUFDQSxlQUFBO0FDQ0o7O0FERUU7RUFDRSwwQkFBQTtFQUNBLDRCQUFBO0VBQ0EsNkJBQUE7RUFDQSxlQUFBO0FDQ0o7O0FERUU7RUFDRSxzQkFBQTtFQUNBLGVBQUE7QUNDSjs7QURFRTtFQUNFLGNBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0FDQ0o7O0FERUU7RUFDRSxlQUFBO0VBQ0Esa0JBQUE7QUNDSjs7QURFRTtFQUNFLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0FDQ0o7O0FERUU7RUFDRSxlQUFBO0FDQ0o7O0FERUU7RUFDRSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtBQ0NKOztBREVFO0VBQ0UsaUJBQUE7RUFDQSxzQkFBQTtBQ0NKOztBREVFO0VBQ0UsZUFBQTtFQUNBLGtCQUFBO0VBQ0EseUJBQUE7QUNDSjs7QURFRTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLHVCQUFBO0FDQ0o7O0FERUU7RUFDRSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0FDQ0o7O0FERUE7RUFDRSwrQkFBQTtVQUFBLHVCQUFBO0FDQ0YiLCJmaWxlIjoic3JjL2FwcC90YWJzL3JlY2VpdmUtYmlsbGZhYy9yZWNlaXZlLWRldGFpbC9yZWNlaXZlLWRldGFpbC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIud2VsY29tZS1jYXJkIGltZyB7XHJcbiAgICBtYXgtaGVpZ2h0OiAzNXZoO1xyXG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICB9XHJcbiAgXHJcbiAgLm15Qm9yZGVyMSB7XHJcbiAgICBib3JkZXI6IHNvbGlkIDFweCAjZGRkO1xyXG4gIH1cclxuICBcclxuICAubXlCb3JkZXIxc2VsZWN0ZWQge1xyXG4gICAgYm9yZGVyOiBzb2xpZCAzcHggcmdiKDIzLCAyNTMsIDE1KTtcclxuICB9XHJcbiAgXHJcbiAgLm15Qm9yZGVyMiB7XHJcbiAgICBib3JkZXItdG9wOiBzb2xpZCAxcHggI2RkZDtcclxuICAgIGJvcmRlci1yaWdodDogc29saWQgMXB4ICNkZGQ7XHJcbiAgICBib3JkZXItYm90dG9tOiBzb2xpZCAxcHggI2RkZDtcclxuICB9XHJcbiAgXHJcbiAgLm15Qm9yZGVyMW0ge1xyXG4gICAgYm9yZGVyOiBzb2xpZCAxcHggI2RkZDtcclxuICAgIG1hcmdpbi10b3A6IDNweDtcclxuICB9XHJcbiAgXHJcbiAgLm15Qm9yZGVyMm0ge1xyXG4gICAgYm9yZGVyLXRvcDogc29saWQgMXB4ICNkZGQ7XHJcbiAgICBib3JkZXItcmlnaHQ6IHNvbGlkIDFweCAjZGRkO1xyXG4gICAgYm9yZGVyLWJvdHRvbTogc29saWQgMXB4ICNkZGQ7XHJcbiAgICBtYXJnaW4tdG9wOiAzcHg7XHJcbiAgfVxyXG4gIFxyXG4gIC5teUJvcmRlclJvdzEge1xyXG4gICAgYm9yZGVyOiBzb2xpZCAxcHggI2RkZDtcclxuICAgIG1hcmdpbi10b3A6IDNweDtcclxuICB9XHJcbiAgXHJcbiAgLm15Rm9udDEge1xyXG4gICAgZm9udC1zaXplOiA4cHg7XHJcbiAgICBwYWRkaW5nLXRvcDogNXB4O1xyXG4gICAgcGFkZGluZy1ib3R0b206IDVweDtcclxuICB9XHJcbiAgXHJcbiAgLm15Rm9udDIge1xyXG4gICAgZm9udC1zaXplOiAxMHB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIH1cclxuICBcclxuICAubXlGb250MyB7XHJcbiAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBjb2xvcjogYmx1ZXZpb2xldDtcclxuICB9XHJcblxyXG4gIC5teUZvbnQ0IHtcclxuICAgIGZvbnQtc2l6ZTogMTBweDtcclxuICB9XHJcbiAgXHJcbiAgLm9yZGVyY2FydEZvbnQge1xyXG4gICAgZm9udC1zaXplOiAxMHB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgY29sb3I6IGJsdWV2aW9sZXQ7XHJcbiAgfVxyXG4gIFxyXG4gIC5pbWFnZS1jb250YWluZXIge1xyXG4gICAgbWluLWhlaWdodDogMjAwcHg7XHJcbiAgICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xyXG4gIH1cclxuICBcclxuICAucGljdEZvbnQxIHtcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHJnYigyMzMsIDIzMiwgMjMyKTtcclxuICB9XHJcbiAgXHJcbiAgLnBpY3RGb250MiB7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBmb250LXN0eWxlOiBib2xkO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgY29sb3I6IHJlZDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHJnYigyNTUsIDI1NSwgMjU1KTtcclxuICB9XHJcblxyXG4gIC5mb250VG9vbGJhciB7XHJcbiAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBjb2xvcjogIzI2MDBmZjtcclxufVxyXG5cclxuLm15SW1nIHtcclxuICBmaWx0ZXI6IGJyaWdodG5lc3MoNTAlKTtcclxufSIsIi53ZWxjb21lLWNhcmQgaW1nIHtcbiAgbWF4LWhlaWdodDogMzV2aDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLm15Qm9yZGVyMSB7XG4gIGJvcmRlcjogc29saWQgMXB4ICNkZGQ7XG59XG5cbi5teUJvcmRlcjFzZWxlY3RlZCB7XG4gIGJvcmRlcjogc29saWQgM3B4ICMxN2ZkMGY7XG59XG5cbi5teUJvcmRlcjIge1xuICBib3JkZXItdG9wOiBzb2xpZCAxcHggI2RkZDtcbiAgYm9yZGVyLXJpZ2h0OiBzb2xpZCAxcHggI2RkZDtcbiAgYm9yZGVyLWJvdHRvbTogc29saWQgMXB4ICNkZGQ7XG59XG5cbi5teUJvcmRlcjFtIHtcbiAgYm9yZGVyOiBzb2xpZCAxcHggI2RkZDtcbiAgbWFyZ2luLXRvcDogM3B4O1xufVxuXG4ubXlCb3JkZXIybSB7XG4gIGJvcmRlci10b3A6IHNvbGlkIDFweCAjZGRkO1xuICBib3JkZXItcmlnaHQ6IHNvbGlkIDFweCAjZGRkO1xuICBib3JkZXItYm90dG9tOiBzb2xpZCAxcHggI2RkZDtcbiAgbWFyZ2luLXRvcDogM3B4O1xufVxuXG4ubXlCb3JkZXJSb3cxIHtcbiAgYm9yZGVyOiBzb2xpZCAxcHggI2RkZDtcbiAgbWFyZ2luLXRvcDogM3B4O1xufVxuXG4ubXlGb250MSB7XG4gIGZvbnQtc2l6ZTogOHB4O1xuICBwYWRkaW5nLXRvcDogNXB4O1xuICBwYWRkaW5nLWJvdHRvbTogNXB4O1xufVxuXG4ubXlGb250MiB7XG4gIGZvbnQtc2l6ZTogMTBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4ubXlGb250MyB7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogYmx1ZXZpb2xldDtcbn1cblxuLm15Rm9udDQge1xuICBmb250LXNpemU6IDEwcHg7XG59XG5cbi5vcmRlcmNhcnRGb250IHtcbiAgZm9udC1zaXplOiAxMHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGNvbG9yOiBibHVldmlvbGV0O1xufVxuXG4uaW1hZ2UtY29udGFpbmVyIHtcbiAgbWluLWhlaWdodDogMjAwcHg7XG4gIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XG59XG5cbi5waWN0Rm9udDEge1xuICBmb250LXNpemU6IDE0cHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2U5ZThlODtcbn1cblxuLnBpY3RGb250MiB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgZm9udC1zdHlsZTogYm9sZDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogcmVkO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcbn1cblxuLmZvbnRUb29sYmFyIHtcbiAgZm9udC1zaXplOiAxOHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGNvbG9yOiAjMjYwMGZmO1xufVxuXG4ubXlJbWcge1xuICBmaWx0ZXI6IGJyaWdodG5lc3MoNTAlKTtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/tabs/receive-billfac/receive-detail/receive-detail.page.ts":
  /*!****************************************************************************!*\
    !*** ./src/app/tabs/receive-billfac/receive-detail/receive-detail.page.ts ***!
    \****************************************************************************/

  /*! exports provided: ReceiveDetailPage */

  /***/
  function srcAppTabsReceiveBillfacReceiveDetailReceiveDetailPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ReceiveDetailPage", function () {
      return ReceiveDetailPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _services_qasales_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./../../../services/qasales.service */
    "./src/app/services/qasales.service.ts");
    /* harmony import */


    var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/auth/auth.service */
    "./src/app/auth/auth.service.ts");
    /* harmony import */


    var _ionic_native_fingerprint_aio_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @ionic-native/fingerprint-aio/ngx */
    "./node_modules/@ionic-native/fingerprint-aio/__ivy_ngcc__/ngx/index.js");

    var ReceiveDetailPage = /*#__PURE__*/function () {
      function ReceiveDetailPage(nav, route, service, loadingCtrl, authService, faio) {
        _classCallCheck(this, ReceiveDetailPage);

        this.nav = nav;
        this.route = route;
        this.service = service;
        this.loadingCtrl = loadingCtrl;
        this.authService = authService;
        this.faio = faio;
        this.isSub1 = false;
        this.isSub2 = false;
        this.isSub3 = false;
        this.sum1 = 0;
        this.receivedata = {
          OrderNumber: '',
          billId: ''
        };
        this.fact = '';
        this.showIcon = '';
        this.saleTeam = '';
        this.userSent = '';
        this.nickNameSent = '';
        this.thaiDate = '';
        this.receivedata.billId = this.route.snapshot.paramMap.get('bill_Id');
        this.receivedata.OrderNumber = this.route.snapshot.paramMap.get('OrderNumber');
        this.fact = this.route.snapshot.paramMap.get('fact');
        this.showIcon = this.route.snapshot.paramMap.get('showIcon');
        this.saleTeam = this.route.snapshot.paramMap.get('saleTeam');
        this.userSent = this.route.snapshot.paramMap.get('userSent');
        this.nickNameSent = this.route.snapshot.paramMap.get('nickNameSent');
        this.thaiDate = this.route.snapshot.paramMap.get('thaiDateBill');
      }

      _createClass(ReceiveDetailPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.user = this.authService.getUserInfo(); // console.log('USer + ' , this.user);
          // console.log(this.receivedata);

          this.isSub1 = false;
          this.isSub2 = false;
          this.isSub3 = false;
          this.loadItemreceive();
        }
      }, {
        key: "loadItemreceive",
        value: function loadItemreceive() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var _this = this;

            var loading;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    this.isSub1 = true;
                    _context3.next = 3;
                    return this.loadingCtrl.create({
                      spinner: 'bubbles',
                      message: 'กำลังโหลด'
                    });

                  case 3:
                    loading = _context3.sent;
                    _context3.next = 6;
                    return loading.present();

                  case 6:
                    _context3.next = 8;
                    return this.service.qaItemsReceive(this.receivedata.billId).subscribe(function (data) {
                      _this.qaReceiveDetail = data;
                      _this.billQA = _this.qaReceiveDetail[0].qaDocNumber;
                      _this.dateReceive = _this.qaReceiveDetail[0].receiveDate;
                      console.log(data);
                    }, function (error) {
                      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                        return regeneratorRuntime.wrap(function _callee$(_context) {
                          while (1) {
                            switch (_context.prev = _context.next) {
                              case 0:
                                console.log(error);
                                _context.next = 3;
                                return loading.dismiss();

                              case 3:
                              case "end":
                                return _context.stop();
                            }
                          }
                        }, _callee);
                      }));
                    }, function () {
                      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
                        var _this2 = this;

                        return regeneratorRuntime.wrap(function _callee2$(_context2) {
                          while (1) {
                            switch (_context2.prev = _context2.next) {
                              case 0:
                                this.sum1 = 0;
                                this.qaReceiveDetail.forEach(function (item) {
                                  _this2.sum1 = _this2.sum1 + item.Qty; // this.sum1 = this.sum1 + item.Qty;
                                });
                                _context2.next = 4;
                                return loading.dismiss();

                              case 4:
                              case "end":
                                return _context2.stop();
                            }
                          }
                        }, _callee2, this);
                      }));
                    });

                  case 8:
                    this.sub = _context3.sent;

                  case 9:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "onConfirm",
        value: function onConfirm() {
          var _this3 = this;

          this.faio.show({
            title: 'ArtEvent Security',
            disableBackup: true
          }).then(function (result) {
            console.log(result);

            _this3.confirmBill();

            alert('บันทึกข้อมูลเรียบร้อย');

            _this3.nav.navigateBack(['/tabs/receive-billfac']);
          })["catch"](function (error) {
            return console.log(error);
          });
        }
      }, {
        key: "confirmBill",
        value: function confirmBill() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
            return regeneratorRuntime.wrap(function _callee4$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    // console.log('UserID', this.user[0].userID);
                    // console.log('billID', this.receivedata.billId);
                    this.isSub2 = true;
                    this.sub2 = this.service.confirmBillreceive(this.receivedata.billId, '1').subscribe(function (data2) {// console.log('Insert Success');
                    });
                    this.isSub3 = true;
                    this.sub3 = this.service.confirmBillreceiveShowUser(this.receivedata.billId, this.user[0].userID).subscribe(function (data) {// console.log('Insert User');
                    });

                  case 4:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee4, this);
          }));
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          if (this.isSub1) {
            this.sub.unsubscribe();
          }

          if (this.isSub2) {
            this.sub2.unsubscribe();
          }

          if (this.isSub3) {
            this.sub3.unsubscribe();
          }
        }
      }]);

      return ReceiveDetailPage;
    }();

    ReceiveDetailPage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]
      }, {
        type: _services_qasales_service__WEBPACK_IMPORTED_MODULE_4__["QasalesService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"]
      }, {
        type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_5__["AuthService"]
      }, {
        type: _ionic_native_fingerprint_aio_ngx__WEBPACK_IMPORTED_MODULE_6__["FingerprintAIO"]
      }];
    };

    ReceiveDetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-receive-detail',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./receive-detail.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/receive-billfac/receive-detail/receive-detail.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./receive-detail.page.scss */
      "./src/app/tabs/receive-billfac/receive-detail/receive-detail.page.scss"))["default"]]
    })], ReceiveDetailPage);
    /***/
  }
}]);
//# sourceMappingURL=default~receive-detail-receive-detail-module~tabs-receive-billfac-receive-detail-receive-detail-module-es5.js.map