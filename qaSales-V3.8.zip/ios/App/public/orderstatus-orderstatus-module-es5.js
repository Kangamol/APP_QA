function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["orderstatus-orderstatus-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/orderstatus/orderstatus.page.html":
  /*!**********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/orderstatus/orderstatus.page.html ***!
    \**********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppTabsOrderstatusOrderstatusPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header >\n  <ion-toolbar class=\"heigth60\">\n    \n      <ion-row>\n        <ion-col size=\"0.5\">\n          <ion-buttons>\n            <ion-menu-button></ion-menu-button>\n          </ion-buttons>\n        </ion-col>\n\n        <ion-col size=\"10\">\n          <ion-title class=\"fontPromptBold fontSize30 ion-text-center\">สถานะ Order ระหว่างผลิต</ion-title>\n        </ion-col>\n\n        <ion-col size=\"1\" >\n          <ion-buttons >\n            <ion-button (click)=\"onClickRefresh()\">\n              <ion-icon name=\"refresh\" size=\"large\"></ion-icon>\n            </ion-button>\n            <ion-button (click)=\"showSearch()\">\n              <ion-icon name=\"search\" size=\"large\"></ion-icon>\n            </ion-button>\n          </ion-buttons>\n        </ion-col>\n    </ion-row>\n\n    \n\n  </ion-toolbar >\n\n\n\n\n<!-- Login -->\n  <ion-toolbar>\n  <ion-grid>\n    <ion-row [ngClass]=\"{'backgroundPink': user[0].saleManager == '2', 'backgroundBlue': user[0].saleManager == '1,3'}\">\n\n      <ion-col size=\"1\">\n        <ion-avatar>\n          <img src=\"{{user[0].userPicture}}\">\n        </ion-avatar>\n      </ion-col>\n\n      <ion-col size=\"5\" class=\"padingTop\">\n        <ion-text  class=\"fontPromptBold fontSize20  ion-text-left \">&nbsp;Login : {{user[0].fullName}}({{user[0].nickName}})</ion-text>\n      </ion-col>\n\n      <ion-col size=\"5\" class=\"padingTop\">\n        <ion-text  class=\"fontPromptBold fontSize20 ion-text-left \">&nbsp;Team : {{user[0].saleTeam}}</ion-text>\n      </ion-col>\n    </ion-row>\n   </ion-grid>\n\n  </ion-toolbar>\n\n\n\n  <ion-toolbar *ngIf=\"search\">\n    <ion-searchbar placeholder=\"Find OrderNumber\" debounce=\"500\"  (ionChange)=\"getBill($event)\"></ion-searchbar>\n  </ion-toolbar>\n\n\n  <ion-grid>\n    <ion-row >\n      <ion-col>\n        <ion-item color=\"primary\">\n          <ion-col size=\"4.7\">\n            <ion-label><div class=\"fontPromptRegular ion-text-center\">Order No. / กำหนดเสร็จ</div></ion-label>\n          </ion-col>\n          <ion-col size=\"1.3\" class=\"ion-text-center\">\n            <ion-label><div class=\"fontPromptRegular fontSize14\">จำนวน<br>ทั้งORDER\n            </div></ion-label>\n          </ion-col>\n          <ion-col size=\"1.2\" class=\"ion-text-center\">\n            <ion-label><div class=\"fontPromptRegular fontSize14\">งานค้าง<br>Order</div></ion-label>\n          </ion-col>\n          <ion-col size=\"1.2\" class=\"ion-text-center\">\n            <ion-label><div class=\"fontPromptRegular fontSize14\">งานค้าง<br>ซ่อม</div></ion-label>\n          </ion-col>\n          <ion-col size=\"1.2\" class=\"ion-text-center\">\n            <ion-label><div class=\"fontPromptRegular fontSize14\">งานรอ<br>ตรวจ</div></ion-label>\n          </ion-col>\n          <ion-col size=\"1.2\" class=\"ion-text-center\">\n            <ion-label><div class=\"fontPromptRegular fontSize14\">QA<br>เสร็จแล้ว</div></ion-label>\n          </ion-col>\n          <!-- <ion-col size=\"0.5\"></ion-col> -->\n          <ion-col size=\"1.2\" class=\"ion-text-center\">\n            <ion-label><div class=\"fontPromptRegular\">สถานะ</div></ion-label>\n          </ion-col>\n        </ion-item>\n      </ion-col>\n    </ion-row>\n\n    <!-- Summary -->\n    <ion-row>\n      <ion-col>\n        <ion-item color=\"light\">\n          <!-- <ion-col size=\"1\"></ion-col> -->\n          <ion-col size=\"4.7\">\n            <ion-label><div class=\"fontPromptRegular\">ยอดรวม</div></ion-label>\n          </ion-col>\n\n          <ion-col size=\"1.3\" class=\"ion-text-center\">\n            <ion-label>\n              <ion-text class=\"fontPromptBold fontSize16\">\n                {{ sum1 | number }}\n              </ion-text>\n            </ion-label>\n          </ion-col>\n\n          <ion-col size=\"1.2\" class=\"ion-text-center\">\n            <ion-label color=\"danger\">\n              <ion-text class=\"fontPromptBold fontSize16\">\n                {{ sum2 | number }}\n              </ion-text>\n            </ion-label>\n          </ion-col>\n\n          <ion-col size=\"1.2\" class=\"ion-text-center\">\n            <ion-label color=\"warning\" >\n              <ion-text class=\"fontPromptBold fontSize16\">\n                {{ sum3 | number }}\n              </ion-text>\n            </ion-label>\n          </ion-col>\n\n          <ion-col size=\"1.2\" class=\"ion-text-center\">\n            <ion-label color=\"danger\">\n              <ion-text class=\"fontPromptBold fontSize16\">\n                {{ sum4 | number }}\n              </ion-text>\n            </ion-label>\n          </ion-col>\n\n          <ion-col size=\"1.2\" class=\"ion-text-center\">\n            <ion-label color=\"primary\" >\n              <ion-text class=\"fontPromptBold fontSize16\">\n                {{ sum5 | number }}\n              </ion-text>\n            </ion-label>\n          </ion-col>\n          <!-- <ion-col size=\"0.2\"></ion-col> -->\n          <ion-col size=\"1.2\" class=\"ion-text-center\">\n            <ion-label><div class=\"fontPromptRegular\"></div></ion-label>\n          </ion-col>\n        </ion-item>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-header>\n\n<ion-content>\n  <ion-grid>\n    <ion-row>\n      <ion-col>\n        <ion-item *ngFor=\"let d of orderStatus\" (click)=\"selectItem(d)\" [ngClass]=\"{'myImg': d.TotalQty == d.TotalQaFinish}\">\n\n          <ion-col size=\"1\">\n            <ion-thumbnail>\n              <img src=\"{{d.avatar}}\">\n            </ion-thumbnail>\n          </ion-col>\n\n          <ion-col size=\"3.8\">\n            <ion-label><ion-text class=\"fontPromptBold fontSize17\">{{ d.OrderNumber }}</ion-text>\n              <br>\n              <p class=\"fontPromptRegular fontSize12\">DL: ({{ d.thaiDate }}) {{ d.DueDate | date:'dd/MM/yyyy':\"+0000\" }}</p>\n              <!-- <p class=\"fontPromptRegular fontSize12\">DL: ({{ d.thaiDate }}){{ d.DueDate | date:'dd/MM/yyyy' }}({{d.JobDay}}วัน) </p> -->\n              <!-- <p class=\"fontPromptRegular fontSize12\">Factory : {{ d.ProductionTeam }}</p> -->\n            </ion-label>\n              \n          </ion-col>\n\n          <ion-col size=\"1.2\" class=\"ion-text-center\">\n            <ion-label> \n              <ion-text class=\"fontPromptRegular fontSize16\">\n                {{ d.TotalQty | number }}\n              </ion-text>\n            </ion-label>\n          </ion-col>\n\n          \n          <ion-col size=\"1.2\" class=\"ion-text-center \">\n            <ion-label color=\"danger\">\n              <ion-text class=\"fontPromptRegular fontSize16\">\n                {{d.Balance | number }}\n              </ion-text>\n            </ion-label>\n          </ion-col>\n\n          <ion-col size=\"1.2\" class=\"ion-text-center\">\n            <ion-label color=\"warning\">\n              <ion-text class=\"fontPromptRegular fontSize16\">\n                {{ d.TotalQaRepair| number }}\n              </ion-text>\n            </ion-label>\n          </ion-col>\n\n          <ion-col size=\"1.2\" class=\"ion-text-center\">\n            <ion-label color=\"danger\">\n              <ion-text class=\"fontPromptRegular fontSize16\">\n                {{ d.TotalQaBill - d.TotalQaRepair - d.TotalQaFinish | number }}\n              </ion-text>\n            </ion-label>\n          </ion-col>\n\n          <ion-col size=\"1.2\" class=\"ion-text-center\">\n            <ion-label color=\"primary\">\n              <ion-text class=\"fontPromptRegular fontSize16\">\n                {{ d.TotalQaFinish | number }}\n              </ion-text>\n            </ion-label>\n          </ion-col>\n\n\n\n\n\n          <!-- <ion-col size=\"0.5\"></ion-col> -->\n          <ion-col size=\"1.2\" class=\"ion-text-right\">\n            <!-- <ion-label>{{ d.dateLate | number }}</ion-label> -->\n            <ion-button *ngIf=\"d.dateLate > 3\" expand=\"block\" color=\"success\"><ion-text class=\"fontPromptRegular fontSize16\">{{ d.dateLate | number }} วัน</ion-text></ion-button>\n            <ion-button *ngIf=\"d.dateLate >= 0 && d.dateLate <= 3\" expand=\"block\" color=\"warning\"><ion-text class=\"fontPromptRegular fontSize16\">{{ d.dateLate | number }} วัน</ion-text></ion-button>\n            <ion-button *ngIf=\"d.dateLate < 0\"expand=\"block\" color=\"danger\"><ion-text class=\"fontPromptRegular fontSize16\">{{ d.dateLate | number }} วัน</ion-text></ion-button>\n          </ion-col>\n        </ion-item>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/tabs/orderstatus/orderstatus-routing.module.ts":
  /*!****************************************************************!*\
    !*** ./src/app/tabs/orderstatus/orderstatus-routing.module.ts ***!
    \****************************************************************/

  /*! exports provided: OrderstatusPageRoutingModule */

  /***/
  function srcAppTabsOrderstatusOrderstatusRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "OrderstatusPageRoutingModule", function () {
      return OrderstatusPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _orderstatus_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./orderstatus.page */
    "./src/app/tabs/orderstatus/orderstatus.page.ts");

    var routes = [{
      path: '',
      component: _orderstatus_page__WEBPACK_IMPORTED_MODULE_3__["OrderstatusPage"]
    }, {
      path: 'orderitems',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | orderitems-orderitems-module */
        "default~orderitems-orderitems-module~tabs-orderstatus-orderitems-orderitems-module").then(__webpack_require__.bind(null,
        /*! ./orderitems/orderitems.module */
        "./src/app/tabs/orderstatus/orderitems/orderitems.module.ts")).then(function (m) {
          return m.OrderitemsPageModule;
        });
      }
    }, {
      path: 'popup-reportrepair-item',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | popup-reportrepair-item-popup-reportrepair-item-module */
        "popup-reportrepair-item-popup-reportrepair-item-module").then(__webpack_require__.bind(null,
        /*! ./popup-reportrepair-item/popup-reportrepair-item.module */
        "./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.module.ts")).then(function (m) {
          return m.PopupReportrepairItemPageModule;
        });
      }
    }];

    var OrderstatusPageRoutingModule = function OrderstatusPageRoutingModule() {
      _classCallCheck(this, OrderstatusPageRoutingModule);
    };

    OrderstatusPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], OrderstatusPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/tabs/orderstatus/orderstatus.module.ts":
  /*!********************************************************!*\
    !*** ./src/app/tabs/orderstatus/orderstatus.module.ts ***!
    \********************************************************/

  /*! exports provided: OrderstatusPageModule */

  /***/
  function srcAppTabsOrderstatusOrderstatusModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "OrderstatusPageModule", function () {
      return OrderstatusPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _orderstatus_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./orderstatus-routing.module */
    "./src/app/tabs/orderstatus/orderstatus-routing.module.ts");
    /* harmony import */


    var _orderstatus_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./orderstatus.page */
    "./src/app/tabs/orderstatus/orderstatus.page.ts");

    var OrderstatusPageModule = function OrderstatusPageModule() {
      _classCallCheck(this, OrderstatusPageModule);
    };

    OrderstatusPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _orderstatus_routing_module__WEBPACK_IMPORTED_MODULE_5__["OrderstatusPageRoutingModule"]],
      declarations: [_orderstatus_page__WEBPACK_IMPORTED_MODULE_6__["OrderstatusPage"]]
    })], OrderstatusPageModule);
    /***/
  },

  /***/
  "./src/app/tabs/orderstatus/orderstatus.page.scss":
  /*!********************************************************!*\
    !*** ./src/app/tabs/orderstatus/orderstatus.page.scss ***!
    \********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppTabsOrderstatusOrderstatusPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".myImg {\n  -webkit-filter: brightness(50%);\n          filter: brightness(50%);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy90aGFuYXNhdGUvaW9uaWMvcWFTYWxlcy1WMy40L3NyYy9hcHAvdGFicy9vcmRlcnN0YXR1cy9vcmRlcnN0YXR1cy5wYWdlLnNjc3MiLCJzcmMvYXBwL3RhYnMvb3JkZXJzdGF0dXMvb3JkZXJzdGF0dXMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksK0JBQUE7VUFBQSx1QkFBQTtBQ0NKIiwiZmlsZSI6InNyYy9hcHAvdGFicy9vcmRlcnN0YXR1cy9vcmRlcnN0YXR1cy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubXlJbWcge1xyXG4gICAgZmlsdGVyOiBicmlnaHRuZXNzKDUwJSk7XHJcbiAgfSIsIi5teUltZyB7XG4gIGZpbHRlcjogYnJpZ2h0bmVzcyg1MCUpO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/tabs/orderstatus/orderstatus.page.ts":
  /*!******************************************************!*\
    !*** ./src/app/tabs/orderstatus/orderstatus.page.ts ***!
    \******************************************************/

  /*! exports provided: OrderstatusPage */

  /***/
  function srcAppTabsOrderstatusOrderstatusPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "OrderstatusPage", function () {
      return OrderstatusPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/auth/auth.service */
    "./src/app/auth/auth.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var src_app_services_qasales_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/app/services/qasales.service */
    "./src/app/services/qasales.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var OrderstatusPage = /*#__PURE__*/function () {
      function OrderstatusPage(authService, route, service, loadingCtrl, nav) {
        _classCallCheck(this, OrderstatusPage);

        this.authService = authService;
        this.route = route;
        this.service = service;
        this.loadingCtrl = loadingCtrl;
        this.nav = nav;
        this.search = false;
        this.sum1 = 0;
        this.sum2 = 0;
        this.sum3 = 0;
        this.sum4 = 0;
        this.sum5 = 0;
      }

      _createClass(OrderstatusPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.user = this.authService.getUserInfo(); // console.log('onInit Deaprtment = ', this.user[0].userDepartment);
        }
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.search = false; // this.person = false;

          this.user = this.authService.getUserInfo();

          if (!this.user) {
            this.route.navigateByUrl('/auth');
          } else {
            // console.log('Deaprtment = ', this.user[0].userDepartment);
            this.loaddata();
          }
        }
      }, {
        key: "loaddata",
        value: function loaddata() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var _this = this;

            var loading;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return this.loadingCtrl.create({
                      spinner: 'bubbles',
                      message: 'กำลังโหลด'
                    });

                  case 2:
                    loading = _context3.sent;
                    _context3.next = 5;
                    return loading.present();

                  case 5:
                    this.sub = this.service.getOrderStatus(this.user[0].saleManager).subscribe(function (data) {
                      // console.log(data);
                      _this.orderStatus = data;
                      _this.orderStatusGet = data;
                    }, function (error) {
                      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                        return regeneratorRuntime.wrap(function _callee$(_context) {
                          while (1) {
                            switch (_context.prev = _context.next) {
                              case 0:
                                console.log(error);
                                _context.next = 3;
                                return loading.dismiss();

                              case 3:
                              case "end":
                                return _context.stop();
                            }
                          }
                        }, _callee);
                      }));
                    }, function () {
                      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
                        return regeneratorRuntime.wrap(function _callee2$(_context2) {
                          while (1) {
                            switch (_context2.prev = _context2.next) {
                              case 0:
                                // หาผลรวม
                                this.SumValues();
                                _context2.next = 3;
                                return loading.dismiss();

                              case 3:
                              case "end":
                                return _context2.stop();
                            }
                          }
                        }, _callee2, this);
                      }));
                    });

                  case 6:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "getBill",
        value: function getBill(ev) {
          var val = ev.target.value;
          this.orderStatus = this.orderStatusGet;

          if (val && val.trim() !== '') {
            this.orderStatus = this.orderStatus.filter(function (bill) {
              return bill.OrderNumber.toLowerCase().indexOf(val.toLowerCase()) > -1;
            }); // หาผลรวม

            this.SumValues();
          } else {
            // this.loaddata();
            this.orderStatus = this.orderStatusGet;
            this.SumValues();
          }
        }
      }, {
        key: "SumValues",
        value: function SumValues() {
          var _this2 = this;

          this.sum1 = this.sum2 = this.sum3 = this.sum4 = this.sum5 = 0;
          this.orderStatus.forEach(function (item) {
            _this2.sum1 = _this2.sum1 + item.TotalQty;
            _this2.sum2 = _this2.sum2 + item.Balance;
            _this2.sum3 = _this2.sum3 + item.TotalQaRepair;
            _this2.sum4 = _this2.sum4 + (item.TotalQaBill - item.TotalQaRepair - item.TotalQaFinish);
            _this2.sum5 = _this2.sum5 + item.TotalQaFinish;
          });
        }
      }, {
        key: "showSearch",
        value: function showSearch() {
          this.search = !this.search;
        }
      }, {
        key: "onClickRefresh",
        value: function onClickRefresh() {
          this.loaddata();
        }
      }, {
        key: "selectItem",
        value: function selectItem(selectData) {
          this.nav.navigateForward(['/orderitems', {
            orderNumber: selectData.OrderNumber,
            thaiDate: selectData.thaiDate,
            DueDate: selectData.DueDate,
            totalQty: selectData.TotalQty,
            finishQty: selectData.TotalQaFinish,
            repairQty: selectData.TotalQaRepair,
            Balance: selectData.Balance,
            qaQty: selectData.TotalQaBill,
            avatar: selectData.avatar,
            fac: selectData.ProductionTeam,
            totalRepairSum: selectData.Totalrepairsum,
            dateLate: selectData.dateLate
          }]);
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          this.sub.unsubscribe();
        }
      }]);

      return OrderstatusPage;
    }();

    OrderstatusPage.ctorParameters = function () {
      return [{
        type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }, {
        type: src_app_services_qasales_service__WEBPACK_IMPORTED_MODULE_4__["QasalesService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"]
      }];
    };

    OrderstatusPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-orderstatus',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./orderstatus.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/orderstatus/orderstatus.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./orderstatus.page.scss */
      "./src/app/tabs/orderstatus/orderstatus.page.scss"))["default"]]
    })], OrderstatusPage);
    /***/
  }
}]);
//# sourceMappingURL=orderstatus-orderstatus-module-es5.js.map