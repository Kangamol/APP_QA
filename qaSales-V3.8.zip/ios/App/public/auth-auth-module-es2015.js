(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["auth-auth-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth.page.html":
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth.page.html ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header [translucent]=\"true\">\n  <!-- <ion-toolbar>\n    <ion-button slot=\"end\" size=\"Default\" color=\"danger\" (click)=\"logout()\">LOGOUT</ion-button>\n    <ion-title></ion-title>\n  </ion-toolbar> -->\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n  <ion-grid>\n    <ion-row class=\"ion-padding-top\"></ion-row>\n    <ion-row class=\"ion-padding-top\">\n      <ion-col size-sm=\"6\" offset-sm=\"3\" size-lg=\"2\" offset-lg=\"5\">\n        <ion-img src=\"http://172.16.0.15/aeweb/picture/PICTURE2/Art%20Event%20Logo2.jpg\"></ion-img>\n      </ion-col>\n    </ion-row>\n\n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\" size-lg=\"2\" offset-lg=\"5\">\n        <ion-img src=\"{{userPict}}\" class=\"imgsize\"></ion-img>\n      </ion-col>\n    </ion-row>\n\n      <ion-row>\n        <ion-col class=\"ion-text-center\"> \n          <h4>Authenticate</h4>   \n        </ion-col>        \n      </ion-row>\n  \n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\" size-lg=\"4\" offset-lg=\"4\">\n        <div>\n          <ion-item>\n            <ion-input type=\"text\" placeholder=\"Username\" (ionBlur)=\"changeAvatar($event)\"></ion-input> \n            </ion-item>\n        </div>\n        </ion-col>\n      </ion-row>\n         \n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\" size-lg=\"4\" offset-lg=\"4\">\n          <ion-item>\n            <ion-input type=\"password\" placeholder=\"Password\" [(ngModel)]=\"enterPassword\"></ion-input>\n          </ion-item>\n        </ion-col>\n      </ion-row>\n\n      <br>\n      <br>\n      <br>\n\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\" size-lg=\"4\" offset-lg=\"4\">\n          <ion-button size=\"large\" expand=\"block\" (click)=\"login()\">Login</ion-button>\n        </ion-col>    \n      </ion-row>\n    </ion-grid>\n\n  <!-- <app-explore-container name=\"Tab 1 page\"></app-explore-container> -->\n</ion-content>\n");

/***/ }),

/***/ "./src/app/auth/auth-routing.module.ts":
/*!*********************************************!*\
  !*** ./src/app/auth/auth-routing.module.ts ***!
  \*********************************************/
/*! exports provided: AuthPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthPageRoutingModule", function() { return AuthPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _auth_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./auth.page */ "./src/app/auth/auth.page.ts");




const routes = [
    {
        path: '',
        component: _auth_page__WEBPACK_IMPORTED_MODULE_3__["AuthPage"]
    }
];
let AuthPageRoutingModule = class AuthPageRoutingModule {
};
AuthPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], AuthPageRoutingModule);



/***/ }),

/***/ "./src/app/auth/auth.module.ts":
/*!*************************************!*\
  !*** ./src/app/auth/auth.module.ts ***!
  \*************************************/
/*! exports provided: AuthPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthPageModule", function() { return AuthPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _auth_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./auth-routing.module */ "./src/app/auth/auth-routing.module.ts");
/* harmony import */ var _auth_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./auth.page */ "./src/app/auth/auth.page.ts");







let AuthPageModule = class AuthPageModule {
};
AuthPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _auth_routing_module__WEBPACK_IMPORTED_MODULE_5__["AuthPageRoutingModule"]
        ],
        declarations: [_auth_page__WEBPACK_IMPORTED_MODULE_6__["AuthPage"]]
    })
], AuthPageModule);



/***/ }),

/***/ "./src/app/auth/auth.page.scss":
/*!*************************************!*\
  !*** ./src/app/auth/auth.page.scss ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2F1dGgvYXV0aC5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/auth/auth.page.ts":
/*!***********************************!*\
  !*** ./src/app/auth/auth.page.ts ***!
  \***********************************/
/*! exports provided: AuthPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthPage", function() { return AuthPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./auth.service */ "./src/app/auth/auth.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");




let AuthPage = class AuthPage {
    constructor(authService, route) {
        this.authService = authService;
        this.route = route;
        this.userPict = 'http://172.16.0.15/aeweb/picture/PICTURE2//Employee//avatarShow.png';
        this.getPassword = '';
        this.enterPassword = '';
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        // console.log('auth page -> ', this.authService.getUserInfo());
        if (!this.authService.getUserInfo()) {
            this.userPict = 'http://172.16.0.15/aeweb/picture/PICTURE2//Employee//avatarShow.png';
            this.getPassword = '';
            this.enterPassword = '';
        }
    }
    changeAvatar(e) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            console.log(e.target.value);
            const event = e.target.value;
            if (event && event.trim() !== '') {
                this.sub = yield this.authService.getUser(event).subscribe((data) => {
                    if (data.length > 0) {
                        this.userInfo = data;
                        this.userPict = data[0].userPicture;
                        // this.userPict = data[0].userPicture;
                        this.getPassword = data[0].userPassword;
                        // this.getUserID = data[0].userID;
                        // this.getUserPict = data[0].userPicture;
                        // console.log(this.userInfo);
                    }
                    else {
                        // No picture
                        this.userPict = 'http://172.16.0.15/aeweb/picture/PICTURE2//Employee//avatarShow.png';
                    }
                });
            }
        });
    }
    login() {
        if (this.getPassword === this.enterPassword) {
            this.authService.setUserInfo(this.userInfo);
            this.authService.login();
            this.route.navigateByUrl('/tabs/orderstatus');
        }
        else {
            alert('Password ไม่ถูกต้อง');
        }
    }
    logout() {
        this.authService.logout();
        this.userPict = 'http://172.16.0.15/aeweb/picture/PICTURE2//Employee//avatarShow.png';
        this.getPassword = '';
        this.enterPassword = '';
    }
    ngOnDestroy() {
        this.sub.unsubscribe();
    }
};
AuthPage.ctorParameters = () => [
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] }
];
AuthPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-auth',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./auth.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./auth.page.scss */ "./src/app/auth/auth.page.scss")).default]
    })
], AuthPage);



/***/ })

}]);
//# sourceMappingURL=auth-auth-module-es2015.js.map