(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["repairstatus-repairstatus-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/repairstatus/repairstatus.page.html":
/*!************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/repairstatus/repairstatus.page.html ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header [translucent]=\"true\">\n\n  <ion-toolbar class=\"heigth70\">\n    <ion-title class=\" fontPromptBold\" >\n      <h1 class=\"fontsize30\">สถานะงานซ่อม & รับงานซ่อมกลับจากผลิต</h1>\n    </ion-title>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n\n    <ion-buttons slot=\"end\" >\n      <ion-button (click)=\"onClickRefresh()\">\n        <ion-icon slot=\"icon-only\" name=\"refresh\" size=\"large\"></ion-icon>\n      </ion-button>\n      <ion-button (click)=\"showSearch()\">\n        <ion-icon slot=\"icon-only\" name=\"search\" size=\"large\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n\n  <ion-toolbar class=\"align\">\n    <ion-button slot=\"end\" (click)=\"gotoRepairFinish()\">\n      <h5 class=\"fontPromptRegular align\">\n        ดูประวัติงานที่ซ่อมเสร็จ\n      </h5>\n    </ion-button>\n  </ion-toolbar>\n\n  <!-- Login -->\n  <ion-toolbar>\n    <ion-grid>\n      <ion-row [ngClass]=\"{'backgroundPink': user[0].saleManager == '2', 'backgroundBlue': user[0].saleManager == '1,3'}\">\n      <ion-col size=\"1\">\n        <ion-avatar>\n          <img src=\"{{user[0].userPicture}}\">\n        </ion-avatar>\n        </ion-col>\n\n        <ion-col size=\"5\" class=\"padingTop\">\n          <ion-text  class=\"fontPromptBold fontSize20  ion-text-left \">&nbsp;Login : {{user[0].fullName}}({{user[0].nickName}})</ion-text>\n        </ion-col>\n\n        <ion-col size=\"5\" class=\"padingTop\">\n          <ion-text  class=\"fontPromptBold fontSize20 ion-text-left \">&nbsp;Team : {{user[0].saleTeam}}</ion-text>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n\n  </ion-toolbar>\n\n\n  <ion-toolbar *ngIf=\"search\">\n    <ion-searchbar placeholder=\"Find OrderNumber\" debounce=\"500\" (ionChange)=\"getBill($event)\" ></ion-searchbar>\n  </ion-toolbar>\n\n\n  <ion-toolbar>\n    <ion-grid>\n      <ion-row>\n        <ion-col>\n          <ion-item color=\"warning\">\n\n            <ion-col size=\"5.1\">\n              <ion-label class=\"ion-text-center\">    \n                <h1 class=\"fontPromptBold\">Description</h1> \n              </ion-label>\n            </ion-col>\n\n            <ion-col size=\"1.25\">\n              <ion-label class=\"ion-text-center\">\n                <h2 class=\"fontPromptBold\">จำนวนที่<br>ส่งซ่อม</h2>\n              </ion-label>\n            </ion-col>\n\n            <ion-col size=\"1.25\">\n              <ion-label class=\"ion-text-center\">\n                <h2 class=\"fontPromptBold\">QA<br>รับแล้ว</h2>\n              </ion-label>\n            </ion-col>\n        \n            <ion-col size=\"1.25\">\n              <ion-label class=\"ion-text-center\">\n                <h2 class=\"fontPromptBold\">กำลัง<br>ซ่อม</h2>\n              </ion-label>\n            </ion-col>  \n        \n            <ion-col size=\"1.25\">\n              <ion-label class=\"ion-text-center\">\n                <h2 class=\"fontPromptBold\">รอ<br>QA รับ</h2>\n              </ion-label>\n            </ion-col>\n        \n            <ion-col size=\"1.9\">\n              <ion-label class=\"ion-text-center\">\n                <h2 class=\"fontPromptBold\">สถานะ</h2>\n              </ion-label>\n            </ion-col>\n\n          </ion-item>\n\n        </ion-col>\n      </ion-row>\n  \n   <!-- Summary -->\n   <ion-row>\n    <ion-col>\n\n      <ion-item color=\"light\">\n        <!-- <ion-col size=\"1\"></ion-col> -->\n        <ion-col size=\"5.1\" class=\"ion-text-center\">\n          <ion-label><div class=\"fontPromptBold\">ยอดรวม</div></ion-label>\n        </ion-col>\n\n        <ion-col size=\"1.25\" class=\"ion-text-center\">\n          <ion-label>\n            <ion-text class=\"fontPromptBold fontSize18\">\n              {{ sum1 | number }}\n            </ion-text>\n          </ion-label>\n        </ion-col>\n\n        <ion-col size=\"1.25\" class=\"ion-text-center\">\n          <ion-label color=\"primary\">\n            <ion-text class=\"fontPromptBold fontSize18\">\n              {{ sum2 | number }}\n            </ion-text>\n          </ion-label>\n        </ion-col>\n\n        <ion-col size=\"1.25\" class=\"ion-text-center\">\n          <ion-label color=\"warning\" >\n            <ion-text class=\"fontPromptBold fontSize18\">\n              {{ sum3 | number }}\n            </ion-text>\n          </ion-label>\n        </ion-col>\n\n        <ion-col size=\"1.25\" class=\"ion-text-center\">\n          <ion-label color=\"success\">\n            <ion-text class=\"fontPromptBold fontSize18\">\n              {{ sum4 | number }}\n            </ion-text>\n          </ion-label>\n        </ion-col>\n\n      </ion-item>\n    </ion-col>\n  </ion-row>\n</ion-grid>\n</ion-toolbar>\n\n</ion-header>\n\n<ion-content>\n\n  <ion-grid>\n    <ion-row>\n      <ion-col>\n        <ion-item *ngFor=\"let i of statusRepairMaster\" (click)=\"gotoReceiveRepair(i)\">\n\n          <ion-col size=\"0.8\">\n            <ion-thumbnail>\n              <img src=\"{{i.showIcon}}\">\n            </ion-thumbnail>\n          </ion-col>\n\n          <ion-col size=\"4.1\" offset=\"0.2\">\n            <ion-label class=\"ion-text-left\">    \n              <ion-text>\n                <h2 class=\"fontPromptBold\">{{i.OrderNumber}}</h2>\n                <h3 class=\"fontPromptRegular colorFontGray\">เลขที่บิล QA&nbsp;&nbsp;: {{i.qaDocNumber}}</h3>\n                <h3 class=\"fontPromptRegular colorFontGray\">เลขที่บิลซ่อม : {{i.repairDocNumber}} </h3>\n                <h3 class=\"fontPromptRegular colorFontGray\">วันที่ส่งซ่อม : ({{i.receiveDateThai}}){{i.repairDate | date:\"dd/MM/yy\":\"+0000\"}} ({{i.repairDate | date: 'HH:mm' : '+0'}}น.)</h3>\n              </ion-text>\n            </ion-label>\n          </ion-col>\n\n          <ion-col size=\"1.25\">\n            <ion-label class=\"ion-text-center\">\n              <h2 class=\"fontPromptRegular\">{{i.TotalQty | number}}</h2>\n            </ion-label>\n          </ion-col>\n\n          <ion-col size=\"1.25\">\n            <ion-label class=\"ion-text-center\" color=\"primary\">\n              <h2 class=\"fontPromptRegular\">{{i.TotalFinishQty | number}}</h2>\n            </ion-label>\n          </ion-col>\n      \n          <ion-col size=\"1.25\">\n            <ion-label class=\"ion-text-center\" color=\"warning\">\n              <h2 class=\"fontPromptRegular\">{{i.TotalQty - i.TotalFinishQty | number}}</h2>\n            </ion-label>\n          </ion-col>  \n      \n          <ion-col size=\"1.25\">\n            <ion-label class=\"ion-text-center\">\n              <h2 class=\"fontPromptRegular\" [ngClass]=\"{'backgroundGreen': i.ToQa !== 0}\">{{i.ToQa | number}}</h2>\n            </ion-label>\n          </ion-col>\n      \n          <ion-col size=\"1.9\">\n            <ion-label class=\"align\">\n              <ion-button *ngIf=\"i.qaRepairStatus == ' ' \" expand=\"block\" color=\"success\"><ion-text class=\"fontPromptRegular fontSize16\">{{i.statusShow}}</ion-text></ion-button>\n              <ion-button *ngIf=\"i.qaRepairStatus == '1' \" expand=\"block\" color=\"warning\"><ion-text class=\"fontPromptRegular fontSize16\">{{i.statusShow}}</ion-text></ion-button>\n              <ion-button *ngIf=\"i.qaRepairStatus == '2' \" expand=\"block\" color=\"primary\"><ion-text class=\"fontPromptRegular fontSize16\">{{i.statusShow}}</ion-text></ion-button>\n              <ion-button *ngIf=\"i.qaRepairStatus == '3' \" expand=\"block\" color=\"danger\"><ion-text class=\"fontPromptRegular fontSize16\">{{i.statusShow}}</ion-text></ion-button>\n             </ion-label>\n          </ion-col>\n\n        </ion-item>\n\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n  \n</ion-content>");

/***/ }),

/***/ "./src/app/tabs/repairstatus/repairstatus-routing.module.ts":
/*!******************************************************************!*\
  !*** ./src/app/tabs/repairstatus/repairstatus-routing.module.ts ***!
  \******************************************************************/
/*! exports provided: RepairstatusPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RepairstatusPageRoutingModule", function() { return RepairstatusPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _repairstatus_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./repairstatus.page */ "./src/app/tabs/repairstatus/repairstatus.page.ts");




const routes = [
    {
        path: '',
        component: _repairstatus_page__WEBPACK_IMPORTED_MODULE_3__["RepairstatusPage"]
    },
    {
        path: 'receive-repair',
        loadChildren: () => __webpack_require__.e(/*! import() | receive-repair-receive-repair-module */ "default~receive-repair-receive-repair-module~tabs-repairstatus-receive-repair-receive-repair-module").then(__webpack_require__.bind(null, /*! ./receive-repair/receive-repair.module */ "./src/app/tabs/repairstatus/receive-repair/receive-repair.module.ts")).then(m => m.ReceiveRepairPageModule)
    },
    {
        path: 'repair-finish-master',
        loadChildren: () => __webpack_require__.e(/*! import() | repair-finish-master-repair-finish-master-module */ "default~repair-finish-master-repair-finish-master-module~tabs-repairstatus-repair-finish-master-repa~6f6a5a8a").then(__webpack_require__.bind(null, /*! ./repair-finish-master/repair-finish-master.module */ "./src/app/tabs/repairstatus/repair-finish-master/repair-finish-master.module.ts")).then(m => m.RepairFinishMasterPageModule)
    }
];
let RepairstatusPageRoutingModule = class RepairstatusPageRoutingModule {
};
RepairstatusPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], RepairstatusPageRoutingModule);



/***/ }),

/***/ "./src/app/tabs/repairstatus/repairstatus.module.ts":
/*!**********************************************************!*\
  !*** ./src/app/tabs/repairstatus/repairstatus.module.ts ***!
  \**********************************************************/
/*! exports provided: RepairstatusPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RepairstatusPageModule", function() { return RepairstatusPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _repairstatus_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./repairstatus-routing.module */ "./src/app/tabs/repairstatus/repairstatus-routing.module.ts");
/* harmony import */ var _repairstatus_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./repairstatus.page */ "./src/app/tabs/repairstatus/repairstatus.page.ts");







let RepairstatusPageModule = class RepairstatusPageModule {
};
RepairstatusPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _repairstatus_routing_module__WEBPACK_IMPORTED_MODULE_5__["RepairstatusPageRoutingModule"]
        ],
        declarations: [_repairstatus_page__WEBPACK_IMPORTED_MODULE_6__["RepairstatusPage"]]
    })
], RepairstatusPageModule);



/***/ }),

/***/ "./src/app/tabs/repairstatus/repairstatus.page.scss":
/*!**********************************************************!*\
  !*** ./src/app/tabs/repairstatus/repairstatus.page.scss ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3RhYnMvcmVwYWlyc3RhdHVzL3JlcGFpcnN0YXR1cy5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/tabs/repairstatus/repairstatus.page.ts":
/*!********************************************************!*\
  !*** ./src/app/tabs/repairstatus/repairstatus.page.ts ***!
  \********************************************************/
/*! exports provided: RepairstatusPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RepairstatusPage", function() { return RepairstatusPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_native_fingerprint_aio_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/fingerprint-aio/ngx */ "./node_modules/@ionic-native/fingerprint-aio/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var src_app_services_qasales_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/qasales.service */ "./src/app/services/qasales.service.ts");
/* harmony import */ var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/auth/auth.service */ "./src/app/auth/auth.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");








let RepairstatusPage = class RepairstatusPage {
    constructor(faio, service, nav, loadingCtrl, authService, route) {
        this.faio = faio;
        this.service = service;
        this.nav = nav;
        this.loadingCtrl = loadingCtrl;
        this.authService = authService;
        this.route = route;
        this.person = false;
        this.search = false;
        this.sum1 = 0;
        this.sum2 = 0;
        this.sum3 = 0;
        this.sum4 = 0;
    }
    ngOnInit() {
        this.user = this.authService.getUserInfo();
    }
    ionViewWillEnter() {
        this.loaddata();
        this.search = false;
        this.user = this.authService.getUserInfo();
        if (!this.user) {
            this.route.navigateByUrl('/auth');
        }
        else {
            // console.log('Deaprtment = ', this.user[0].userDepartment);
            this.loaddata();
        }
    }
    loaddata() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingCtrl.create({
                spinner: 'bubbles',
                message: 'กำลังโหลด'
            });
            yield loading.present();
            this.sub = this.service.statusRepairMaster(this.user[0].saleManager).subscribe((data) => {
                this.statusRepairMaster = data;
                this.statusRepairMasterGet = data;
                //  console.log( this.statusRepairMaster);
            }, (error) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                console.log(error);
                yield loading.dismiss();
            }), () => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                this.SumValues();
                yield loading.dismiss();
            }));
        });
    }
    SumValues() {
        this.sum1 = this.sum2 = this.sum3 = this.sum4 = 0;
        this.statusRepairMaster.forEach((item) => {
            this.sum1 = this.sum1 + item.TotalQty;
            this.sum2 = this.sum2 + item.TotalFinishQty;
            this.sum3 = this.sum3 + (item.TotalQty - item.TotalFinishQty);
            this.sum4 = this.sum4 + item.ToQa;
        });
    }
    gotoReceiveRepair(i) {
        this.nav.navigateRoot(['//receive-repair', {
                repairId: i.qaRepair_ID,
                OrderNumber: i.OrderNumber,
                qaDoc: i.qaDocNumber,
                repairDoc: i.repairDocNumber,
                fact: i.ProductionTeam,
                Repairstatus: i.qaRepairStatus,
                userReceive: i.userReceive,
                userSent: i.userSent,
                avatar: i.avatar,
                showIcon: i.showIcon,
                repairDate: i.repairDate,
                repairDateThai: i.repairDateThai,
                receiveDate: i.receiveDate,
                receiveDateThai: i.receiveDateThai,
                nickNameSent: i.nickNameSent,
                nickNameReceive: i.nickNameReceive
            }]);
    }
    getBill(ev) {
        const val = ev.target.value;
        this.statusRepairMaster = this.statusRepairMasterGet;
        if (val && val.trim() !== '') {
            this.statusRepairMaster = this.statusRepairMaster.filter((bill) => {
                return (bill.OrderNumber.toLowerCase().indexOf(val.toLowerCase()) > -1);
            });
            this.SumValues();
        }
        else {
            this.statusRepairMaster = this.statusRepairMasterGet;
            this.SumValues();
        }
    }
    gotoRepairFinish() {
        this.nav.navigateRoot(['/repairfinish-master']);
    }
    onClickRefresh() {
        this.loaddata();
    }
    showSearch() {
        this.search = !this.search;
    }
    ngOnDestroy() {
        this.sub.unsubscribe();
    }
};
RepairstatusPage.ctorParameters = () => [
    { type: _ionic_native_fingerprint_aio_ngx__WEBPACK_IMPORTED_MODULE_2__["FingerprintAIO"] },
    { type: src_app_services_qasales_service__WEBPACK_IMPORTED_MODULE_4__["QasalesService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"] },
    { type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_5__["AuthService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] }
];
RepairstatusPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-repairstatus',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./repairstatus.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/repairstatus/repairstatus.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./repairstatus.page.scss */ "./src/app/tabs/repairstatus/repairstatus.page.scss")).default]
    })
], RepairstatusPage);



/***/ })

}]);
//# sourceMappingURL=repairstatus-repairstatus-module-es2015.js.map