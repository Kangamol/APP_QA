import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { QasalesService } from 'src/app/services/qasales.service';
import { ActivatedRoute, Router} from '@angular/router';
import { ReportRepairByOrder } from 'src/app/models/reportRepairByOrder';
import { LoadingController, NavController, ModalController } from '@ionic/angular';
import { OrderStatusDetail } from 'src/app/models/orderStatusDetail';
import { PopupReportrepairItemPage } from '../popup-reportrepair-item/popup-reportrepair-item.page';

@Component({
  selector: 'app-report-repair-byorder',
  templateUrl: './report-repair-byorder.page.html',
  styleUrls: ['./report-repair-byorder.page.scss'],
})
export class ReportRepairByorderPage implements OnInit, OnDestroy {

  sub1: Subscription;
  sub2: Subscription;
  sub3: Subscription;
  reasonReport: ReportRepairByOrder[];
  orderItems: OrderStatusDetail[];
  orderItemsGet: OrderStatusDetail[];
  orderNumber: string;

  sum1 = 0;
  sum2 = 0;

  selectGet = false;


  constructor(private router: Router,
              private route: ActivatedRoute,
              private service: QasalesService,
              private loadingCtrl: LoadingController,
              private nav: NavController,
              private modal: ModalController) {
                this.orderNumber = this.route.snapshot.paramMap.get('orderNumber');
              }

  ngOnInit() {
    this.loadData();
    this.selectGet = false;
  }

  async loadData() {
    const loading = await this.loadingCtrl.create({
      spinner: 'bubbles',
      message: 'กำลังโหลดข้อมูล...'
    });
    await loading.present();
    this.sub1 = this.service.reportRepairbyOrder(this.orderNumber).subscribe(
      (data) => {
        this.reasonReport = data;
        // console.log(this.reasonReport);
      },
    async (error) => {
      console.log(error);
      await loading.dismiss();
    },
    async () => {
      this.sub2 = this.service.getOrderDetail(this.orderNumber).subscribe(
        (data2) => {
        this.orderItems = data2;
        this.orderItemsGet = data2;
        // console.log(this.orderItems);
      },
      async (err) => {
        console.log(err);
      },
      async () => {
        this.sumValues();
        await loading.dismiss();
      });
    });
  }

  getSum() {
    this.selectGet = !this.selectGet;
    this.orderItems = this.orderItemsGet;
    if (this.selectGet) {
      this.orderItems = this.orderItems.filter((sum: OrderStatusDetail) => {
      return (sum.SumRepair > 0);
      }),
      this.sumValues();
    } else {
      this.orderItems = this.orderItemsGet;
      this.sumValues();
    }
  }

  sumValues() {
    this.sum1 = this.sum2 = 0;
    this.orderItems.forEach((item) => {
      this.sum1 = this.sum1 + item.TotalQty;
      this.sum2 = this.sum2 + item.SumRepair;
    });
  }

  backToOrderStatus() {
    this.nav.navigateBack(['/orderitems']);
  }

  async openModalReportRepair(i: OrderStatusDetail) {
    // console.log(i);
    if (i.SumRepair > 0) {
      const modal = await this.modal.create({
        component: PopupReportrepairItemPage,
        componentProps: {
          product: i,
        }
      });
      modal.onWillDismiss().then(dataReturn => {
        // console.log(dataReturn);
      });
      return await modal.present();
    }

  }

  ngOnDestroy() {
    this.sub1.unsubscribe();
    this.sub2.unsubscribe();
  }

}
