export interface HeaderDetail {
        orderNumber: string,
        thaiDate: string,
        DueDate: Date,
        totalQty: number,
        finishQty: number,
        totalRepairSum: number,
        dateLate: number,
        repairQty: number,
        qaQty: number,
        fac: number,
        avatar: string,
        Balance: number

}