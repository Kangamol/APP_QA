export interface RepairReceiveItems {
    bill_Item: number;
    NewPict: string;
    ProductCode: string;
    Qty: number;
    repairTypeID: number;
    repairTypeDesc: string;
    RepairFinish: number;
    ToQa: number;
    repair_Item: number;
    reviseQty: number;
    qaBill_ID: number;

}

