export interface ReportRepairByOrder {
        qaDocNumber: string;
        qaBill_ID: number;
        qaRepair_ID: number;
        OrderNumber: string;
        bill_Item: number;
        ProductCode: string;
        TotalQA: number;
        TotalRepair: number;
        repairType: string;
        reasonType: string;
        Qty: number;
        repairDate: Date;
        OrderItemNo: number;
}
