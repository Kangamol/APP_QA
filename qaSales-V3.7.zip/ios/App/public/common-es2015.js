(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["common"],{

/***/ "./node_modules/@ionic/core/dist/esm/button-active-4b76b5c3.js":
/*!*********************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/button-active-4b76b5c3.js ***!
  \*********************************************************************/
/*! exports provided: c */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return createButtonActiveGesture; });
/* harmony import */ var _index_29df6f59_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index-29df6f59.js */ "./node_modules/@ionic/core/dist/esm/index-29df6f59.js");
/* harmony import */ var _index_eea61379_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index-eea61379.js */ "./node_modules/@ionic/core/dist/esm/index-eea61379.js");
/* harmony import */ var _haptic_7b8ba70a_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./haptic-7b8ba70a.js */ "./node_modules/@ionic/core/dist/esm/haptic-7b8ba70a.js");




const createButtonActiveGesture = (el, isButton) => {
    let currentTouchedButton;
    let initialTouchedButton;
    const activateButtonAtPoint = (x, y, hapticFeedbackFn) => {
        if (typeof document === 'undefined') {
            return;
        }
        const target = document.elementFromPoint(x, y);
        if (!target || !isButton(target)) {
            clearActiveButton();
            return;
        }
        if (target !== currentTouchedButton) {
            clearActiveButton();
            setActiveButton(target, hapticFeedbackFn);
        }
    };
    const setActiveButton = (button, hapticFeedbackFn) => {
        currentTouchedButton = button;
        if (!initialTouchedButton) {
            initialTouchedButton = currentTouchedButton;
        }
        const buttonToModify = currentTouchedButton;
        Object(_index_29df6f59_js__WEBPACK_IMPORTED_MODULE_0__["w"])(() => buttonToModify.classList.add('ion-activated'));
        hapticFeedbackFn();
    };
    const clearActiveButton = (dispatchClick = false) => {
        if (!currentTouchedButton) {
            return;
        }
        const buttonToModify = currentTouchedButton;
        Object(_index_29df6f59_js__WEBPACK_IMPORTED_MODULE_0__["w"])(() => buttonToModify.classList.remove('ion-activated'));
        /**
         * Clicking on one button, but releasing on another button
         * does not dispatch a click event in browsers, so we
         * need to do it manually here. Some browsers will
         * dispatch a click if clicking on one button, dragging over
         * another button, and releasing on the original button. In that
         * case, we need to make sure we do not cause a double click there.
         */
        if (dispatchClick && initialTouchedButton !== currentTouchedButton) {
            currentTouchedButton.click();
        }
        currentTouchedButton = undefined;
    };
    return Object(_index_eea61379_js__WEBPACK_IMPORTED_MODULE_1__["createGesture"])({
        el,
        gestureName: 'buttonActiveDrag',
        threshold: 0,
        onStart: ev => activateButtonAtPoint(ev.currentX, ev.currentY, _haptic_7b8ba70a_js__WEBPACK_IMPORTED_MODULE_2__["a"]),
        onMove: ev => activateButtonAtPoint(ev.currentX, ev.currentY, _haptic_7b8ba70a_js__WEBPACK_IMPORTED_MODULE_2__["b"]),
        onEnd: () => {
            clearActiveButton(true);
            Object(_haptic_7b8ba70a_js__WEBPACK_IMPORTED_MODULE_2__["h"])();
            initialTouchedButton = undefined;
        }
    });
};




/***/ }),

/***/ "./node_modules/@ionic/core/dist/esm/framework-delegate-d1eb6504.js":
/*!**************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/framework-delegate-d1eb6504.js ***!
  \**************************************************************************/
/*! exports provided: a, d */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return attachComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return detachComponent; });
const attachComponent = async (delegate, container, component, cssClasses, componentProps) => {
    if (delegate) {
        return delegate.attachViewToDom(container, component, componentProps, cssClasses);
    }
    if (typeof component !== 'string' && !(component instanceof HTMLElement)) {
        throw new Error('framework delegate is missing');
    }
    const el = (typeof component === 'string')
        ? container.ownerDocument && container.ownerDocument.createElement(component)
        : component;
    if (cssClasses) {
        cssClasses.forEach(c => el.classList.add(c));
    }
    if (componentProps) {
        Object.assign(el, componentProps);
    }
    container.appendChild(el);
    if (el.componentOnReady) {
        await el.componentOnReady();
    }
    return el;
};
const detachComponent = (delegate, element) => {
    if (element) {
        if (delegate) {
            const container = element.parentElement;
            return delegate.removeViewFromDom(container, element);
        }
        element.remove();
    }
    return Promise.resolve();
};




/***/ }),

/***/ "./node_modules/@ionic/core/dist/esm/haptic-7b8ba70a.js":
/*!**************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/haptic-7b8ba70a.js ***!
  \**************************************************************/
/*! exports provided: a, b, c, d, h */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return hapticSelectionStart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return hapticSelectionChanged; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return hapticSelection; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return hapticImpact; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "h", function() { return hapticSelectionEnd; });
const HapticEngine = {
    getEngine() {
        const win = window;
        return (win.TapticEngine) || (win.Capacitor && win.Capacitor.isPluginAvailable('Haptics') && win.Capacitor.Plugins.Haptics);
    },
    available() {
        return !!this.getEngine();
    },
    isCordova() {
        return !!window.TapticEngine;
    },
    isCapacitor() {
        const win = window;
        return !!win.Capacitor;
    },
    impact(options) {
        const engine = this.getEngine();
        if (!engine) {
            return;
        }
        const style = this.isCapacitor() ? options.style.toUpperCase() : options.style;
        engine.impact({ style });
    },
    notification(options) {
        const engine = this.getEngine();
        if (!engine) {
            return;
        }
        const style = this.isCapacitor() ? options.style.toUpperCase() : options.style;
        engine.notification({ style });
    },
    selection() {
        this.impact({ style: 'light' });
    },
    selectionStart() {
        const engine = this.getEngine();
        if (!engine) {
            return;
        }
        if (this.isCapacitor()) {
            engine.selectionStart();
        }
        else {
            engine.gestureSelectionStart();
        }
    },
    selectionChanged() {
        const engine = this.getEngine();
        if (!engine) {
            return;
        }
        if (this.isCapacitor()) {
            engine.selectionChanged();
        }
        else {
            engine.gestureSelectionChanged();
        }
    },
    selectionEnd() {
        const engine = this.getEngine();
        if (!engine) {
            return;
        }
        if (this.isCapacitor()) {
            engine.selectionEnd();
        }
        else {
            engine.gestureSelectionEnd();
        }
    }
};
/**
 * Trigger a selection changed haptic event. Good for one-time events
 * (not for gestures)
 */
const hapticSelection = () => {
    HapticEngine.selection();
};
/**
 * Tell the haptic engine that a gesture for a selection change is starting.
 */
const hapticSelectionStart = () => {
    HapticEngine.selectionStart();
};
/**
 * Tell the haptic engine that a selection changed during a gesture.
 */
const hapticSelectionChanged = () => {
    HapticEngine.selectionChanged();
};
/**
 * Tell the haptic engine we are done with a gesture. This needs to be
 * called lest resources are not properly recycled.
 */
const hapticSelectionEnd = () => {
    HapticEngine.selectionEnd();
};
/**
 * Use this to indicate success/failure/warning to the user.
 * options should be of the type `{ style: 'light' }` (or `medium`/`heavy`)
 */
const hapticImpact = (options) => {
    HapticEngine.impact(options);
};




/***/ }),

/***/ "./node_modules/@ionic/core/dist/esm/spinner-configs-c78e170e.js":
/*!***********************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/spinner-configs-c78e170e.js ***!
  \***********************************************************************/
/*! exports provided: S */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "S", function() { return SPINNERS; });
const spinners = {
    'bubbles': {
        dur: 1000,
        circles: 9,
        fn: (dur, index, total) => {
            const animationDelay = `${(dur * index / total) - dur}ms`;
            const angle = 2 * Math.PI * index / total;
            return {
                r: 5,
                style: {
                    'top': `${9 * Math.sin(angle)}px`,
                    'left': `${9 * Math.cos(angle)}px`,
                    'animation-delay': animationDelay,
                }
            };
        }
    },
    'circles': {
        dur: 1000,
        circles: 8,
        fn: (dur, index, total) => {
            const step = index / total;
            const animationDelay = `${(dur * step) - dur}ms`;
            const angle = 2 * Math.PI * step;
            return {
                r: 5,
                style: {
                    'top': `${9 * Math.sin(angle)}px`,
                    'left': `${9 * Math.cos(angle)}px`,
                    'animation-delay': animationDelay,
                }
            };
        }
    },
    'circular': {
        dur: 1400,
        elmDuration: true,
        circles: 1,
        fn: () => {
            return {
                r: 20,
                cx: 48,
                cy: 48,
                fill: 'none',
                viewBox: '24 24 48 48',
                transform: 'translate(0,0)',
                style: {}
            };
        }
    },
    'crescent': {
        dur: 750,
        circles: 1,
        fn: () => {
            return {
                r: 26,
                style: {}
            };
        }
    },
    'dots': {
        dur: 750,
        circles: 3,
        fn: (_, index) => {
            const animationDelay = -(110 * index) + 'ms';
            return {
                r: 6,
                style: {
                    'left': `${9 - (9 * index)}px`,
                    'animation-delay': animationDelay,
                }
            };
        }
    },
    'lines': {
        dur: 1000,
        lines: 12,
        fn: (dur, index, total) => {
            const transform = `rotate(${30 * index + (index < 6 ? 180 : -180)}deg)`;
            const animationDelay = `${(dur * index / total) - dur}ms`;
            return {
                y1: 17,
                y2: 29,
                style: {
                    'transform': transform,
                    'animation-delay': animationDelay,
                }
            };
        }
    },
    'lines-small': {
        dur: 1000,
        lines: 12,
        fn: (dur, index, total) => {
            const transform = `rotate(${30 * index + (index < 6 ? 180 : -180)}deg)`;
            const animationDelay = `${(dur * index / total) - dur}ms`;
            return {
                y1: 12,
                y2: 20,
                style: {
                    'transform': transform,
                    'animation-delay': animationDelay,
                }
            };
        }
    }
};
const SPINNERS = spinners;




/***/ }),

/***/ "./node_modules/@ionic/core/dist/esm/theme-3f0b0c04.js":
/*!*************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/theme-3f0b0c04.js ***!
  \*************************************************************/
/*! exports provided: c, g, h, o */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return createColorClasses; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "g", function() { return getClassMap; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "h", function() { return hostContext; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "o", function() { return openURL; });
const hostContext = (selector, el) => {
    return el.closest(selector) !== null;
};
/**
 * Create the mode and color classes for the component based on the classes passed in
 */
const createColorClasses = (color) => {
    return (typeof color === 'string' && color.length > 0) ? {
        'ion-color': true,
        [`ion-color-${color}`]: true
    } : undefined;
};
const getClassList = (classes) => {
    if (classes !== undefined) {
        const array = Array.isArray(classes) ? classes : classes.split(' ');
        return array
            .filter(c => c != null)
            .map(c => c.trim())
            .filter(c => c !== '');
    }
    return [];
};
const getClassMap = (classes) => {
    const map = {};
    getClassList(classes).forEach(c => map[c] = true);
    return map;
};
const SCHEME = /^[a-z][a-z0-9+\-.]*:/;
const openURL = async (url, ev, direction, animation) => {
    if (url != null && url[0] !== '#' && !SCHEME.test(url)) {
        const router = document.querySelector('ion-router');
        if (router) {
            if (ev != null) {
                ev.preventDefault();
            }
            return router.push(url, direction, animation);
        }
    }
    return false;
};




/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/qastatus/qa-finish-master/qa-finish-master.page.html":
/*!*****************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/qastatus/qa-finish-master/qa-finish-master.page.html ***!
  \*****************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar class=\"heigth50\">\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"backToQaStatus()\">\n        <ion-icon name=\"arrow-back\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-title class=\"fontPromptBold fontSize26\">ประวัติการตรวจงานเสร็จ</ion-title>\n\n    <ion-buttons slot=\"end\" >\n      <ion-button (click)=\"onClickRefresh()\">\n        <ion-icon slot=\"icon-only\" name=\"refresh\" size=\"large\"></ion-icon>\n      </ion-button>\n      <ion-button (click)=\"showSearch()\">\n        <ion-icon slot=\"icon-only\" name=\"search\" size=\"large\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n\n\n\n  <!-- Login -->\n  <ion-toolbar>\n    <ion-grid>\n      <ion-row [ngClass]=\"{'backgroundPink': user[0].saleManager == '2', 'backgroundBlue': user[0].saleManager == '1,3'}\">\n  \n        <ion-col size=\"1\">\n          <ion-avatar>\n            <img src=\"{{user[0].userPicture}}\">\n          </ion-avatar>\n        </ion-col>\n  \n        <ion-col size=\"5\" class=\"padingTop\">\n          <ion-text  class=\"fontPromptBold fontSize20  ion-text-left \">&nbsp;Login : {{user[0].fullName}}({{user[0].nickName}})</ion-text>\n        </ion-col>\n  \n        <ion-col size=\"5\" class=\"padingTop\">\n          <ion-text  class=\"fontPromptBold fontSize20 ion-text-left \">&nbsp;Team : {{user[0].saleTeam}}</ion-text>\n        </ion-col>\n      </ion-row>\n     </ion-grid> \n  \n    </ion-toolbar>\n\n  <ion-grid>\n\n    <ion-toolbar *ngIf=\"search\">\n      <ion-searchbar placeholder=\"Find OrderNumber\" debounce=\"500\"  (ionChange)=\"getBill($event)\"></ion-searchbar>\n    </ion-toolbar>\n\n    <ion-item color=\"primary\">\n\n\n      <ion-label  fixed class=\"fixed20 align\" >    \n        <ion-text>\n          <h2 class=\"fontPromptRegular align\">วันที่ตรวจงานเสร็จ</h2>\n        </ion-text>\n    </ion-label>\n  \n      <ion-label  fixed class=\"fixed35 align\">    \n          <ion-text>\n            <h1 class=\"fontPromptRegular\">Description</h1>\n          </ion-text>\n       \n      </ion-label>\n  \n      <ion-label class=\"fixed20 align\">\n        <h2 class=\"fontPromptRegular\">จำนวนที่ตรวจเสร็จ</h2>\n      </ion-label>\n\n      <ion-label class=\"fixed20 align\">\n        <h2 class=\"fontPromptRegular\">ผู้ส่งงานตรวจเสร็จ</h2>\n      </ion-label>\n  \n    </ion-item>\n  \n  </ion-grid>\n\n        <!-- Summary -->\n        <ion-row>\n          <ion-col>\n  \n            <ion-item color=\"light\">\n              <!-- <ion-col size=\"1\"></ion-col> -->\n              <ion-col size=\"7\" class=\"ion-text-right\">\n                <ion-label><div class=\"fontPromptBold fontSize24\">ยอดรวม : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div></ion-label>\n              </ion-col>\n    \n              <ion-col size=\"2\" class=\"ion-text-center\" >\n                <ion-label color=\"primary\">\n                  <ion-text class=\"fontPromptBold fontSize24\">\n                    {{ sum1 | number }}\n                  </ion-text>\n                </ion-label>\n              </ion-col>\n    \n  \n            </ion-item>\n          </ion-col>\n        </ion-row>\n  \n\n</ion-header>\n\n<ion-content>\n\n  <ion-item *ngFor=\"let i of qaFinishMaster\" (click)=\"goToqaFinishDetail(i)\" detail>\n\n    <ion-label  fixed class=\"fixed20 align\">    \n      <ion-text>\n        <h2 class=\"fontPromptRegular align\">({{i.thaiDate}})&nbsp;{{i.receiveDate | date:'dd/MM/yyyy':\"+0000\"}}</h2>\n        <h3 class=\"fontPromptRegular align colorFontGray\">เวลา : {{i.receiveDate | date: 'HH:mm' : '+0'}}</h3>\n      </ion-text>\n  </ion-label>\n\n    <ion-label  fixed class=\"fixed35 align\">    \n        <ion-text>\n          <h2 class=\"fontPromptBold\">{{i.OrderNumber}}</h2>\n          <p class=\"fontPromptRegular colorFontGray\">เลขที่บิล : {{i.qaDocNumber}}</p>\n        </ion-text>\n     \n    </ion-label>\n\n    <ion-label class=\"fixed20 align\" color=\"primary\">\n      <h1 class=\"fontPromptRegular\">{{i.TotalQaFinish}}</h1>\n    </ion-label>\n\n    <ion-label class=\"fixed20 align\">\n      <h2 class=\"fontPromptRegular\">{{i.fullName}}({{i.nickName}})</h2>\n    </ion-label>\n\n  </ion-item>\n\n</ion-content>\n");

/***/ }),

/***/ "./src/app/services/qasales.service.ts":
/*!*********************************************!*\
  !*** ./src/app/services/qasales.service.ts ***!
  \*********************************************/
/*! exports provided: QasalesService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QasalesService", function() { return QasalesService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");



let QasalesService = class QasalesService {
    constructor(http) {
        this.http = http;
        this.mainApi = 'http://172.16.0.19:3000/';
    }
    // แสดงข้อมูลสถานะของแต่ละ Order Tab4
    getOrderStatus(saleID) {
        return this.http.get(`${this.mainApi}orderStatusSales/${saleID}`);
    }
    // แสดงข้อมูลสถานะของแต่ละ Item ของ Order Tab4
    getOrderDetail(orderNumber) {
        return this.http.get(`${this.mainApi}OrderDetailSale?orderNumber=${orderNumber}`);
    }
    // ดึงข้อมูล Report งานซ่อม แบบ Order
    reportRepairbyOrder(orderNumber) {
        return this.http.get(`${this.mainApi}reportRepairbyorder?orderNumber=${orderNumber}`);
    }
    // ดึงข้อมูล Report งานซ่อม แบบItem Popup
    reportRepairbyItem(orderNumber, OrderItem) {
        return this.http.get(`${this.mainApi}reportRepairbyitem/${OrderItem}?orderNumber=${orderNumber}`);
    }
    // (TAB1 หน้าดึงรูป เปลี่ยนรูป TAB 1)
    appUser(userid) {
        return this.http.get(`${this.mainApi}getuser/${userid}`);
    }
    // (สถานะงานในกแผนก QA TAB 2 )
    qaStatus(manager) {
        return this.http.get(`${this.mainApi}qaStatus/${manager}`);
    }
    // (สถานะงานในกแผนก QA กดเข้าไปดูเป็นรายการเพื่อนำไปQA เสร็จหรือส่งซ่อม TAB 2 )
    qaStatusDetail(billID) {
        return this.http.get(this.mainApi + 'qaStatusItems/' + billID);
    }
    // (รับงานจา่กFac เข้า แผนก QA TAB 3)
    qaBillReceive(saleManger) {
        return this.http.get(`${this.mainApi}qabillreceive/${saleManger}`);
    }
    // (กดรับงานจากFac เข้าแผนก QA Detail TAB 3)
    qaItemsReceive(billID) {
        return this.http.get(`${this.mainApi}qaBillReceiveitems/${billID}`);
    }
    // (ดูสถานะการซ่อม และ หน้าแรกของกดรับงานซ่อม TAB4)
    statusRepairMaster(sales) {
        return this.http.get(`${this.mainApi}qaStatusRepair/${sales}`);
    }
    // (รับงานซ่อมที่กลับมาจากผลิต TAB4 Detail)
    repairReceiveItems(repairID) {
        return this.http.get(`${this.mainApi}repairbillreceivefacitems/${repairID}`);
    }
    // แสดงสถานะของOrder TAB5
    // statusOrder(fact: string): Observable<StatusOrder[]> {
    //   return this.http.get<StatusOrder[]>(`${this.mainApi}wipfact/${fact}`);
    // }
    // ยืนยันรับงานที่ส่งลงมาจากฝ่ายผลิต TAB 2(เปลี่ยนสถานะ)
    confirmBillreceive(billID, status) {
        return this.http.put(`${this.mainApi}updateQaBillStatus/${billID}/${status}`, {});
    }
    // ยืนยันรับงานที่ส่งลงมาจากฝ่ายผลิต TAB 2(แสดงชื่อ และ วันที่รับ)
    confirmBillreceiveShowUser(billID, receiver) {
        return this.http.put(`${this.mainApi}updateQaBillReceiver/${billID}/${receiver}`, {});
    }
    // ยืนยันรับงานซ่อม ใส่ข้อมูลไปที่ ToQA Tab3 รับงานซ่อม
    updateQaRepairBillFinishQty(repairID, repairItem, ToQa) {
        return this.http.put(`${this.mainApi}updateQaRepairBillFinishQty/${repairID}/${repairItem}/${ToQa}`, {});
    }
    // ยืนยันส่งงานไปซ่อม เช็คข้อมูลว่า RepairFinish เท่ากับ QTY หรือยัง Tab3 รับงานซ่อม
    checkRepairBillFinish(repairID) {
        return this.http.get(`${this.mainApi}checkRepairBillFinish/${repairID}`);
    }
    // อัพเดท Status ของรับงานซ่อม เมื่อ RepairFinish เท่ากับ QTY เมื่องานครบ Tab3 รับงานซ่อม
    updateQaRepairBill(repairID) {
        return this.http.put(`${this.mainApi}updateQaRepairBill/${repairID}`, {});
    }
    insertRepairBillMaster(i) {
        const body = {
            repairDocNumber: i.repairDocNumber,
            qaBill_ID: i.qaBill_ID,
            userID: i.userID,
            OrderNumber: i.OrderNumber,
            receiver: i.receiver
        };
        // console.log('api -> ', body);
        return this.http.post(this.mainApi + 'insertRepairBillMaster', body);
    }
    insertRepairBillDetail(i) {
        // insertRepairBillDetail(i: any) {
        const body = {
            qaRepair_ID: Number(i.qaRepair_ID),
            repair_Item: Number(i.repair_Item),
            bill_Item: Number(i.bill_Item),
            repairTypeID: Number(i.repairTypeID),
            Qty: Number(i.Qty)
        };
        // console.log('i service = ', i);
        // console.log('body service = ', body);
        // return true;
        return this.http.post(this.mainApi + 'insertRepairBillDetail', body);
    }
    // แสดงข้อมูลอาการเสีย Input 1 PopupRepair
    repairTypeMaster() {
        return this.http.get(`${this.mainApi}repairTypeMaster`);
    }
    // แสดงข้อมูลอาการเสีย โดยส่ง Value Input 1 มา Input 2 PopupRepair
    repairTypeDetail(typeID) {
        return this.http.get(`${this.mainApi}repairTypeDetail/${typeID}`);
    }
    // แสดงข้อมูลอาการเสีย โดยส่งไม่ได้ส่งค่าอะไรมา
    repairTypeDetail2() {
        return this.http.get(`${this.mainApi}repairTypeDetail*`);
    }
    // ยืนยันงานตรวจเสร็จ Master Tab1 qaStatus
    insertFinishMaster(i) {
        const body = {
            finishDocNumber: i.finishDocNumber,
            qaBill_ID: i.qaBill_ID,
            userID: i.userID,
            OrderNumber: i.OrderNumber,
            receiver: i.receiver
        };
        // console.log('api -> ', body);
        return this.http.post(this.mainApi + 'insertFinishMaster', body);
    }
    // ยืนยันงานตรวจเสร็จ Detail Tab1 qaStatus
    insertFinishDetail(i) {
        const body = {
            qaFinish_ID: Number(i.qaFinish_ID),
            finish_Item: Number(i.finish_Item),
            bill_Item: Number(i.bill_Item),
            Qty: Number(i.Qty)
        };
        // console.log('i service = ', i);
        // console.log('body service = ', body);
        // return true;
        return this.http.post(this.mainApi + 'insertFinishDetail', body);
    }
    // ใส่เหตุผลอาการเสียตอนส่งซ่อม Tab1 qaStatus
    insertRepairReason(i) {
        const body = {
            qaRepairID: Number(i.qaRepairID),
            repairItem: Number(i.repairItem),
            reasonNo: i.reasonNo,
            typeID: i.typeID,
            Qty: Number(i.Qty)
        };
        // console.log('แสดงอาการเสีย = ', body);
        return this.http.post(this.mainApi + 'insertRepairReason', body);
    }
    // Qa เสร็จ Master Tab1
    qaFinishMaster(sales) {
        return this.http.get(`${this.mainApi}qaFinishMaster/${sales}`);
    }
    // Qa เสร็จ Detail Tab1
    qaFinishDetail(finishID) {
        return this.http.get(`${this.mainApi}qaFinishDetail/${finishID}`);
    }
    // แสดงอาการเสีย
    repairTypePopup(repairID, repairItem) {
        return this.http.get(`${this.mainApi}getRepairReason/${repairID}/${repairItem}`);
    }
    // เช็คค่า QTY ในบิลซ่อม ไม่ให้เกิน Bill
    checkQtyRepair(billID, billItem) {
        return this.http.get(`${this.mainApi}checkQtyRepair/${billID}/${billItem}`);
    }
    // ยกเลิกบิลซ่อม
    cancelBillRepair(repairID) {
        return this.http.put(`${this.mainApi}cancelBillRepair/${repairID}`, {});
    }
    // ดูอาการเสีย
    getRepairReason(repairID, repairItem) {
        return this.http.get(this.mainApi + 'getRepairReason/' + repairID + '/' + repairItem);
    }
    repairFinishMaster(salesID) {
        return this.http.get(`${this.mainApi}repairFinishMaster/${salesID}`);
    }
};
QasalesService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
QasalesService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], QasalesService);



/***/ }),

/***/ "./src/app/tabs/qastatus/qa-finish-master/qa-finish-master-routing.module.ts":
/*!***********************************************************************************!*\
  !*** ./src/app/tabs/qastatus/qa-finish-master/qa-finish-master-routing.module.ts ***!
  \***********************************************************************************/
/*! exports provided: QaFinishMasterPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QaFinishMasterPageRoutingModule", function() { return QaFinishMasterPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _qa_finish_master_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./qa-finish-master.page */ "./src/app/tabs/qastatus/qa-finish-master/qa-finish-master.page.ts");




const routes = [
    {
        path: '',
        component: _qa_finish_master_page__WEBPACK_IMPORTED_MODULE_3__["QaFinishMasterPage"]
    },
    {
        path: 'qa-finish-detail',
        loadChildren: () => __webpack_require__.e(/*! import() | qa-finish-detail-qa-finish-detail-module */ "default~qa-finish-detail-qa-finish-detail-module~tabs-qastatus-qa-finish-master-qa-finish-detail-qa-~59da3f9e").then(__webpack_require__.bind(null, /*! ./qa-finish-detail/qa-finish-detail.module */ "./src/app/tabs/qastatus/qa-finish-master/qa-finish-detail/qa-finish-detail.module.ts")).then(m => m.QaFinishDetailPageModule)
    }
];
let QaFinishMasterPageRoutingModule = class QaFinishMasterPageRoutingModule {
};
QaFinishMasterPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], QaFinishMasterPageRoutingModule);



/***/ }),

/***/ "./src/app/tabs/qastatus/qa-finish-master/qa-finish-master.module.ts":
/*!***************************************************************************!*\
  !*** ./src/app/tabs/qastatus/qa-finish-master/qa-finish-master.module.ts ***!
  \***************************************************************************/
/*! exports provided: QaFinishMasterPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QaFinishMasterPageModule", function() { return QaFinishMasterPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _qa_finish_master_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./qa-finish-master-routing.module */ "./src/app/tabs/qastatus/qa-finish-master/qa-finish-master-routing.module.ts");
/* harmony import */ var _qa_finish_master_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./qa-finish-master.page */ "./src/app/tabs/qastatus/qa-finish-master/qa-finish-master.page.ts");







let QaFinishMasterPageModule = class QaFinishMasterPageModule {
};
QaFinishMasterPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _qa_finish_master_routing_module__WEBPACK_IMPORTED_MODULE_5__["QaFinishMasterPageRoutingModule"]
        ],
        declarations: [_qa_finish_master_page__WEBPACK_IMPORTED_MODULE_6__["QaFinishMasterPage"]]
    })
], QaFinishMasterPageModule);



/***/ }),

/***/ "./src/app/tabs/qastatus/qa-finish-master/qa-finish-master.page.scss":
/*!***************************************************************************!*\
  !*** ./src/app/tabs/qastatus/qa-finish-master/qa-finish-master.page.scss ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3RhYnMvcWFzdGF0dXMvcWEtZmluaXNoLW1hc3Rlci9xYS1maW5pc2gtbWFzdGVyLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/tabs/qastatus/qa-finish-master/qa-finish-master.page.ts":
/*!*************************************************************************!*\
  !*** ./src/app/tabs/qastatus/qa-finish-master/qa-finish-master.page.ts ***!
  \*************************************************************************/
/*! exports provided: QaFinishMasterPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QaFinishMasterPage", function() { return QaFinishMasterPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/auth/auth.service */ "./src/app/auth/auth.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _services_qasales_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./../../../services/qasales.service */ "./src/app/services/qasales.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");







let QaFinishMasterPage = class QaFinishMasterPage {
    constructor(authService, loadingCtrl, service, nav, route) {
        this.authService = authService;
        this.loadingCtrl = loadingCtrl;
        this.service = service;
        this.nav = nav;
        this.route = route;
        this.search = false;
        this.sum1 = 0;
    }
    ngOnInit() {
        this.user = this.authService.getUserInfo();
    }
    ionViewWillEnter() {
        this.search = false;
        this.user = this.authService.getUserInfo();
        if (!this.user) {
            this.route.navigateByUrl('/auth');
        }
        else {
            // console.log(this.user[0].saleManager);
            this.loaddata();
        }
    }
    loaddata() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingCtrl.create({
                spinner: 'bubbles',
                message: 'กำลังโหลด'
            });
            yield loading.present();
            this.sub = this.service.qaFinishMaster(this.user[0].saleManager).subscribe((data) => {
                this.qaFinishMaster = data;
                //  console.log(this.qaFinishMaster);
            }, (err) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                console.log(err);
                yield loading.dismiss();
            }), () => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                this.sum1 = 0;
                this.qaFinishMaster.forEach((item) => {
                    this.sum1 = this.sum1 + item.TotalQaFinish;
                });
                yield loading.dismiss();
            }));
        });
    }
    goToqaFinishDetail(i) {
        this.nav.navigateForward(['/qafinish-detail', {
                finishID: i.qaFinish_ID,
                OrderNumber: i.OrderNumber,
                fullName: i.fullName,
                date: i.receiveDate,
                thaiDate: i.thaiDate,
                qaDoc: i.qaDocNumber,
                showIcon: i.showIcon,
                avatar: i.avatar,
                nickName: i.nickName
            }]);
    }
    showSearch() {
        this.search = !this.search;
    }
    getBill(ev) {
        const val = ev.target.value;
        if (val && val.trim() !== '') {
            this.qaFinishMaster = this.qaFinishMaster.filter((bill) => {
                return (bill.OrderNumber.toLowerCase().indexOf(val.toLowerCase()) > -1);
            });
            this.sum1 = 0;
            this.qaFinishMaster.forEach((item) => {
                this.sum1 = this.sum1 + item.TotalQaFinish;
            });
        }
        else {
            this.loaddata();
        }
    }
    onClickRefresh() {
        this.loaddata();
    }
    backToQaStatus() {
        this.nav.navigateBack(['/tabs/qastatus']);
    }
    ngOnDestroy() {
        this.sub.unsubscribe();
    }
};
QaFinishMasterPage.ctorParameters = () => [
    { type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"] },
    { type: _services_qasales_service__WEBPACK_IMPORTED_MODULE_4__["QasalesService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] }
];
QaFinishMasterPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-qa-finish-master',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./qa-finish-master.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/qastatus/qa-finish-master/qa-finish-master.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./qa-finish-master.page.scss */ "./src/app/tabs/qastatus/qa-finish-master/qa-finish-master.page.scss")).default]
    })
], QaFinishMasterPage);



/***/ })

}]);
//# sourceMappingURL=common-es2015.js.map