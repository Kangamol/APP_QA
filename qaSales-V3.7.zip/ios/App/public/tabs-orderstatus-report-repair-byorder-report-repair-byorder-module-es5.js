function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tabs-orderstatus-report-repair-byorder-report-repair-byorder-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.html":
  /*!**********************************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.html ***!
    \**********************************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppTabsOrderstatusPopupReportrepairItemPopupReportrepairItemPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-title class=\"fontPromptBold fontSize20\">รายการซ่อม</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n\n\n    <div align=\"center\">\n      <ion-img src=\"{{product.NewPict}}\" style=\"width: 250px;\"></ion-img>\n      <h3 class=\" fontPromptRegular\">{{product.ProductCode}}</h3>\n    </div>\n\n\n    <ion-item color=\"light\" >\n\n\n      <ion-label class=\"fixed50 ion-text-center\">\n        <ion-text class=\"fontPromptRegular fontSize18\">\n         จำนวนงานของ Order :  {{product.TotalQty}}\n        </ion-text>\n      </ion-label>\n\n      <ion-label class=\"fixed50 ion-text-center\">\n        <ion-text class=\"fontPromptRegular fontSize18\">\n         ยอดซ่อมทั้งหมด : {{sum}} \n         <ion-text class=\"fontPromptBold fontSize20\" color=\"warning\">= {{(sum/product.TotalQty)*100 | number:'1.0-1'}}%</ion-text>\n        </ion-text>\n      </ion-label>\n\n \n\n    </ion-item>\n\n    \n      <ion-item color=\"warning\" >\n        <ion-label class=\"fixed15 ion-text-center\">\n          <ion-text class=\"fontPromptRegular fontSize16\">\n            วันที่ส่งซ่อม\n          </ion-text>\n        </ion-label>\n\n        <ion-label class=\"fixed30 ion-text-center\">\n          <ion-text class=\"fontPromptRegular fontSize16\">\n            เลขที่บิล QA\n          </ion-text>\n        </ion-label>\n\n        <ion-label class=\"fixed40 ion-text-center\">\n          <ion-text class=\"fontPromptRegular fontSize16\">\n            อาการที่ซ่อม\n          </ion-text>\n        </ion-label>\n\n        <ion-label class=\"fixed10 ion-text-center\">\n          <ion-text class=\"fontPromptRegular fontSize16\">\n            จำนวน\n          </ion-text>\n        </ion-label>\n      </ion-item>\n\n\n\n\n      <ion-item  *ngFor=\"let i of ReportRepairItem\">\n          <ion-label class=\"fixed15 ion-text-center\">\n            <ion-text class=\"fontPromptRegular fontSize16\">\n              {{i.repairDate | date:\"dd/MM/yy\":\"+0000\" }}<br>\n              <ion-text class=\"colorFontGray\">{{i.repairDate | date: 'HH:mm' : '+0' }} น.</ion-text>\n            </ion-text>\n          </ion-label>\n\n          <ion-label class=\"fixed30 ion-text-center\">\n            <ion-text class=\"fontPromptRegular fontSize16\">\n              {{i.qaDocNumber}}\n            </ion-text>\n          </ion-label>\n  \n          <ion-label class=\"fixed40 ion-text-center\">\n            <ion-text class=\"fontPromptRegular fontSize16\">\n              {{i.repairType}}-{{i.reasonType}}\n            </ion-text>\n          </ion-label>\n  \n          <ion-label class=\"fixed10 ion-text-center\">\n            <ion-text class=\"fontPromptRegular fontSize16\">\n              {{i.Qty}}\n            </ion-text>\n          </ion-label>\n      </ion-item>\n\n\n\n    <div align=\"center\">\n      <br><br><br>\n      <ion-button color=\"danger\" (click)=\"closeModal()\">&nbsp;&nbsp;&nbsp;&nbsp;ปิด&nbsp;&nbsp;&nbsp;&nbsp;</ion-button>\n    </div>\n\n</ion-content>\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/orderstatus/report-repair-byorder/report-repair-byorder.page.html":
  /*!******************************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/orderstatus/report-repair-byorder/report-repair-byorder.page.html ***!
    \******************************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppTabsOrderstatusReportRepairByorderReportRepairByorderPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-button>\n        <ion-back-button></ion-back-button>\n      </ion-button>\n    </ion-buttons>\n    <ion-title><ion-text class=\"fontSize24 fontPromptBold\">รายการซ่อมของ Order</ion-text></ion-title>\n  </ion-toolbar>\n\n  <ion-toolbar >\n  <ion-title><ion-text color=\"warning\" class=\"fontSize20 fontPromptBold\">{{ orderNumber }}</ion-text></ion-title>\n  </ion-toolbar>\n\n  <ion-item lines=\"none\">\n    <ion-checkbox color=\"warning\" slot=\"start\" (click)=\"getSum()\"></ion-checkbox>\n    <ion-label>\n      <h1  class=\"fontPromptRegular\">\n        เลือกเฉพาะที่มีรายการซ่อม\n      </h1>\n    </ion-label>\n  </ion-item>\n\n  <ion-grid>\n    <ion-row>\n      <ion-col>\n        <ion-item color=\"warning\">\n  \n          <ion-col size=\"0.7\">\n            <ion-label>\n              <ion-text class=\"fontPromptBold ion-text-left\">\n                No.\n              </ion-text>\n            </ion-label>\n          </ion-col>\n  \n          \n          <ion-col size=\"3.3\" class=\"ion-text-center\">\n            <ion-label>\n              <ion-text class=\"fontPromptBold \"> Product </ion-text>\n            </ion-label>\n          </ion-col>\n  \n          <ion-col size=\"1.5\" offset=\"0.5\" class=\"ion-text-center\">\n            <ion-label>\n              <ion-text class=\"fontPromptBold ion-text-center\">\n                จำนวน<br>Order\n              </ion-text>\n            </ion-label>\n          </ion-col>\n  \n          <ion-col size=\"1.5\" offset=\"0.5\" class=\"ion-text-center\">\n            <ion-label>\n              <ion-text class=\"fontPromptBold ion-text-center\">\n                ยอดรวม<br>ที่ซ่อม\n              </ion-text>\n            </ion-label>\n          </ion-col>\n  \n          <ion-col size=\"4\" class=\"ion-text-center\">\n            <ion-label >\n              <ion-text class=\"fontPromptBold ion-text-center\">\n                รายการซ่อม\n              </ion-text>\n            </ion-label>\n          </ion-col>\n  \n        </ion-item>\n      </ion-col>\n    </ion-row>\n\n    <ion-row>\n      <ion-col>\n        <ion-item color=\"light\">\n  \n          <ion-col size=\"4\" class=\"ion-text-center\">\n            <ion-label>\n              <ion-text class=\"fontPromptBold fontSize20\">\n                ยอดรวม\n              </ion-text>\n            </ion-label>\n          </ion-col>\n  \n          <ion-col size=\"1.5\" offset=\"0.5\" class=\"ion-text-center\">\n            <ion-label>\n              <ion-text class=\"fontPromptBold fontSize20\">\n                {{sum1}}\n              </ion-text>\n            </ion-label>\n          </ion-col>\n  \n          <ion-col size=\"1.5\" offset=\"0.5\" class=\"ion-text-center\">\n            <ion-label color=\"warning\">\n              <ion-text class=\"fontPromptBold fontSize20\">\n                {{sum2}}\n              </ion-text>\n            </ion-label>\n          </ion-col>\n  \n          <ion-col size=\"4\" class=\"ion-text-center\">\n            <ion-label >\n              <ion-text class=\"fontPromptBold ion-text-center\">\n                \n              </ion-text>\n            </ion-label>\n          </ion-col>\n  \n        </ion-item>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-header>\n\n<ion-content>\n<ion-grid>\n  <ion-row>\n    <ion-col>\n      <ion-item *ngFor=\"let i of orderItems\" class=\"align\" (click)=\"openModalReportRepair(i)\">\n\n        <ion-col size=\"0.7\">\n          <ion-label>\n            <ion-text class=\"fontPromptRegular ion-text-left\">\n              {{i.ItemNo}}\n            </ion-text>\n          </ion-label>\n        </ion-col>\n\n        \n        <ion-col size=\"3.3\" class=\"ion-text-center\">\n            <img src=\"{{i.NewPict}}\">\n            <ion-text class=\"fontPromptRegular \"> {{i.ProductCode}}</ion-text>\n        </ion-col>\n\n        <ion-col size=\"1.5\" offset=\"0.5\" class=\"ion-text-center\">\n          <ion-label>\n            <ion-text class=\"fontPromptRegular\">\n              {{i.TotalQty}}\n            </ion-text>\n          </ion-label>\n        </ion-col>\n\n        <ion-col size=\"1.5\" offset=\"0.5\" class=\"ion-text-center\">\n          <ion-label color=\"warning\">\n            <ion-text class=\"fontPromptBold fontSize18\">\n              {{i.SumRepair}}<br>\n              <ion-text class=\"fontPromptBold colorFontRed fontSize14\">{{(i.SumRepair / i.TotalQty)*100 | number:'1.0-1'}}%</ion-text>\n            </ion-text>\n          </ion-label>\n        </ion-col>\n\n        <ion-col size=\"4\" offset= \"0.5\"class=\"ion-text-left\">\n          <ion-label  *ngFor=\"let r of reasonReport\"  >\n            <ion-text *ngIf=\"r.OrderItemNo === i.ItemNo\">\n              <h2 class=\"fontPromptRegular\" > {{r.repairType}}-{{r.reasonType}} = {{r.Qty}}</h2>\n            </ion-text>\n          </ion-label>\n        </ion-col>\n\n      </ion-item>\n    </ion-col>\n  </ion-row>\n</ion-grid>\n\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.scss":
  /*!********************************************************************************************!*\
    !*** ./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.scss ***!
    \********************************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppTabsOrderstatusPopupReportrepairItemPopupReportrepairItemPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3RhYnMvb3JkZXJzdGF0dXMvcG9wdXAtcmVwb3J0cmVwYWlyLWl0ZW0vcG9wdXAtcmVwb3J0cmVwYWlyLWl0ZW0ucGFnZS5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.ts":
  /*!******************************************************************************************!*\
    !*** ./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.ts ***!
    \******************************************************************************************/

  /*! exports provided: PopupReportrepairItemPage */

  /***/
  function srcAppTabsOrderstatusPopupReportrepairItemPopupReportrepairItemPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PopupReportrepairItemPage", function () {
      return PopupReportrepairItemPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var src_app_services_qasales_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/services/qasales.service */
    "./src/app/services/qasales.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var PopupReportrepairItemPage = /*#__PURE__*/function () {
      function PopupReportrepairItemPage(service, loadingCtrl, modal) {
        _classCallCheck(this, PopupReportrepairItemPage);

        this.service = service;
        this.loadingCtrl = loadingCtrl;
        this.modal = modal;
      }

      _createClass(PopupReportrepairItemPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          // console.log(this.product);
          this.loadData();
        }
      }, {
        key: "loadData",
        value: function loadData() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var _this = this;

            var loading;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return this.loadingCtrl.create({
                      spinner: 'dots',
                      message: 'กำลังโหลดข้อมูล...'
                    });

                  case 2:
                    loading = _context3.sent;
                    _context3.next = 5;
                    return loading.present();

                  case 5:
                    // start loading
                    this.sub1 = this.service.reportRepairbyItem(this.product.OrderNumber, this.product.ItemNo).subscribe(function (data) {
                      _this.ReportRepairItem = data; // console.log(this.ReportRepairItem);
                    }, function (error) {
                      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                        return regeneratorRuntime.wrap(function _callee$(_context) {
                          while (1) {
                            switch (_context.prev = _context.next) {
                              case 0:
                                console.log(error);
                                _context.next = 3;
                                return loading.dismiss();

                              case 3:
                              case "end":
                                return _context.stop();
                            }
                          }
                        }, _callee);
                      }));
                    }, function () {
                      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
                        var _this2 = this;

                        return regeneratorRuntime.wrap(function _callee2$(_context2) {
                          while (1) {
                            switch (_context2.prev = _context2.next) {
                              case 0:
                                this.sum = 0;
                                this.ReportRepairItem.forEach(function (item) {
                                  _this2.sum = _this2.sum + item.Qty;
                                });
                                _context2.next = 4;
                                return loading.dismiss();

                              case 4:
                              case "end":
                                return _context2.stop();
                            }
                          }
                        }, _callee2, this);
                      }));
                    });

                  case 6:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "closeModal",
        value: function closeModal() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
            return regeneratorRuntime.wrap(function _callee4$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    _context4.next = 2;
                    return this.modal.dismiss();

                  case 2:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee4, this);
          }));
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          this.sub1.unsubscribe();
        }
      }]);

      return PopupReportrepairItemPage;
    }();

    PopupReportrepairItemPage.ctorParameters = function () {
      return [{
        type: src_app_services_qasales_service__WEBPACK_IMPORTED_MODULE_2__["QasalesService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"]
      }];
    };

    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], PopupReportrepairItemPage.prototype, "product", void 0);
    PopupReportrepairItemPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-popup-reportrepair-item',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./popup-reportrepair-item.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./popup-reportrepair-item.page.scss */
      "./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.scss"))["default"]]
    })], PopupReportrepairItemPage);
    /***/
  },

  /***/
  "./src/app/tabs/orderstatus/report-repair-byorder/report-repair-byorder-routing.module.ts":
  /*!************************************************************************************************!*\
    !*** ./src/app/tabs/orderstatus/report-repair-byorder/report-repair-byorder-routing.module.ts ***!
    \************************************************************************************************/

  /*! exports provided: ReportRepairByorderPageRoutingModule */

  /***/
  function srcAppTabsOrderstatusReportRepairByorderReportRepairByorderRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ReportRepairByorderPageRoutingModule", function () {
      return ReportRepairByorderPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _report_repair_byorder_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./report-repair-byorder.page */
    "./src/app/tabs/orderstatus/report-repair-byorder/report-repair-byorder.page.ts");

    var routes = [{
      path: '',
      component: _report_repair_byorder_page__WEBPACK_IMPORTED_MODULE_3__["ReportRepairByorderPage"]
    }];

    var ReportRepairByorderPageRoutingModule = function ReportRepairByorderPageRoutingModule() {
      _classCallCheck(this, ReportRepairByorderPageRoutingModule);
    };

    ReportRepairByorderPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], ReportRepairByorderPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/tabs/orderstatus/report-repair-byorder/report-repair-byorder.module.ts":
  /*!****************************************************************************************!*\
    !*** ./src/app/tabs/orderstatus/report-repair-byorder/report-repair-byorder.module.ts ***!
    \****************************************************************************************/

  /*! exports provided: ReportRepairByorderPageModule */

  /***/
  function srcAppTabsOrderstatusReportRepairByorderReportRepairByorderModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ReportRepairByorderPageModule", function () {
      return ReportRepairByorderPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _report_repair_byorder_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./report-repair-byorder-routing.module */
    "./src/app/tabs/orderstatus/report-repair-byorder/report-repair-byorder-routing.module.ts");
    /* harmony import */


    var _report_repair_byorder_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./report-repair-byorder.page */
    "./src/app/tabs/orderstatus/report-repair-byorder/report-repair-byorder.page.ts");

    var ReportRepairByorderPageModule = function ReportRepairByorderPageModule() {
      _classCallCheck(this, ReportRepairByorderPageModule);
    };

    ReportRepairByorderPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _report_repair_byorder_routing_module__WEBPACK_IMPORTED_MODULE_5__["ReportRepairByorderPageRoutingModule"]],
      declarations: [_report_repair_byorder_page__WEBPACK_IMPORTED_MODULE_6__["ReportRepairByorderPage"]]
    })], ReportRepairByorderPageModule);
    /***/
  },

  /***/
  "./src/app/tabs/orderstatus/report-repair-byorder/report-repair-byorder.page.scss":
  /*!****************************************************************************************!*\
    !*** ./src/app/tabs/orderstatus/report-repair-byorder/report-repair-byorder.page.scss ***!
    \****************************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppTabsOrderstatusReportRepairByorderReportRepairByorderPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".myImg {\n  -webkit-filter: brightness(50%);\n          filter: brightness(50%);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy90aGFuYXNhdGUvaW9uaWMvcWFTYWxlcy1WMy40L3NyYy9hcHAvdGFicy9vcmRlcnN0YXR1cy9yZXBvcnQtcmVwYWlyLWJ5b3JkZXIvcmVwb3J0LXJlcGFpci1ieW9yZGVyLnBhZ2Uuc2NzcyIsInNyYy9hcHAvdGFicy9vcmRlcnN0YXR1cy9yZXBvcnQtcmVwYWlyLWJ5b3JkZXIvcmVwb3J0LXJlcGFpci1ieW9yZGVyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLCtCQUFBO1VBQUEsdUJBQUE7QUNDSiIsImZpbGUiOiJzcmMvYXBwL3RhYnMvb3JkZXJzdGF0dXMvcmVwb3J0LXJlcGFpci1ieW9yZGVyL3JlcG9ydC1yZXBhaXItYnlvcmRlci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubXlJbWcge1xyXG4gICAgZmlsdGVyOiBicmlnaHRuZXNzKDUwJSk7XHJcbiAgfSIsIi5teUltZyB7XG4gIGZpbHRlcjogYnJpZ2h0bmVzcyg1MCUpO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/tabs/orderstatus/report-repair-byorder/report-repair-byorder.page.ts":
  /*!**************************************************************************************!*\
    !*** ./src/app/tabs/orderstatus/report-repair-byorder/report-repair-byorder.page.ts ***!
    \**************************************************************************************/

  /*! exports provided: ReportRepairByorderPage */

  /***/
  function srcAppTabsOrderstatusReportRepairByorderReportRepairByorderPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ReportRepairByorderPage", function () {
      return ReportRepairByorderPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var src_app_services_qasales_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/services/qasales.service */
    "./src/app/services/qasales.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _popup_reportrepair_item_popup_reportrepair_item_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../popup-reportrepair-item/popup-reportrepair-item.page */
    "./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.ts");

    var ReportRepairByorderPage = /*#__PURE__*/function () {
      function ReportRepairByorderPage(router, route, service, loadingCtrl, nav, modal) {
        _classCallCheck(this, ReportRepairByorderPage);

        this.router = router;
        this.route = route;
        this.service = service;
        this.loadingCtrl = loadingCtrl;
        this.nav = nav;
        this.modal = modal;
        this.sum1 = 0;
        this.sum2 = 0;
        this.selectGet = false;
        this.orderNumber = this.route.snapshot.paramMap.get('orderNumber');
      }

      _createClass(ReportRepairByorderPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.loadData();
          this.selectGet = false;
        }
      }, {
        key: "loadData",
        value: function loadData() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee9() {
            var _this3 = this;

            var loading;
            return regeneratorRuntime.wrap(function _callee9$(_context9) {
              while (1) {
                switch (_context9.prev = _context9.next) {
                  case 0:
                    _context9.next = 2;
                    return this.loadingCtrl.create({
                      spinner: 'bubbles',
                      message: 'กำลังโหลดข้อมูล...'
                    });

                  case 2:
                    loading = _context9.sent;
                    _context9.next = 5;
                    return loading.present();

                  case 5:
                    this.sub1 = this.service.reportRepairbyOrder(this.orderNumber).subscribe(function (data) {
                      _this3.reasonReport = data; // console.log(this.reasonReport);
                    }, function (error) {
                      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this3, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
                        return regeneratorRuntime.wrap(function _callee5$(_context5) {
                          while (1) {
                            switch (_context5.prev = _context5.next) {
                              case 0:
                                console.log(error);
                                _context5.next = 3;
                                return loading.dismiss();

                              case 3:
                              case "end":
                                return _context5.stop();
                            }
                          }
                        }, _callee5);
                      }));
                    }, function () {
                      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this3, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee8() {
                        var _this4 = this;

                        return regeneratorRuntime.wrap(function _callee8$(_context8) {
                          while (1) {
                            switch (_context8.prev = _context8.next) {
                              case 0:
                                this.sub2 = this.service.getOrderDetail(this.orderNumber).subscribe(function (data2) {
                                  _this4.orderItems = data2;
                                  _this4.orderItemsGet = data2; // console.log(this.orderItems);
                                }, function (err) {
                                  return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this4, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
                                    return regeneratorRuntime.wrap(function _callee6$(_context6) {
                                      while (1) {
                                        switch (_context6.prev = _context6.next) {
                                          case 0:
                                            console.log(err);

                                          case 1:
                                          case "end":
                                            return _context6.stop();
                                        }
                                      }
                                    }, _callee6);
                                  }));
                                }, function () {
                                  return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this4, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
                                    return regeneratorRuntime.wrap(function _callee7$(_context7) {
                                      while (1) {
                                        switch (_context7.prev = _context7.next) {
                                          case 0:
                                            this.sumValues();
                                            _context7.next = 3;
                                            return loading.dismiss();

                                          case 3:
                                          case "end":
                                            return _context7.stop();
                                        }
                                      }
                                    }, _callee7, this);
                                  }));
                                });

                              case 1:
                              case "end":
                                return _context8.stop();
                            }
                          }
                        }, _callee8, this);
                      }));
                    });

                  case 6:
                  case "end":
                    return _context9.stop();
                }
              }
            }, _callee9, this);
          }));
        }
      }, {
        key: "getSum",
        value: function getSum() {
          this.selectGet = !this.selectGet;
          this.orderItems = this.orderItemsGet;

          if (this.selectGet) {
            this.orderItems = this.orderItems.filter(function (sum) {
              return sum.SumRepair > 0;
            }), this.sumValues();
          } else {
            this.orderItems = this.orderItemsGet;
            this.sumValues();
          }
        }
      }, {
        key: "sumValues",
        value: function sumValues() {
          var _this5 = this;

          this.sum1 = this.sum2 = 0;
          this.orderItems.forEach(function (item) {
            _this5.sum1 = _this5.sum1 + item.TotalQty;
            _this5.sum2 = _this5.sum2 + item.SumRepair;
          });
        }
      }, {
        key: "backToOrderStatus",
        value: function backToOrderStatus() {
          this.nav.navigateBack(['/orderitems']);
        }
      }, {
        key: "openModalReportRepair",
        value: function openModalReportRepair(i) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee10() {
            var modal;
            return regeneratorRuntime.wrap(function _callee10$(_context10) {
              while (1) {
                switch (_context10.prev = _context10.next) {
                  case 0:
                    if (!(i.SumRepair > 0)) {
                      _context10.next = 8;
                      break;
                    }

                    _context10.next = 3;
                    return this.modal.create({
                      component: _popup_reportrepair_item_popup_reportrepair_item_page__WEBPACK_IMPORTED_MODULE_5__["PopupReportrepairItemPage"],
                      componentProps: {
                        product: i
                      }
                    });

                  case 3:
                    modal = _context10.sent;
                    modal.onWillDismiss().then(function (dataReturn) {// console.log(dataReturn);
                    });
                    _context10.next = 7;
                    return modal.present();

                  case 7:
                    return _context10.abrupt("return", _context10.sent);

                  case 8:
                  case "end":
                    return _context10.stop();
                }
              }
            }, _callee10, this);
          }));
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          this.sub1.unsubscribe();
          this.sub2.unsubscribe();
        }
      }]);

      return ReportRepairByorderPage;
    }();

    ReportRepairByorderPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]
      }, {
        type: src_app_services_qasales_service__WEBPACK_IMPORTED_MODULE_2__["QasalesService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"]
      }];
    };

    ReportRepairByorderPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-report-repair-byorder',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./report-repair-byorder.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/orderstatus/report-repair-byorder/report-repair-byorder.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./report-repair-byorder.page.scss */
      "./src/app/tabs/orderstatus/report-repair-byorder/report-repair-byorder.page.scss"))["default"]]
    })], ReportRepairByorderPage);
    /***/
  }
}]);
//# sourceMappingURL=tabs-orderstatus-report-repair-byorder-report-repair-byorder-module-es5.js.map