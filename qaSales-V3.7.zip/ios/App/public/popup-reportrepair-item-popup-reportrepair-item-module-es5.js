function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["popup-reportrepair-item-popup-reportrepair-item-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.html":
  /*!**********************************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.html ***!
    \**********************************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppTabsOrderstatusPopupReportrepairItemPopupReportrepairItemPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-title class=\"fontPromptBold fontSize20\">รายการซ่อม</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n\n\n    <div align=\"center\">\n      <ion-img src=\"{{product.NewPict}}\" style=\"width: 250px;\"></ion-img>\n      <h3 class=\" fontPromptRegular\">{{product.ProductCode}}</h3>\n    </div>\n\n\n    <ion-item color=\"light\" >\n\n\n      <ion-label class=\"fixed50 ion-text-center\">\n        <ion-text class=\"fontPromptRegular fontSize18\">\n         จำนวนงานของ Order :  {{product.TotalQty}}\n        </ion-text>\n      </ion-label>\n\n      <ion-label class=\"fixed50 ion-text-center\">\n        <ion-text class=\"fontPromptRegular fontSize18\">\n         ยอดซ่อมทั้งหมด : {{sum}} \n         <ion-text class=\"fontPromptBold fontSize20\" color=\"warning\">= {{(sum/product.TotalQty)*100 | number:'1.0-1'}}%</ion-text>\n        </ion-text>\n      </ion-label>\n\n \n\n    </ion-item>\n\n    \n      <ion-item color=\"warning\" >\n        <ion-label class=\"fixed15 ion-text-center\">\n          <ion-text class=\"fontPromptRegular fontSize16\">\n            วันที่ส่งซ่อม\n          </ion-text>\n        </ion-label>\n\n        <ion-label class=\"fixed30 ion-text-center\">\n          <ion-text class=\"fontPromptRegular fontSize16\">\n            เลขที่บิล QA\n          </ion-text>\n        </ion-label>\n\n        <ion-label class=\"fixed40 ion-text-center\">\n          <ion-text class=\"fontPromptRegular fontSize16\">\n            อาการที่ซ่อม\n          </ion-text>\n        </ion-label>\n\n        <ion-label class=\"fixed10 ion-text-center\">\n          <ion-text class=\"fontPromptRegular fontSize16\">\n            จำนวน\n          </ion-text>\n        </ion-label>\n      </ion-item>\n\n\n\n\n      <ion-item  *ngFor=\"let i of ReportRepairItem\">\n          <ion-label class=\"fixed15 ion-text-center\">\n            <ion-text class=\"fontPromptRegular fontSize16\">\n              {{i.repairDate | date:\"dd/MM/yy\":\"+0000\" }}<br>\n              <ion-text class=\"colorFontGray\">{{i.repairDate | date: 'HH:mm' : '+0' }} น.</ion-text>\n            </ion-text>\n          </ion-label>\n\n          <ion-label class=\"fixed30 ion-text-center\">\n            <ion-text class=\"fontPromptRegular fontSize16\">\n              {{i.qaDocNumber}}\n            </ion-text>\n          </ion-label>\n  \n          <ion-label class=\"fixed40 ion-text-center\">\n            <ion-text class=\"fontPromptRegular fontSize16\">\n              {{i.repairType}}-{{i.reasonType}}\n            </ion-text>\n          </ion-label>\n  \n          <ion-label class=\"fixed10 ion-text-center\">\n            <ion-text class=\"fontPromptRegular fontSize16\">\n              {{i.Qty}}\n            </ion-text>\n          </ion-label>\n      </ion-item>\n\n\n\n    <div align=\"center\">\n      <br><br><br>\n      <ion-button color=\"danger\" (click)=\"closeModal()\">&nbsp;&nbsp;&nbsp;&nbsp;ปิด&nbsp;&nbsp;&nbsp;&nbsp;</ion-button>\n    </div>\n\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item-routing.module.ts":
  /*!****************************************************************************************************!*\
    !*** ./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item-routing.module.ts ***!
    \****************************************************************************************************/

  /*! exports provided: PopupReportrepairItemPageRoutingModule */

  /***/
  function srcAppTabsOrderstatusPopupReportrepairItemPopupReportrepairItemRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PopupReportrepairItemPageRoutingModule", function () {
      return PopupReportrepairItemPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _popup_reportrepair_item_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./popup-reportrepair-item.page */
    "./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.ts");

    var routes = [{
      path: '',
      component: _popup_reportrepair_item_page__WEBPACK_IMPORTED_MODULE_3__["PopupReportrepairItemPage"]
    }];

    var PopupReportrepairItemPageRoutingModule = function PopupReportrepairItemPageRoutingModule() {
      _classCallCheck(this, PopupReportrepairItemPageRoutingModule);
    };

    PopupReportrepairItemPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], PopupReportrepairItemPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.module.ts":
  /*!********************************************************************************************!*\
    !*** ./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.module.ts ***!
    \********************************************************************************************/

  /*! exports provided: PopupReportrepairItemPageModule */

  /***/
  function srcAppTabsOrderstatusPopupReportrepairItemPopupReportrepairItemModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PopupReportrepairItemPageModule", function () {
      return PopupReportrepairItemPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _popup_reportrepair_item_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./popup-reportrepair-item-routing.module */
    "./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item-routing.module.ts"); // import { PopupReportrepairItemPage } from './popup-reportrepair-item.page';


    var PopupReportrepairItemPageModule = function PopupReportrepairItemPageModule() {
      _classCallCheck(this, PopupReportrepairItemPageModule);
    };

    PopupReportrepairItemPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _popup_reportrepair_item_routing_module__WEBPACK_IMPORTED_MODULE_5__["PopupReportrepairItemPageRoutingModule"]],
      declarations: []
    })], PopupReportrepairItemPageModule);
    /***/
  },

  /***/
  "./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.scss":
  /*!********************************************************************************************!*\
    !*** ./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.scss ***!
    \********************************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppTabsOrderstatusPopupReportrepairItemPopupReportrepairItemPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3RhYnMvb3JkZXJzdGF0dXMvcG9wdXAtcmVwb3J0cmVwYWlyLWl0ZW0vcG9wdXAtcmVwb3J0cmVwYWlyLWl0ZW0ucGFnZS5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.ts":
  /*!******************************************************************************************!*\
    !*** ./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.ts ***!
    \******************************************************************************************/

  /*! exports provided: PopupReportrepairItemPage */

  /***/
  function srcAppTabsOrderstatusPopupReportrepairItemPopupReportrepairItemPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PopupReportrepairItemPage", function () {
      return PopupReportrepairItemPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var src_app_services_qasales_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/services/qasales.service */
    "./src/app/services/qasales.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var PopupReportrepairItemPage = /*#__PURE__*/function () {
      function PopupReportrepairItemPage(service, loadingCtrl, modal) {
        _classCallCheck(this, PopupReportrepairItemPage);

        this.service = service;
        this.loadingCtrl = loadingCtrl;
        this.modal = modal;
      }

      _createClass(PopupReportrepairItemPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          // console.log(this.product);
          this.loadData();
        }
      }, {
        key: "loadData",
        value: function loadData() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var _this = this;

            var loading;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return this.loadingCtrl.create({
                      spinner: 'dots',
                      message: 'กำลังโหลดข้อมูล...'
                    });

                  case 2:
                    loading = _context3.sent;
                    _context3.next = 5;
                    return loading.present();

                  case 5:
                    // start loading
                    this.sub1 = this.service.reportRepairbyItem(this.product.OrderNumber, this.product.ItemNo).subscribe(function (data) {
                      _this.ReportRepairItem = data; // console.log(this.ReportRepairItem);
                    }, function (error) {
                      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                        return regeneratorRuntime.wrap(function _callee$(_context) {
                          while (1) {
                            switch (_context.prev = _context.next) {
                              case 0:
                                console.log(error);
                                _context.next = 3;
                                return loading.dismiss();

                              case 3:
                              case "end":
                                return _context.stop();
                            }
                          }
                        }, _callee);
                      }));
                    }, function () {
                      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
                        var _this2 = this;

                        return regeneratorRuntime.wrap(function _callee2$(_context2) {
                          while (1) {
                            switch (_context2.prev = _context2.next) {
                              case 0:
                                this.sum = 0;
                                this.ReportRepairItem.forEach(function (item) {
                                  _this2.sum = _this2.sum + item.Qty;
                                });
                                _context2.next = 4;
                                return loading.dismiss();

                              case 4:
                              case "end":
                                return _context2.stop();
                            }
                          }
                        }, _callee2, this);
                      }));
                    });

                  case 6:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "closeModal",
        value: function closeModal() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
            return regeneratorRuntime.wrap(function _callee4$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    _context4.next = 2;
                    return this.modal.dismiss();

                  case 2:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee4, this);
          }));
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          this.sub1.unsubscribe();
        }
      }]);

      return PopupReportrepairItemPage;
    }();

    PopupReportrepairItemPage.ctorParameters = function () {
      return [{
        type: src_app_services_qasales_service__WEBPACK_IMPORTED_MODULE_2__["QasalesService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"]
      }];
    };

    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], PopupReportrepairItemPage.prototype, "product", void 0);
    PopupReportrepairItemPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-popup-reportrepair-item',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./popup-reportrepair-item.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./popup-reportrepair-item.page.scss */
      "./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.scss"))["default"]]
    })], PopupReportrepairItemPage);
    /***/
  }
}]);
//# sourceMappingURL=popup-reportrepair-item-popup-reportrepair-item-module-es5.js.map