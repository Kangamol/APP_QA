(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["receive-billfac-receive-billfac-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/receive-billfac/receive-billfac.page.html":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/receive-billfac/receive-billfac.page.html ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar class=\"heigth70\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title class=\"fontPromptBold fontSize26\">QA รับโอนงานจาก Factory</ion-title>\n    \n    <ion-buttons slot=\"end\" >\n      <ion-button (click)=\"onClickRefresh()\">\n        <ion-icon slot=\"icon-only\" name=\"refresh\" size=\"large\"></ion-icon>\n      </ion-button>\n      <ion-button (click)=\"showSearch()\">\n        <ion-icon slot=\"icon-only\" name=\"search\" size=\"large\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n\n  </ion-toolbar>\n\n<!-- Login -->\n<ion-toolbar>\n  <ion-grid>\n    <ion-row [ngClass]=\"{'backgroundPink': user[0].saleManager == '2', 'backgroundBlue': user[0].saleManager == '1,3'}\">\n\n      <ion-col size=\"1\">\n        <ion-avatar>\n          <img src=\"{{user[0].userPicture}}\">\n        </ion-avatar>\n      </ion-col>\n\n      <ion-col size=\"5\" class=\"padingTop\">\n        <ion-text  class=\"fontPromptBold fontSize20  ion-text-left \">&nbsp;Login : {{user[0].fullName}}({{user[0].nickName}})</ion-text>\n      </ion-col>\n\n      <ion-col size=\"5\" class=\"padingTop\">\n        <ion-text  class=\"fontPromptBold fontSize20 ion-text-left \">&nbsp;Team : {{user[0].saleTeam}}</ion-text>\n      </ion-col>\n    </ion-row>\n   </ion-grid>\n\n  </ion-toolbar>\n  \n\n\n  <ion-toolbar *ngIf=\"search\">\n    <ion-searchbar placeholder=\"Find OrderNumber\" debounce=\"500\"  (ionChange)=\"getBill($event)\"></ion-searchbar>\n  </ion-toolbar>\n\n  <ion-grid>\n  <ion-item color=\"danger\">\n    <ion-thumbnail slot=\"start\">\n      \n    </ion-thumbnail>\n\n    <ion-label  fixed class=\"fixed45\">    \n        <ion-text>\n          <h1 class=\"fontPromptRegular\">Description</h1>\n        </ion-text>\n     \n    </ion-label>\n\n    <ion-label class=\"alignright\">\n      <h1 class=\"fontPromptRegular\"> จำนวนที่ฝ่ายผลิตโอนมา</h1>\n    </ion-label>\n  </ion-item>\n</ion-grid>\n</ion-header>\n\n<ion-content>\n\n  <ion-item *ngFor=\"let i of qaBillReceive\" (click)=\"gotoQaReceive(i)\">\n    <ion-thumbnail slot=\"start\">\n      <img src=\"{{i.showIcon}}\">\n    </ion-thumbnail>\n\n    <ion-label fixed class=\"fixed45\">\n      <h2 class=\"fontPromptBold\">{{i.OrderNumber}}</h2>\n      <h3 class=\"fontPromptRegular colorFontGray\">Bill : {{i.qaDocNumber}}<br>\n                                                  กำหนดส่ง : ({{i.thaiDateDue}}){{i.DueDate | date:'dd/MM/yyyy':\"+0000\" }}<br>\n                                                  วันที่/เวลาที่ส่ง : ({{i.thaiDateBill}}){{i.billDate | date:'dd/MM/yy':\"+0000\"}} ({{i.billDate | date: 'HH:mm' : '+0'}}น.)\n                                                  <!-- Factory: {{i.ProductionTeam}} -->\n      </h3>\n    </ion-label>\n\n    <ion-label class=\"alignright\">\n      <h1 class=\"fontPromptBold\"> ยอดโอน : {{ i.TotalQty | number }}</h1>\n      <!-- <h3 class=\"fontPromptRegular colorFontGray\"> จำนวนทั้งหมดของOrder : {{ i.OrderQty | number }}</h3> -->\n      <!-- <h3 class=\"fontPromptRegular colorFontGray\">ยอดที่ยังไม่เสร็จ : {{i.OrderQty - i.TotalQaFinish | number}}<br>\n                                                  จำนวนทั้งหมดของOrder : {{ i.OrderQty | number }}</h3> -->\n    </ion-label>\n\n  </ion-item>\n\n</ion-content>\n");

/***/ }),

/***/ "./src/app/tabs/receive-billfac/receive-billfac-routing.module.ts":
/*!************************************************************************!*\
  !*** ./src/app/tabs/receive-billfac/receive-billfac-routing.module.ts ***!
  \************************************************************************/
/*! exports provided: ReceiveBillfacPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReceiveBillfacPageRoutingModule", function() { return ReceiveBillfacPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _receive_billfac_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./receive-billfac.page */ "./src/app/tabs/receive-billfac/receive-billfac.page.ts");




const routes = [
    {
        path: '',
        component: _receive_billfac_page__WEBPACK_IMPORTED_MODULE_3__["ReceiveBillfacPage"]
    },
    {
        path: 'receive-detail',
        loadChildren: () => __webpack_require__.e(/*! import() | receive-detail-receive-detail-module */ "default~receive-detail-receive-detail-module~tabs-receive-billfac-receive-detail-receive-detail-module").then(__webpack_require__.bind(null, /*! ./receive-detail/receive-detail.module */ "./src/app/tabs/receive-billfac/receive-detail/receive-detail.module.ts")).then(m => m.ReceiveDetailPageModule)
    }
];
let ReceiveBillfacPageRoutingModule = class ReceiveBillfacPageRoutingModule {
};
ReceiveBillfacPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ReceiveBillfacPageRoutingModule);



/***/ }),

/***/ "./src/app/tabs/receive-billfac/receive-billfac.module.ts":
/*!****************************************************************!*\
  !*** ./src/app/tabs/receive-billfac/receive-billfac.module.ts ***!
  \****************************************************************/
/*! exports provided: ReceiveBillfacPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReceiveBillfacPageModule", function() { return ReceiveBillfacPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _receive_billfac_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./receive-billfac-routing.module */ "./src/app/tabs/receive-billfac/receive-billfac-routing.module.ts");
/* harmony import */ var _receive_billfac_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./receive-billfac.page */ "./src/app/tabs/receive-billfac/receive-billfac.page.ts");







let ReceiveBillfacPageModule = class ReceiveBillfacPageModule {
};
ReceiveBillfacPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _receive_billfac_routing_module__WEBPACK_IMPORTED_MODULE_5__["ReceiveBillfacPageRoutingModule"]
        ],
        declarations: [_receive_billfac_page__WEBPACK_IMPORTED_MODULE_6__["ReceiveBillfacPage"]]
    })
], ReceiveBillfacPageModule);



/***/ }),

/***/ "./src/app/tabs/receive-billfac/receive-billfac.page.scss":
/*!****************************************************************!*\
  !*** ./src/app/tabs/receive-billfac/receive-billfac.page.scss ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3RhYnMvcmVjZWl2ZS1iaWxsZmFjL3JlY2VpdmUtYmlsbGZhYy5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/tabs/receive-billfac/receive-billfac.page.ts":
/*!**************************************************************!*\
  !*** ./src/app/tabs/receive-billfac/receive-billfac.page.ts ***!
  \**************************************************************/
/*! exports provided: ReceiveBillfacPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReceiveBillfacPage", function() { return ReceiveBillfacPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _services_qasales_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../services/qasales.service */ "./src/app/services/qasales.service.ts");
/* harmony import */ var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/auth/auth.service */ "./src/app/auth/auth.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");







let ReceiveBillfacPage = class ReceiveBillfacPage {
    constructor(nav, service, loadingCtrl, authService, route) {
        this.nav = nav;
        this.service = service;
        this.loadingCtrl = loadingCtrl;
        this.authService = authService;
        this.route = route;
        this.person = false;
        this.search = false;
    }
    ngOnInit() {
        this.user = this.authService.getUserInfo();
    }
    ionViewWillEnter() {
        this.search = false;
        this.user = this.authService.getUserInfo();
        if (!this.user) {
            this.route.navigateByUrl('/auth');
        }
        else {
            // console.log('Deaprtment = ', this.user[0].userDepartment);
            this.loadBillShow();
        }
    }
    loadBillShow() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingCtrl.create({
                spinner: 'bubbles',
                message: 'กำลังโหลด'
            });
            yield loading.present();
            this.sub = this.service.qaBillReceive(this.user[0].saleManager).subscribe((data) => {
                this.qaBillReceive = data;
                this.qaBillReceiveGet = data;
                // console.log(this.qaBillReceive);
                // console.log(this.saleManager);
            }, (error) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                console.log(error);
                yield loading.dismiss();
            }), () => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                yield loading.dismiss();
            }));
        });
    }
    gotoQaReceive(i) {
        this.nav.navigateRoot(['/receive-detail', {
                bill_Id: i.qaBill_ID,
                OrderNumber: i.OrderNumber,
                fact: i.ProductionTeam,
                showIcon: i.showIcon,
                saleTeam: i.avatar,
                userSent: i.userSent,
                nickNameSent: i.nickNameSent,
                thaiDateBill: i.thaiDateBill
            }]);
    }
    getBill(ev) {
        const val = ev.target.value;
        this.qaBillReceive = this.qaBillReceiveGet;
        if (val && val.trim() !== '') {
            this.qaBillReceive = this.qaBillReceive.filter((bill) => {
                return (bill.OrderNumber.toLowerCase().indexOf(val.toLowerCase()) > -1);
            });
        }
        else {
            //  this.loadBillShow();
            this.qaBillReceive = this.qaBillReceiveGet;
        }
    }
    showPerson() {
        this.person = !this.person;
    }
    showSearch() {
        this.search = !this.search;
    }
    onClickRefresh() {
        this.loadBillShow();
    }
    ngOnDestroy() {
        this.sub.unsubscribe();
    }
};
ReceiveBillfacPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _services_qasales_service__WEBPACK_IMPORTED_MODULE_3__["QasalesService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] },
    { type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] }
];
ReceiveBillfacPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-receive-billfac',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./receive-billfac.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/receive-billfac/receive-billfac.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./receive-billfac.page.scss */ "./src/app/tabs/receive-billfac/receive-billfac.page.scss")).default]
    })
], ReceiveBillfacPage);



/***/ })

}]);
//# sourceMappingURL=receive-billfac-receive-billfac-module-es2015.js.map