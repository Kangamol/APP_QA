function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["common"], {
  /***/
  "./node_modules/@ionic/core/dist/esm/button-active-4b76b5c3.js":
  /*!*********************************************************************!*\
    !*** ./node_modules/@ionic/core/dist/esm/button-active-4b76b5c3.js ***!
    \*********************************************************************/

  /*! exports provided: c */

  /***/
  function node_modulesIonicCoreDistEsmButtonActive4b76b5c3Js(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "c", function () {
      return createButtonActiveGesture;
    });
    /* harmony import */


    var _index_29df6f59_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! ./index-29df6f59.js */
    "./node_modules/@ionic/core/dist/esm/index-29df6f59.js");
    /* harmony import */


    var _index_eea61379_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./index-eea61379.js */
    "./node_modules/@ionic/core/dist/esm/index-eea61379.js");
    /* harmony import */


    var _haptic_7b8ba70a_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./haptic-7b8ba70a.js */
    "./node_modules/@ionic/core/dist/esm/haptic-7b8ba70a.js");

    var createButtonActiveGesture = function createButtonActiveGesture(el, isButton) {
      var currentTouchedButton;
      var initialTouchedButton;

      var activateButtonAtPoint = function activateButtonAtPoint(x, y, hapticFeedbackFn) {
        if (typeof document === 'undefined') {
          return;
        }

        var target = document.elementFromPoint(x, y);

        if (!target || !isButton(target)) {
          clearActiveButton();
          return;
        }

        if (target !== currentTouchedButton) {
          clearActiveButton();
          setActiveButton(target, hapticFeedbackFn);
        }
      };

      var setActiveButton = function setActiveButton(button, hapticFeedbackFn) {
        currentTouchedButton = button;

        if (!initialTouchedButton) {
          initialTouchedButton = currentTouchedButton;
        }

        var buttonToModify = currentTouchedButton;
        Object(_index_29df6f59_js__WEBPACK_IMPORTED_MODULE_0__["w"])(function () {
          return buttonToModify.classList.add('ion-activated');
        });
        hapticFeedbackFn();
      };

      var clearActiveButton = function clearActiveButton() {
        var dispatchClick = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;

        if (!currentTouchedButton) {
          return;
        }

        var buttonToModify = currentTouchedButton;
        Object(_index_29df6f59_js__WEBPACK_IMPORTED_MODULE_0__["w"])(function () {
          return buttonToModify.classList.remove('ion-activated');
        });
        /**
         * Clicking on one button, but releasing on another button
         * does not dispatch a click event in browsers, so we
         * need to do it manually here. Some browsers will
         * dispatch a click if clicking on one button, dragging over
         * another button, and releasing on the original button. In that
         * case, we need to make sure we do not cause a double click there.
         */

        if (dispatchClick && initialTouchedButton !== currentTouchedButton) {
          currentTouchedButton.click();
        }

        currentTouchedButton = undefined;
      };

      return Object(_index_eea61379_js__WEBPACK_IMPORTED_MODULE_1__["createGesture"])({
        el: el,
        gestureName: 'buttonActiveDrag',
        threshold: 0,
        onStart: function onStart(ev) {
          return activateButtonAtPoint(ev.currentX, ev.currentY, _haptic_7b8ba70a_js__WEBPACK_IMPORTED_MODULE_2__["a"]);
        },
        onMove: function onMove(ev) {
          return activateButtonAtPoint(ev.currentX, ev.currentY, _haptic_7b8ba70a_js__WEBPACK_IMPORTED_MODULE_2__["b"]);
        },
        onEnd: function onEnd() {
          clearActiveButton(true);
          Object(_haptic_7b8ba70a_js__WEBPACK_IMPORTED_MODULE_2__["h"])();
          initialTouchedButton = undefined;
        }
      });
    };
    /***/

  },

  /***/
  "./node_modules/@ionic/core/dist/esm/framework-delegate-d1eb6504.js":
  /*!**************************************************************************!*\
    !*** ./node_modules/@ionic/core/dist/esm/framework-delegate-d1eb6504.js ***!
    \**************************************************************************/

  /*! exports provided: a, d */

  /***/
  function node_modulesIonicCoreDistEsmFrameworkDelegateD1eb6504Js(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "a", function () {
      return attachComponent;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "d", function () {
      return detachComponent;
    });

    var attachComponent = /*#__PURE__*/function () {
      var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(delegate, container, component, cssClasses, componentProps) {
        var el;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                if (!delegate) {
                  _context.next = 2;
                  break;
                }

                return _context.abrupt("return", delegate.attachViewToDom(container, component, componentProps, cssClasses));

              case 2:
                if (!(typeof component !== 'string' && !(component instanceof HTMLElement))) {
                  _context.next = 4;
                  break;
                }

                throw new Error('framework delegate is missing');

              case 4:
                el = typeof component === 'string' ? container.ownerDocument && container.ownerDocument.createElement(component) : component;

                if (cssClasses) {
                  cssClasses.forEach(function (c) {
                    return el.classList.add(c);
                  });
                }

                if (componentProps) {
                  Object.assign(el, componentProps);
                }

                container.appendChild(el);

                if (!el.componentOnReady) {
                  _context.next = 11;
                  break;
                }

                _context.next = 11;
                return el.componentOnReady();

              case 11:
                return _context.abrupt("return", el);

              case 12:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }));

      return function attachComponent(_x, _x2, _x3, _x4, _x5) {
        return _ref.apply(this, arguments);
      };
    }();

    var detachComponent = function detachComponent(delegate, element) {
      if (element) {
        if (delegate) {
          var container = element.parentElement;
          return delegate.removeViewFromDom(container, element);
        }

        element.remove();
      }

      return Promise.resolve();
    };
    /***/

  },

  /***/
  "./node_modules/@ionic/core/dist/esm/haptic-7b8ba70a.js":
  /*!**************************************************************!*\
    !*** ./node_modules/@ionic/core/dist/esm/haptic-7b8ba70a.js ***!
    \**************************************************************/

  /*! exports provided: a, b, c, d, h */

  /***/
  function node_modulesIonicCoreDistEsmHaptic7b8ba70aJs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "a", function () {
      return hapticSelectionStart;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "b", function () {
      return hapticSelectionChanged;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "c", function () {
      return hapticSelection;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "d", function () {
      return hapticImpact;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "h", function () {
      return hapticSelectionEnd;
    });

    var HapticEngine = {
      getEngine: function getEngine() {
        var win = window;
        return win.TapticEngine || win.Capacitor && win.Capacitor.isPluginAvailable('Haptics') && win.Capacitor.Plugins.Haptics;
      },
      available: function available() {
        return !!this.getEngine();
      },
      isCordova: function isCordova() {
        return !!window.TapticEngine;
      },
      isCapacitor: function isCapacitor() {
        var win = window;
        return !!win.Capacitor;
      },
      impact: function impact(options) {
        var engine = this.getEngine();

        if (!engine) {
          return;
        }

        var style = this.isCapacitor() ? options.style.toUpperCase() : options.style;
        engine.impact({
          style: style
        });
      },
      notification: function notification(options) {
        var engine = this.getEngine();

        if (!engine) {
          return;
        }

        var style = this.isCapacitor() ? options.style.toUpperCase() : options.style;
        engine.notification({
          style: style
        });
      },
      selection: function selection() {
        this.impact({
          style: 'light'
        });
      },
      selectionStart: function selectionStart() {
        var engine = this.getEngine();

        if (!engine) {
          return;
        }

        if (this.isCapacitor()) {
          engine.selectionStart();
        } else {
          engine.gestureSelectionStart();
        }
      },
      selectionChanged: function selectionChanged() {
        var engine = this.getEngine();

        if (!engine) {
          return;
        }

        if (this.isCapacitor()) {
          engine.selectionChanged();
        } else {
          engine.gestureSelectionChanged();
        }
      },
      selectionEnd: function selectionEnd() {
        var engine = this.getEngine();

        if (!engine) {
          return;
        }

        if (this.isCapacitor()) {
          engine.selectionEnd();
        } else {
          engine.gestureSelectionEnd();
        }
      }
    };
    /**
     * Trigger a selection changed haptic event. Good for one-time events
     * (not for gestures)
     */

    var hapticSelection = function hapticSelection() {
      HapticEngine.selection();
    };
    /**
     * Tell the haptic engine that a gesture for a selection change is starting.
     */


    var hapticSelectionStart = function hapticSelectionStart() {
      HapticEngine.selectionStart();
    };
    /**
     * Tell the haptic engine that a selection changed during a gesture.
     */


    var hapticSelectionChanged = function hapticSelectionChanged() {
      HapticEngine.selectionChanged();
    };
    /**
     * Tell the haptic engine we are done with a gesture. This needs to be
     * called lest resources are not properly recycled.
     */


    var hapticSelectionEnd = function hapticSelectionEnd() {
      HapticEngine.selectionEnd();
    };
    /**
     * Use this to indicate success/failure/warning to the user.
     * options should be of the type `{ style: 'light' }` (or `medium`/`heavy`)
     */


    var hapticImpact = function hapticImpact(options) {
      HapticEngine.impact(options);
    };
    /***/

  },

  /***/
  "./node_modules/@ionic/core/dist/esm/spinner-configs-c78e170e.js":
  /*!***********************************************************************!*\
    !*** ./node_modules/@ionic/core/dist/esm/spinner-configs-c78e170e.js ***!
    \***********************************************************************/

  /*! exports provided: S */

  /***/
  function node_modulesIonicCoreDistEsmSpinnerConfigsC78e170eJs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "S", function () {
      return SPINNERS;
    });

    var spinners = {
      'bubbles': {
        dur: 1000,
        circles: 9,
        fn: function fn(dur, index, total) {
          var animationDelay = "".concat(dur * index / total - dur, "ms");
          var angle = 2 * Math.PI * index / total;
          return {
            r: 5,
            style: {
              'top': "".concat(9 * Math.sin(angle), "px"),
              'left': "".concat(9 * Math.cos(angle), "px"),
              'animation-delay': animationDelay
            }
          };
        }
      },
      'circles': {
        dur: 1000,
        circles: 8,
        fn: function fn(dur, index, total) {
          var step = index / total;
          var animationDelay = "".concat(dur * step - dur, "ms");
          var angle = 2 * Math.PI * step;
          return {
            r: 5,
            style: {
              'top': "".concat(9 * Math.sin(angle), "px"),
              'left': "".concat(9 * Math.cos(angle), "px"),
              'animation-delay': animationDelay
            }
          };
        }
      },
      'circular': {
        dur: 1400,
        elmDuration: true,
        circles: 1,
        fn: function fn() {
          return {
            r: 20,
            cx: 48,
            cy: 48,
            fill: 'none',
            viewBox: '24 24 48 48',
            transform: 'translate(0,0)',
            style: {}
          };
        }
      },
      'crescent': {
        dur: 750,
        circles: 1,
        fn: function fn() {
          return {
            r: 26,
            style: {}
          };
        }
      },
      'dots': {
        dur: 750,
        circles: 3,
        fn: function fn(_, index) {
          var animationDelay = -(110 * index) + 'ms';
          return {
            r: 6,
            style: {
              'left': "".concat(9 - 9 * index, "px"),
              'animation-delay': animationDelay
            }
          };
        }
      },
      'lines': {
        dur: 1000,
        lines: 12,
        fn: function fn(dur, index, total) {
          var transform = "rotate(".concat(30 * index + (index < 6 ? 180 : -180), "deg)");
          var animationDelay = "".concat(dur * index / total - dur, "ms");
          return {
            y1: 17,
            y2: 29,
            style: {
              'transform': transform,
              'animation-delay': animationDelay
            }
          };
        }
      },
      'lines-small': {
        dur: 1000,
        lines: 12,
        fn: function fn(dur, index, total) {
          var transform = "rotate(".concat(30 * index + (index < 6 ? 180 : -180), "deg)");
          var animationDelay = "".concat(dur * index / total - dur, "ms");
          return {
            y1: 12,
            y2: 20,
            style: {
              'transform': transform,
              'animation-delay': animationDelay
            }
          };
        }
      }
    };
    var SPINNERS = spinners;
    /***/
  },

  /***/
  "./node_modules/@ionic/core/dist/esm/theme-3f0b0c04.js":
  /*!*************************************************************!*\
    !*** ./node_modules/@ionic/core/dist/esm/theme-3f0b0c04.js ***!
    \*************************************************************/

  /*! exports provided: c, g, h, o */

  /***/
  function node_modulesIonicCoreDistEsmTheme3f0b0c04Js(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "c", function () {
      return createColorClasses;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "g", function () {
      return getClassMap;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "h", function () {
      return hostContext;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "o", function () {
      return openURL;
    });

    var hostContext = function hostContext(selector, el) {
      return el.closest(selector) !== null;
    };
    /**
     * Create the mode and color classes for the component based on the classes passed in
     */


    var createColorClasses = function createColorClasses(color) {
      return typeof color === 'string' && color.length > 0 ? _defineProperty({
        'ion-color': true
      }, "ion-color-".concat(color), true) : undefined;
    };

    var getClassList = function getClassList(classes) {
      if (classes !== undefined) {
        var array = Array.isArray(classes) ? classes : classes.split(' ');
        return array.filter(function (c) {
          return c != null;
        }).map(function (c) {
          return c.trim();
        }).filter(function (c) {
          return c !== '';
        });
      }

      return [];
    };

    var getClassMap = function getClassMap(classes) {
      var map = {};
      getClassList(classes).forEach(function (c) {
        return map[c] = true;
      });
      return map;
    };

    var SCHEME = /^[a-z][a-z0-9+\-.]*:/;

    var openURL = /*#__PURE__*/function () {
      var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(url, ev, direction, animation) {
        var router;
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                if (!(url != null && url[0] !== '#' && !SCHEME.test(url))) {
                  _context2.next = 5;
                  break;
                }

                router = document.querySelector('ion-router');

                if (!router) {
                  _context2.next = 5;
                  break;
                }

                if (ev != null) {
                  ev.preventDefault();
                }

                return _context2.abrupt("return", router.push(url, direction, animation));

              case 5:
                return _context2.abrupt("return", false);

              case 6:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }));

      return function openURL(_x6, _x7, _x8, _x9) {
        return _ref3.apply(this, arguments);
      };
    }();
    /***/

  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/qastatus/qa-finish-master/qa-finish-master.page.html":
  /*!*****************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/qastatus/qa-finish-master/qa-finish-master.page.html ***!
    \*****************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppTabsQastatusQaFinishMasterQaFinishMasterPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar class=\"heigth50\">\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"backToQaStatus()\">\n        <ion-icon name=\"arrow-back\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-title class=\"fontPromptBold fontSize26\">ประวัติการตรวจงานเสร็จ</ion-title>\n\n    <ion-buttons slot=\"end\" >\n      <ion-button (click)=\"onClickRefresh()\">\n        <ion-icon slot=\"icon-only\" name=\"refresh\" size=\"large\"></ion-icon>\n      </ion-button>\n      <ion-button (click)=\"showSearch()\">\n        <ion-icon slot=\"icon-only\" name=\"search\" size=\"large\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n\n\n\n  <!-- Login -->\n  <ion-toolbar>\n    <ion-grid>\n      <ion-row [ngClass]=\"{'backgroundPink': user[0].saleManager == '2', 'backgroundBlue': user[0].saleManager == '1,3'}\">\n  \n        <ion-col size=\"1\">\n          <ion-avatar>\n            <img src=\"{{user[0].userPicture}}\">\n          </ion-avatar>\n        </ion-col>\n  \n        <ion-col size=\"5\" class=\"padingTop\">\n          <ion-text  class=\"fontPromptBold fontSize20  ion-text-left \">&nbsp;Login : {{user[0].fullName}}({{user[0].nickName}})</ion-text>\n        </ion-col>\n  \n        <ion-col size=\"5\" class=\"padingTop\">\n          <ion-text  class=\"fontPromptBold fontSize20 ion-text-left \">&nbsp;Team : {{user[0].saleTeam}}</ion-text>\n        </ion-col>\n      </ion-row>\n     </ion-grid> \n  \n    </ion-toolbar>\n\n  <ion-grid>\n\n    <ion-toolbar *ngIf=\"search\">\n      <ion-searchbar placeholder=\"Find OrderNumber\" debounce=\"500\"  (ionChange)=\"getBill($event)\"></ion-searchbar>\n    </ion-toolbar>\n\n    <ion-item color=\"primary\">\n\n\n      <ion-label  fixed class=\"fixed20 align\" >    \n        <ion-text>\n          <h2 class=\"fontPromptRegular align\">วันที่ตรวจงานเสร็จ</h2>\n        </ion-text>\n    </ion-label>\n  \n      <ion-label  fixed class=\"fixed35 align\">    \n          <ion-text>\n            <h1 class=\"fontPromptRegular\">Description</h1>\n          </ion-text>\n       \n      </ion-label>\n  \n      <ion-label class=\"fixed20 align\">\n        <h2 class=\"fontPromptRegular\">จำนวนที่ตรวจเสร็จ</h2>\n      </ion-label>\n\n      <ion-label class=\"fixed20 align\">\n        <h2 class=\"fontPromptRegular\">ผู้ส่งงานตรวจเสร็จ</h2>\n      </ion-label>\n  \n    </ion-item>\n  \n  </ion-grid>\n\n        <!-- Summary -->\n        <ion-row>\n          <ion-col>\n  \n            <ion-item color=\"light\">\n              <!-- <ion-col size=\"1\"></ion-col> -->\n              <ion-col size=\"7\" class=\"ion-text-right\">\n                <ion-label><div class=\"fontPromptBold fontSize24\">ยอดรวม : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div></ion-label>\n              </ion-col>\n    \n              <ion-col size=\"2\" class=\"ion-text-center\" >\n                <ion-label color=\"primary\">\n                  <ion-text class=\"fontPromptBold fontSize24\">\n                    {{ sum1 | number }}\n                  </ion-text>\n                </ion-label>\n              </ion-col>\n    \n  \n            </ion-item>\n          </ion-col>\n        </ion-row>\n  \n\n</ion-header>\n\n<ion-content>\n\n  <ion-item *ngFor=\"let i of qaFinishMaster\" (click)=\"goToqaFinishDetail(i)\" detail>\n\n    <ion-label  fixed class=\"fixed20 align\">    \n      <ion-text>\n        <h2 class=\"fontPromptRegular align\">({{i.thaiDate}})&nbsp;{{i.receiveDate | date:'dd/MM/yyyy':\"+0000\"}}</h2>\n        <h3 class=\"fontPromptRegular align colorFontGray\">เวลา : {{i.receiveDate | date: 'HH:mm' : '+0'}}</h3>\n      </ion-text>\n  </ion-label>\n\n    <ion-label  fixed class=\"fixed35 align\">    \n        <ion-text>\n          <h2 class=\"fontPromptBold\">{{i.OrderNumber}}</h2>\n          <p class=\"fontPromptRegular colorFontGray\">เลขที่บิล : {{i.qaDocNumber}}</p>\n        </ion-text>\n     \n    </ion-label>\n\n    <ion-label class=\"fixed20 align\" color=\"primary\">\n      <h1 class=\"fontPromptRegular\">{{i.TotalQaFinish}}</h1>\n    </ion-label>\n\n    <ion-label class=\"fixed20 align\">\n      <h2 class=\"fontPromptRegular\">{{i.fullName}}({{i.nickName}})</h2>\n    </ion-label>\n\n  </ion-item>\n\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/services/qasales.service.ts":
  /*!*********************************************!*\
    !*** ./src/app/services/qasales.service.ts ***!
    \*********************************************/

  /*! exports provided: QasalesService */

  /***/
  function srcAppServicesQasalesServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "QasalesService", function () {
      return QasalesService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");

    var QasalesService = /*#__PURE__*/function () {
      function QasalesService(http) {
        _classCallCheck(this, QasalesService);

        this.http = http;
        this.mainApi = 'http://172.16.0.19:3000/';
      } // แสดงข้อมูลสถานะของแต่ละ Order Tab4


      _createClass(QasalesService, [{
        key: "getOrderStatus",
        value: function getOrderStatus(saleID) {
          return this.http.get("".concat(this.mainApi, "orderStatusSales/").concat(saleID));
        } // แสดงข้อมูลสถานะของแต่ละ Item ของ Order Tab4

      }, {
        key: "getOrderDetail",
        value: function getOrderDetail(orderNumber) {
          return this.http.get("".concat(this.mainApi, "OrderDetailSale?orderNumber=").concat(orderNumber));
        } // ดึงข้อมูล Report งานซ่อม แบบ Order

      }, {
        key: "reportRepairbyOrder",
        value: function reportRepairbyOrder(orderNumber) {
          return this.http.get("".concat(this.mainApi, "reportRepairbyorder?orderNumber=").concat(orderNumber));
        } // ดึงข้อมูล Report งานซ่อม แบบItem Popup

      }, {
        key: "reportRepairbyItem",
        value: function reportRepairbyItem(orderNumber, OrderItem) {
          return this.http.get("".concat(this.mainApi, "reportRepairbyitem/").concat(OrderItem, "?orderNumber=").concat(orderNumber));
        } // (TAB1 หน้าดึงรูป เปลี่ยนรูป TAB 1)

      }, {
        key: "appUser",
        value: function appUser(userid) {
          return this.http.get("".concat(this.mainApi, "getuser/").concat(userid));
        } // (สถานะงานในกแผนก QA TAB 2 )

      }, {
        key: "qaStatus",
        value: function qaStatus(manager) {
          return this.http.get("".concat(this.mainApi, "qaStatus/").concat(manager));
        } // (สถานะงานในกแผนก QA กดเข้าไปดูเป็นรายการเพื่อนำไปQA เสร็จหรือส่งซ่อม TAB 2 )

      }, {
        key: "qaStatusDetail",
        value: function qaStatusDetail(billID) {
          return this.http.get(this.mainApi + 'qaStatusItems/' + billID);
        } // (รับงานจา่กFac เข้า แผนก QA TAB 3)

      }, {
        key: "qaBillReceive",
        value: function qaBillReceive(saleManger) {
          return this.http.get("".concat(this.mainApi, "qabillreceive/").concat(saleManger));
        } // (กดรับงานจากFac เข้าแผนก QA Detail TAB 3)

      }, {
        key: "qaItemsReceive",
        value: function qaItemsReceive(billID) {
          return this.http.get("".concat(this.mainApi, "qaBillReceiveitems/").concat(billID));
        } // (ดูสถานะการซ่อม และ หน้าแรกของกดรับงานซ่อม TAB4)

      }, {
        key: "statusRepairMaster",
        value: function statusRepairMaster(sales) {
          return this.http.get("".concat(this.mainApi, "qaStatusRepair/").concat(sales));
        } // (รับงานซ่อมที่กลับมาจากผลิต TAB4 Detail)

      }, {
        key: "repairReceiveItems",
        value: function repairReceiveItems(repairID) {
          return this.http.get("".concat(this.mainApi, "repairbillreceivefacitems/").concat(repairID));
        } // แสดงสถานะของOrder TAB5
        // statusOrder(fact: string): Observable<StatusOrder[]> {
        //   return this.http.get<StatusOrder[]>(`${this.mainApi}wipfact/${fact}`);
        // }
        // ยืนยันรับงานที่ส่งลงมาจากฝ่ายผลิต TAB 2(เปลี่ยนสถานะ)

      }, {
        key: "confirmBillreceive",
        value: function confirmBillreceive(billID, status) {
          return this.http.put("".concat(this.mainApi, "updateQaBillStatus/").concat(billID, "/").concat(status), {});
        } // ยืนยันรับงานที่ส่งลงมาจากฝ่ายผลิต TAB 2(แสดงชื่อ และ วันที่รับ)

      }, {
        key: "confirmBillreceiveShowUser",
        value: function confirmBillreceiveShowUser(billID, receiver) {
          return this.http.put("".concat(this.mainApi, "updateQaBillReceiver/").concat(billID, "/").concat(receiver), {});
        } // ยืนยันรับงานซ่อม ใส่ข้อมูลไปที่ ToQA Tab3 รับงานซ่อม

      }, {
        key: "updateQaRepairBillFinishQty",
        value: function updateQaRepairBillFinishQty(repairID, repairItem, ToQa) {
          return this.http.put("".concat(this.mainApi, "updateQaRepairBillFinishQty/").concat(repairID, "/").concat(repairItem, "/").concat(ToQa), {});
        } // ยืนยันส่งงานไปซ่อม เช็คข้อมูลว่า RepairFinish เท่ากับ QTY หรือยัง Tab3 รับงานซ่อม

      }, {
        key: "checkRepairBillFinish",
        value: function checkRepairBillFinish(repairID) {
          return this.http.get("".concat(this.mainApi, "checkRepairBillFinish/").concat(repairID));
        } // อัพเดท Status ของรับงานซ่อม เมื่อ RepairFinish เท่ากับ QTY เมื่องานครบ Tab3 รับงานซ่อม

      }, {
        key: "updateQaRepairBill",
        value: function updateQaRepairBill(repairID) {
          return this.http.put("".concat(this.mainApi, "updateQaRepairBill/").concat(repairID), {});
        }
      }, {
        key: "insertRepairBillMaster",
        value: function insertRepairBillMaster(i) {
          var body = {
            repairDocNumber: i.repairDocNumber,
            qaBill_ID: i.qaBill_ID,
            userID: i.userID,
            OrderNumber: i.OrderNumber,
            receiver: i.receiver
          }; // console.log('api -> ', body);

          return this.http.post(this.mainApi + 'insertRepairBillMaster', body);
        }
      }, {
        key: "insertRepairBillDetail",
        value: function insertRepairBillDetail(i) {
          // insertRepairBillDetail(i: any) {
          var body = {
            qaRepair_ID: Number(i.qaRepair_ID),
            repair_Item: Number(i.repair_Item),
            bill_Item: Number(i.bill_Item),
            repairTypeID: Number(i.repairTypeID),
            Qty: Number(i.Qty)
          }; // console.log('i service = ', i);
          // console.log('body service = ', body);
          // return true;

          return this.http.post(this.mainApi + 'insertRepairBillDetail', body);
        } // แสดงข้อมูลอาการเสีย Input 1 PopupRepair

      }, {
        key: "repairTypeMaster",
        value: function repairTypeMaster() {
          return this.http.get("".concat(this.mainApi, "repairTypeMaster"));
        } // แสดงข้อมูลอาการเสีย โดยส่ง Value Input 1 มา Input 2 PopupRepair

      }, {
        key: "repairTypeDetail",
        value: function repairTypeDetail(typeID) {
          return this.http.get("".concat(this.mainApi, "repairTypeDetail/").concat(typeID));
        } // แสดงข้อมูลอาการเสีย โดยส่งไม่ได้ส่งค่าอะไรมา

      }, {
        key: "repairTypeDetail2",
        value: function repairTypeDetail2() {
          return this.http.get("".concat(this.mainApi, "repairTypeDetail*"));
        } // ยืนยันงานตรวจเสร็จ Master Tab1 qaStatus

      }, {
        key: "insertFinishMaster",
        value: function insertFinishMaster(i) {
          var body = {
            finishDocNumber: i.finishDocNumber,
            qaBill_ID: i.qaBill_ID,
            userID: i.userID,
            OrderNumber: i.OrderNumber,
            receiver: i.receiver
          }; // console.log('api -> ', body);

          return this.http.post(this.mainApi + 'insertFinishMaster', body);
        } // ยืนยันงานตรวจเสร็จ Detail Tab1 qaStatus

      }, {
        key: "insertFinishDetail",
        value: function insertFinishDetail(i) {
          var body = {
            qaFinish_ID: Number(i.qaFinish_ID),
            finish_Item: Number(i.finish_Item),
            bill_Item: Number(i.bill_Item),
            Qty: Number(i.Qty)
          }; // console.log('i service = ', i);
          // console.log('body service = ', body);
          // return true;

          return this.http.post(this.mainApi + 'insertFinishDetail', body);
        } // ใส่เหตุผลอาการเสียตอนส่งซ่อม Tab1 qaStatus

      }, {
        key: "insertRepairReason",
        value: function insertRepairReason(i) {
          var body = {
            qaRepairID: Number(i.qaRepairID),
            repairItem: Number(i.repairItem),
            reasonNo: i.reasonNo,
            typeID: i.typeID,
            Qty: Number(i.Qty)
          }; // console.log('แสดงอาการเสีย = ', body);

          return this.http.post(this.mainApi + 'insertRepairReason', body);
        } // Qa เสร็จ Master Tab1

      }, {
        key: "qaFinishMaster",
        value: function qaFinishMaster(sales) {
          return this.http.get("".concat(this.mainApi, "qaFinishMaster/").concat(sales));
        } // Qa เสร็จ Detail Tab1

      }, {
        key: "qaFinishDetail",
        value: function qaFinishDetail(finishID) {
          return this.http.get("".concat(this.mainApi, "qaFinishDetail/").concat(finishID));
        } // แสดงอาการเสีย

      }, {
        key: "repairTypePopup",
        value: function repairTypePopup(repairID, repairItem) {
          return this.http.get("".concat(this.mainApi, "getRepairReason/").concat(repairID, "/").concat(repairItem));
        } // เช็คค่า QTY ในบิลซ่อม ไม่ให้เกิน Bill

      }, {
        key: "checkQtyRepair",
        value: function checkQtyRepair(billID, billItem) {
          return this.http.get("".concat(this.mainApi, "checkQtyRepair/").concat(billID, "/").concat(billItem));
        } // ยกเลิกบิลซ่อม

      }, {
        key: "cancelBillRepair",
        value: function cancelBillRepair(repairID) {
          return this.http.put("".concat(this.mainApi, "cancelBillRepair/").concat(repairID), {});
        } // ดูอาการเสีย

      }, {
        key: "getRepairReason",
        value: function getRepairReason(repairID, repairItem) {
          return this.http.get(this.mainApi + 'getRepairReason/' + repairID + '/' + repairItem);
        }
      }, {
        key: "repairFinishMaster",
        value: function repairFinishMaster(salesID) {
          return this.http.get("".concat(this.mainApi, "repairFinishMaster/").concat(salesID));
        }
      }]);

      return QasalesService;
    }();

    QasalesService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }];
    };

    QasalesService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], QasalesService);
    /***/
  },

  /***/
  "./src/app/tabs/qastatus/qa-finish-master/qa-finish-master-routing.module.ts":
  /*!***********************************************************************************!*\
    !*** ./src/app/tabs/qastatus/qa-finish-master/qa-finish-master-routing.module.ts ***!
    \***********************************************************************************/

  /*! exports provided: QaFinishMasterPageRoutingModule */

  /***/
  function srcAppTabsQastatusQaFinishMasterQaFinishMasterRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "QaFinishMasterPageRoutingModule", function () {
      return QaFinishMasterPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _qa_finish_master_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./qa-finish-master.page */
    "./src/app/tabs/qastatus/qa-finish-master/qa-finish-master.page.ts");

    var routes = [{
      path: '',
      component: _qa_finish_master_page__WEBPACK_IMPORTED_MODULE_3__["QaFinishMasterPage"]
    }, {
      path: 'qa-finish-detail',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | qa-finish-detail-qa-finish-detail-module */
        "default~qa-finish-detail-qa-finish-detail-module~tabs-qastatus-qa-finish-master-qa-finish-detail-qa-~59da3f9e").then(__webpack_require__.bind(null,
        /*! ./qa-finish-detail/qa-finish-detail.module */
        "./src/app/tabs/qastatus/qa-finish-master/qa-finish-detail/qa-finish-detail.module.ts")).then(function (m) {
          return m.QaFinishDetailPageModule;
        });
      }
    }];

    var QaFinishMasterPageRoutingModule = function QaFinishMasterPageRoutingModule() {
      _classCallCheck(this, QaFinishMasterPageRoutingModule);
    };

    QaFinishMasterPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], QaFinishMasterPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/tabs/qastatus/qa-finish-master/qa-finish-master.module.ts":
  /*!***************************************************************************!*\
    !*** ./src/app/tabs/qastatus/qa-finish-master/qa-finish-master.module.ts ***!
    \***************************************************************************/

  /*! exports provided: QaFinishMasterPageModule */

  /***/
  function srcAppTabsQastatusQaFinishMasterQaFinishMasterModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "QaFinishMasterPageModule", function () {
      return QaFinishMasterPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _qa_finish_master_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./qa-finish-master-routing.module */
    "./src/app/tabs/qastatus/qa-finish-master/qa-finish-master-routing.module.ts");
    /* harmony import */


    var _qa_finish_master_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./qa-finish-master.page */
    "./src/app/tabs/qastatus/qa-finish-master/qa-finish-master.page.ts");

    var QaFinishMasterPageModule = function QaFinishMasterPageModule() {
      _classCallCheck(this, QaFinishMasterPageModule);
    };

    QaFinishMasterPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _qa_finish_master_routing_module__WEBPACK_IMPORTED_MODULE_5__["QaFinishMasterPageRoutingModule"]],
      declarations: [_qa_finish_master_page__WEBPACK_IMPORTED_MODULE_6__["QaFinishMasterPage"]]
    })], QaFinishMasterPageModule);
    /***/
  },

  /***/
  "./src/app/tabs/qastatus/qa-finish-master/qa-finish-master.page.scss":
  /*!***************************************************************************!*\
    !*** ./src/app/tabs/qastatus/qa-finish-master/qa-finish-master.page.scss ***!
    \***************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppTabsQastatusQaFinishMasterQaFinishMasterPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3RhYnMvcWFzdGF0dXMvcWEtZmluaXNoLW1hc3Rlci9xYS1maW5pc2gtbWFzdGVyLnBhZ2Uuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/tabs/qastatus/qa-finish-master/qa-finish-master.page.ts":
  /*!*************************************************************************!*\
    !*** ./src/app/tabs/qastatus/qa-finish-master/qa-finish-master.page.ts ***!
    \*************************************************************************/

  /*! exports provided: QaFinishMasterPage */

  /***/
  function srcAppTabsQastatusQaFinishMasterQaFinishMasterPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "QaFinishMasterPage", function () {
      return QaFinishMasterPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/auth/auth.service */
    "./src/app/auth/auth.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _services_qasales_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./../../../services/qasales.service */
    "./src/app/services/qasales.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");

    var QaFinishMasterPage = /*#__PURE__*/function () {
      function QaFinishMasterPage(authService, loadingCtrl, service, nav, route) {
        _classCallCheck(this, QaFinishMasterPage);

        this.authService = authService;
        this.loadingCtrl = loadingCtrl;
        this.service = service;
        this.nav = nav;
        this.route = route;
        this.search = false;
        this.sum1 = 0;
      }

      _createClass(QaFinishMasterPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.user = this.authService.getUserInfo();
        }
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.search = false;
          this.user = this.authService.getUserInfo();

          if (!this.user) {
            this.route.navigateByUrl('/auth');
          } else {
            // console.log(this.user[0].saleManager);
            this.loaddata();
          }
        }
      }, {
        key: "loaddata",
        value: function loaddata() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
            var _this = this;

            var loading;
            return regeneratorRuntime.wrap(function _callee5$(_context5) {
              while (1) {
                switch (_context5.prev = _context5.next) {
                  case 0:
                    _context5.next = 2;
                    return this.loadingCtrl.create({
                      spinner: 'bubbles',
                      message: 'กำลังโหลด'
                    });

                  case 2:
                    loading = _context5.sent;
                    _context5.next = 5;
                    return loading.present();

                  case 5:
                    this.sub = this.service.qaFinishMaster(this.user[0].saleManager).subscribe(function (data) {
                      _this.qaFinishMaster = data; //  console.log(this.qaFinishMaster);
                    }, function (err) {
                      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
                        return regeneratorRuntime.wrap(function _callee3$(_context3) {
                          while (1) {
                            switch (_context3.prev = _context3.next) {
                              case 0:
                                console.log(err);
                                _context3.next = 3;
                                return loading.dismiss();

                              case 3:
                              case "end":
                                return _context3.stop();
                            }
                          }
                        }, _callee3);
                      }));
                    }, function () {
                      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
                        var _this2 = this;

                        return regeneratorRuntime.wrap(function _callee4$(_context4) {
                          while (1) {
                            switch (_context4.prev = _context4.next) {
                              case 0:
                                this.sum1 = 0;
                                this.qaFinishMaster.forEach(function (item) {
                                  _this2.sum1 = _this2.sum1 + item.TotalQaFinish;
                                });
                                _context4.next = 4;
                                return loading.dismiss();

                              case 4:
                              case "end":
                                return _context4.stop();
                            }
                          }
                        }, _callee4, this);
                      }));
                    });

                  case 6:
                  case "end":
                    return _context5.stop();
                }
              }
            }, _callee5, this);
          }));
        }
      }, {
        key: "goToqaFinishDetail",
        value: function goToqaFinishDetail(i) {
          this.nav.navigateForward(['/qafinish-detail', {
            finishID: i.qaFinish_ID,
            OrderNumber: i.OrderNumber,
            fullName: i.fullName,
            date: i.receiveDate,
            thaiDate: i.thaiDate,
            qaDoc: i.qaDocNumber,
            showIcon: i.showIcon,
            avatar: i.avatar,
            nickName: i.nickName
          }]);
        }
      }, {
        key: "showSearch",
        value: function showSearch() {
          this.search = !this.search;
        }
      }, {
        key: "getBill",
        value: function getBill(ev) {
          var _this3 = this;

          var val = ev.target.value;

          if (val && val.trim() !== '') {
            this.qaFinishMaster = this.qaFinishMaster.filter(function (bill) {
              return bill.OrderNumber.toLowerCase().indexOf(val.toLowerCase()) > -1;
            });
            this.sum1 = 0;
            this.qaFinishMaster.forEach(function (item) {
              _this3.sum1 = _this3.sum1 + item.TotalQaFinish;
            });
          } else {
            this.loaddata();
          }
        }
      }, {
        key: "onClickRefresh",
        value: function onClickRefresh() {
          this.loaddata();
        }
      }, {
        key: "backToQaStatus",
        value: function backToQaStatus() {
          this.nav.navigateBack(['/tabs/qastatus']);
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          this.sub.unsubscribe();
        }
      }]);

      return QaFinishMasterPage;
    }();

    QaFinishMasterPage.ctorParameters = function () {
      return [{
        type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"]
      }, {
        type: _services_qasales_service__WEBPACK_IMPORTED_MODULE_4__["QasalesService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]
      }];
    };

    QaFinishMasterPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-qa-finish-master',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./qa-finish-master.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/qastatus/qa-finish-master/qa-finish-master.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./qa-finish-master.page.scss */
      "./src/app/tabs/qastatus/qa-finish-master/qa-finish-master.page.scss"))["default"]]
    })], QaFinishMasterPage);
    /***/
  }
}]);
//# sourceMappingURL=common-es5.js.map