(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tabs-orderstatus-report-repair-byorder-report-repair-byorder-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.html":
/*!**********************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.html ***!
  \**********************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-title class=\"fontPromptBold fontSize20\">รายการซ่อม</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n\n\n    <div align=\"center\">\n      <ion-img src=\"{{product.NewPict}}\" style=\"width: 250px;\"></ion-img>\n      <h3 class=\" fontPromptRegular\">{{product.ProductCode}}</h3>\n    </div>\n\n\n    <ion-item color=\"light\" >\n\n\n      <ion-label class=\"fixed50 ion-text-center\">\n        <ion-text class=\"fontPromptRegular fontSize18\">\n         จำนวนงานของ Order :  {{product.TotalQty}}\n        </ion-text>\n      </ion-label>\n\n      <ion-label class=\"fixed50 ion-text-center\">\n        <ion-text class=\"fontPromptRegular fontSize18\">\n         ยอดซ่อมทั้งหมด : {{sum}} \n         <ion-text class=\"fontPromptBold fontSize20\" color=\"warning\">= {{(sum/product.TotalQty)*100 | number:'1.0-1'}}%</ion-text>\n        </ion-text>\n      </ion-label>\n\n \n\n    </ion-item>\n\n    \n      <ion-item color=\"warning\" >\n        <ion-label class=\"fixed15 ion-text-center\">\n          <ion-text class=\"fontPromptRegular fontSize16\">\n            วันที่ส่งซ่อม\n          </ion-text>\n        </ion-label>\n\n        <ion-label class=\"fixed30 ion-text-center\">\n          <ion-text class=\"fontPromptRegular fontSize16\">\n            เลขที่บิล QA\n          </ion-text>\n        </ion-label>\n\n        <ion-label class=\"fixed40 ion-text-center\">\n          <ion-text class=\"fontPromptRegular fontSize16\">\n            อาการที่ซ่อม\n          </ion-text>\n        </ion-label>\n\n        <ion-label class=\"fixed10 ion-text-center\">\n          <ion-text class=\"fontPromptRegular fontSize16\">\n            จำนวน\n          </ion-text>\n        </ion-label>\n      </ion-item>\n\n\n\n\n      <ion-item  *ngFor=\"let i of ReportRepairItem\">\n          <ion-label class=\"fixed15 ion-text-center\">\n            <ion-text class=\"fontPromptRegular fontSize16\">\n              {{i.repairDate | date:\"dd/MM/yy\":\"+0000\" }}<br>\n              <ion-text class=\"colorFontGray\">{{i.repairDate | date: 'HH:mm' : '+0' }} น.</ion-text>\n            </ion-text>\n          </ion-label>\n\n          <ion-label class=\"fixed30 ion-text-center\">\n            <ion-text class=\"fontPromptRegular fontSize16\">\n              {{i.qaDocNumber}}\n            </ion-text>\n          </ion-label>\n  \n          <ion-label class=\"fixed40 ion-text-center\">\n            <ion-text class=\"fontPromptRegular fontSize16\">\n              {{i.repairType}}-{{i.reasonType}}\n            </ion-text>\n          </ion-label>\n  \n          <ion-label class=\"fixed10 ion-text-center\">\n            <ion-text class=\"fontPromptRegular fontSize16\">\n              {{i.Qty}}\n            </ion-text>\n          </ion-label>\n      </ion-item>\n\n\n\n    <div align=\"center\">\n      <br><br><br>\n      <ion-button color=\"danger\" (click)=\"closeModal()\">&nbsp;&nbsp;&nbsp;&nbsp;ปิด&nbsp;&nbsp;&nbsp;&nbsp;</ion-button>\n    </div>\n\n</ion-content>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/orderstatus/report-repair-byorder/report-repair-byorder.page.html":
/*!******************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/orderstatus/report-repair-byorder/report-repair-byorder.page.html ***!
  \******************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-button>\n        <ion-back-button></ion-back-button>\n      </ion-button>\n    </ion-buttons>\n    <ion-title><ion-text class=\"fontSize24 fontPromptBold\">รายการซ่อมของ Order</ion-text></ion-title>\n  </ion-toolbar>\n\n  <ion-toolbar >\n  <ion-title><ion-text color=\"warning\" class=\"fontSize20 fontPromptBold\">{{ orderNumber }}</ion-text></ion-title>\n  </ion-toolbar>\n\n  <ion-item lines=\"none\">\n    <ion-checkbox color=\"warning\" slot=\"start\" (click)=\"getSum()\"></ion-checkbox>\n    <ion-label>\n      <h1  class=\"fontPromptRegular\">\n        เลือกเฉพาะที่มีรายการซ่อม\n      </h1>\n    </ion-label>\n  </ion-item>\n\n  <ion-grid>\n    <ion-row>\n      <ion-col>\n        <ion-item color=\"warning\">\n  \n          <ion-col size=\"0.7\">\n            <ion-label>\n              <ion-text class=\"fontPromptBold ion-text-left\">\n                No.\n              </ion-text>\n            </ion-label>\n          </ion-col>\n  \n          \n          <ion-col size=\"3.3\" class=\"ion-text-center\">\n            <ion-label>\n              <ion-text class=\"fontPromptBold \"> Product </ion-text>\n            </ion-label>\n          </ion-col>\n  \n          <ion-col size=\"1.5\" offset=\"0.5\" class=\"ion-text-center\">\n            <ion-label>\n              <ion-text class=\"fontPromptBold ion-text-center\">\n                จำนวน<br>Order\n              </ion-text>\n            </ion-label>\n          </ion-col>\n  \n          <ion-col size=\"1.5\" offset=\"0.5\" class=\"ion-text-center\">\n            <ion-label>\n              <ion-text class=\"fontPromptBold ion-text-center\">\n                ยอดรวม<br>ที่ซ่อม\n              </ion-text>\n            </ion-label>\n          </ion-col>\n  \n          <ion-col size=\"4\" class=\"ion-text-center\">\n            <ion-label >\n              <ion-text class=\"fontPromptBold ion-text-center\">\n                รายการซ่อม\n              </ion-text>\n            </ion-label>\n          </ion-col>\n  \n        </ion-item>\n      </ion-col>\n    </ion-row>\n\n    <ion-row>\n      <ion-col>\n        <ion-item color=\"light\">\n  \n          <ion-col size=\"4\" class=\"ion-text-center\">\n            <ion-label>\n              <ion-text class=\"fontPromptBold fontSize20\">\n                ยอดรวม\n              </ion-text>\n            </ion-label>\n          </ion-col>\n  \n          <ion-col size=\"1.5\" offset=\"0.5\" class=\"ion-text-center\">\n            <ion-label>\n              <ion-text class=\"fontPromptBold fontSize20\">\n                {{sum1}}\n              </ion-text>\n            </ion-label>\n          </ion-col>\n  \n          <ion-col size=\"1.5\" offset=\"0.5\" class=\"ion-text-center\">\n            <ion-label color=\"warning\">\n              <ion-text class=\"fontPromptBold fontSize20\">\n                {{sum2}}\n              </ion-text>\n            </ion-label>\n          </ion-col>\n  \n          <ion-col size=\"4\" class=\"ion-text-center\">\n            <ion-label >\n              <ion-text class=\"fontPromptBold ion-text-center\">\n                \n              </ion-text>\n            </ion-label>\n          </ion-col>\n  \n        </ion-item>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-header>\n\n<ion-content>\n<ion-grid>\n  <ion-row>\n    <ion-col>\n      <ion-item *ngFor=\"let i of orderItems\" class=\"align\" (click)=\"openModalReportRepair(i)\">\n\n        <ion-col size=\"0.7\">\n          <ion-label>\n            <ion-text class=\"fontPromptRegular ion-text-left\">\n              {{i.ItemNo}}\n            </ion-text>\n          </ion-label>\n        </ion-col>\n\n        \n        <ion-col size=\"3.3\" class=\"ion-text-center\">\n            <img src=\"{{i.NewPict}}\">\n            <ion-text class=\"fontPromptRegular \"> {{i.ProductCode}}</ion-text>\n        </ion-col>\n\n        <ion-col size=\"1.5\" offset=\"0.5\" class=\"ion-text-center\">\n          <ion-label>\n            <ion-text class=\"fontPromptRegular\">\n              {{i.TotalQty}}\n            </ion-text>\n          </ion-label>\n        </ion-col>\n\n        <ion-col size=\"1.5\" offset=\"0.5\" class=\"ion-text-center\">\n          <ion-label color=\"warning\">\n            <ion-text class=\"fontPromptBold fontSize18\">\n              {{i.SumRepair}}<br>\n              <ion-text class=\"fontPromptBold colorFontRed fontSize14\">{{(i.SumRepair / i.TotalQty)*100 | number:'1.0-1'}}%</ion-text>\n            </ion-text>\n          </ion-label>\n        </ion-col>\n\n        <ion-col size=\"4\" offset= \"0.5\"class=\"ion-text-left\">\n          <ion-label  *ngFor=\"let r of reasonReport\"  >\n            <ion-text *ngIf=\"r.OrderItemNo === i.ItemNo\">\n              <h2 class=\"fontPromptRegular\" > {{r.repairType}}-{{r.reasonType}} = {{r.Qty}}</h2>\n            </ion-text>\n          </ion-label>\n        </ion-col>\n\n      </ion-item>\n    </ion-col>\n  </ion-row>\n</ion-grid>\n\n</ion-content>\n");

/***/ }),

/***/ "./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.scss":
/*!********************************************************************************************!*\
  !*** ./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.scss ***!
  \********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3RhYnMvb3JkZXJzdGF0dXMvcG9wdXAtcmVwb3J0cmVwYWlyLWl0ZW0vcG9wdXAtcmVwb3J0cmVwYWlyLWl0ZW0ucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.ts":
/*!******************************************************************************************!*\
  !*** ./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.ts ***!
  \******************************************************************************************/
/*! exports provided: PopupReportrepairItemPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PopupReportrepairItemPage", function() { return PopupReportrepairItemPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_services_qasales_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/qasales.service */ "./src/app/services/qasales.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");




let PopupReportrepairItemPage = class PopupReportrepairItemPage {
    constructor(service, loadingCtrl, modal) {
        this.service = service;
        this.loadingCtrl = loadingCtrl;
        this.modal = modal;
    }
    ngOnInit() {
        // console.log(this.product);
        this.loadData();
    }
    loadData() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingCtrl.create({
                spinner: 'dots',
                message: 'กำลังโหลดข้อมูล...'
            });
            yield loading.present();
            // start loading
            this.sub1 = this.service.reportRepairbyItem(this.product.OrderNumber, this.product.ItemNo).subscribe(data => {
                this.ReportRepairItem = data;
                // console.log(this.ReportRepairItem);
            }, (error) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                console.log(error);
                yield loading.dismiss();
            }), () => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                this.sum = 0;
                this.ReportRepairItem.forEach((item) => {
                    this.sum = this.sum + item.Qty;
                });
                yield loading.dismiss();
            }));
        });
    }
    closeModal() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            // console.log('sent back', this.selectQty);
            yield this.modal.dismiss();
        });
    }
    ngOnDestroy() {
        this.sub1.unsubscribe();
    }
};
PopupReportrepairItemPage.ctorParameters = () => [
    { type: src_app_services_qasales_service__WEBPACK_IMPORTED_MODULE_2__["QasalesService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"] }
];
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], PopupReportrepairItemPage.prototype, "product", void 0);
PopupReportrepairItemPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-popup-reportrepair-item',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./popup-reportrepair-item.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./popup-reportrepair-item.page.scss */ "./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.scss")).default]
    })
], PopupReportrepairItemPage);



/***/ }),

/***/ "./src/app/tabs/orderstatus/report-repair-byorder/report-repair-byorder-routing.module.ts":
/*!************************************************************************************************!*\
  !*** ./src/app/tabs/orderstatus/report-repair-byorder/report-repair-byorder-routing.module.ts ***!
  \************************************************************************************************/
/*! exports provided: ReportRepairByorderPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReportRepairByorderPageRoutingModule", function() { return ReportRepairByorderPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _report_repair_byorder_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./report-repair-byorder.page */ "./src/app/tabs/orderstatus/report-repair-byorder/report-repair-byorder.page.ts");




const routes = [
    {
        path: '',
        component: _report_repair_byorder_page__WEBPACK_IMPORTED_MODULE_3__["ReportRepairByorderPage"]
    }
];
let ReportRepairByorderPageRoutingModule = class ReportRepairByorderPageRoutingModule {
};
ReportRepairByorderPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ReportRepairByorderPageRoutingModule);



/***/ }),

/***/ "./src/app/tabs/orderstatus/report-repair-byorder/report-repair-byorder.module.ts":
/*!****************************************************************************************!*\
  !*** ./src/app/tabs/orderstatus/report-repair-byorder/report-repair-byorder.module.ts ***!
  \****************************************************************************************/
/*! exports provided: ReportRepairByorderPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReportRepairByorderPageModule", function() { return ReportRepairByorderPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _report_repair_byorder_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./report-repair-byorder-routing.module */ "./src/app/tabs/orderstatus/report-repair-byorder/report-repair-byorder-routing.module.ts");
/* harmony import */ var _report_repair_byorder_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./report-repair-byorder.page */ "./src/app/tabs/orderstatus/report-repair-byorder/report-repair-byorder.page.ts");







let ReportRepairByorderPageModule = class ReportRepairByorderPageModule {
};
ReportRepairByorderPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _report_repair_byorder_routing_module__WEBPACK_IMPORTED_MODULE_5__["ReportRepairByorderPageRoutingModule"]
        ],
        declarations: [_report_repair_byorder_page__WEBPACK_IMPORTED_MODULE_6__["ReportRepairByorderPage"]]
    })
], ReportRepairByorderPageModule);



/***/ }),

/***/ "./src/app/tabs/orderstatus/report-repair-byorder/report-repair-byorder.page.scss":
/*!****************************************************************************************!*\
  !*** ./src/app/tabs/orderstatus/report-repair-byorder/report-repair-byorder.page.scss ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".myImg {\n  -webkit-filter: brightness(50%);\n          filter: brightness(50%);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy90aGFuYXNhdGUvaW9uaWMvcWFTYWxlcy1WMy40L3NyYy9hcHAvdGFicy9vcmRlcnN0YXR1cy9yZXBvcnQtcmVwYWlyLWJ5b3JkZXIvcmVwb3J0LXJlcGFpci1ieW9yZGVyLnBhZ2Uuc2NzcyIsInNyYy9hcHAvdGFicy9vcmRlcnN0YXR1cy9yZXBvcnQtcmVwYWlyLWJ5b3JkZXIvcmVwb3J0LXJlcGFpci1ieW9yZGVyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLCtCQUFBO1VBQUEsdUJBQUE7QUNDSiIsImZpbGUiOiJzcmMvYXBwL3RhYnMvb3JkZXJzdGF0dXMvcmVwb3J0LXJlcGFpci1ieW9yZGVyL3JlcG9ydC1yZXBhaXItYnlvcmRlci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubXlJbWcge1xyXG4gICAgZmlsdGVyOiBicmlnaHRuZXNzKDUwJSk7XHJcbiAgfSIsIi5teUltZyB7XG4gIGZpbHRlcjogYnJpZ2h0bmVzcyg1MCUpO1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/tabs/orderstatus/report-repair-byorder/report-repair-byorder.page.ts":
/*!**************************************************************************************!*\
  !*** ./src/app/tabs/orderstatus/report-repair-byorder/report-repair-byorder.page.ts ***!
  \**************************************************************************************/
/*! exports provided: ReportRepairByorderPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReportRepairByorderPage", function() { return ReportRepairByorderPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_services_qasales_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/qasales.service */ "./src/app/services/qasales.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _popup_reportrepair_item_popup_reportrepair_item_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../popup-reportrepair-item/popup-reportrepair-item.page */ "./src/app/tabs/orderstatus/popup-reportrepair-item/popup-reportrepair-item.page.ts");






let ReportRepairByorderPage = class ReportRepairByorderPage {
    constructor(router, route, service, loadingCtrl, nav, modal) {
        this.router = router;
        this.route = route;
        this.service = service;
        this.loadingCtrl = loadingCtrl;
        this.nav = nav;
        this.modal = modal;
        this.sum1 = 0;
        this.sum2 = 0;
        this.selectGet = false;
        this.orderNumber = this.route.snapshot.paramMap.get('orderNumber');
    }
    ngOnInit() {
        this.loadData();
        this.selectGet = false;
    }
    loadData() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingCtrl.create({
                spinner: 'bubbles',
                message: 'กำลังโหลดข้อมูล...'
            });
            yield loading.present();
            this.sub1 = this.service.reportRepairbyOrder(this.orderNumber).subscribe((data) => {
                this.reasonReport = data;
                // console.log(this.reasonReport);
            }, (error) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                console.log(error);
                yield loading.dismiss();
            }), () => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                this.sub2 = this.service.getOrderDetail(this.orderNumber).subscribe((data2) => {
                    this.orderItems = data2;
                    this.orderItemsGet = data2;
                    // console.log(this.orderItems);
                }, (err) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                    console.log(err);
                }), () => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                    this.sumValues();
                    yield loading.dismiss();
                }));
            }));
        });
    }
    getSum() {
        this.selectGet = !this.selectGet;
        this.orderItems = this.orderItemsGet;
        if (this.selectGet) {
            this.orderItems = this.orderItems.filter((sum) => {
                return (sum.SumRepair > 0);
            }),
                this.sumValues();
        }
        else {
            this.orderItems = this.orderItemsGet;
            this.sumValues();
        }
    }
    sumValues() {
        this.sum1 = this.sum2 = 0;
        this.orderItems.forEach((item) => {
            this.sum1 = this.sum1 + item.TotalQty;
            this.sum2 = this.sum2 + item.SumRepair;
        });
    }
    backToOrderStatus() {
        this.nav.navigateBack(['/orderitems']);
    }
    openModalReportRepair(i) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            // console.log(i);
            if (i.SumRepair > 0) {
                const modal = yield this.modal.create({
                    component: _popup_reportrepair_item_popup_reportrepair_item_page__WEBPACK_IMPORTED_MODULE_5__["PopupReportrepairItemPage"],
                    componentProps: {
                        product: i,
                    }
                });
                modal.onWillDismiss().then(dataReturn => {
                    // console.log(dataReturn);
                });
                return yield modal.present();
            }
        });
    }
    ngOnDestroy() {
        this.sub1.unsubscribe();
        this.sub2.unsubscribe();
    }
};
ReportRepairByorderPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
    { type: src_app_services_qasales_service__WEBPACK_IMPORTED_MODULE_2__["QasalesService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] }
];
ReportRepairByorderPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-report-repair-byorder',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./report-repair-byorder.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/orderstatus/report-repair-byorder/report-repair-byorder.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./report-repair-byorder.page.scss */ "./src/app/tabs/orderstatus/report-repair-byorder/report-repair-byorder.page.scss")).default]
    })
], ReportRepairByorderPage);



/***/ })

}]);
//# sourceMappingURL=tabs-orderstatus-report-repair-byorder-report-repair-byorder-module-es2015.js.map